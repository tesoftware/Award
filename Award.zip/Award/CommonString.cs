﻿using System.IO;
using System.Text;
using System;
using System.Security.Cryptography;
namespace ConferenceSupport
{
    class Common
    {

        public static string[] AwardStyleArr = new string[] { "特等奖", "一等奖", "二等奖", "三等奖", "四等奖", "五等奖", "幸运奖", "阳光普照奖", "特别奖", "现场奖" };
        public static string[] AwardPageArr = new string[] { "同屏1人", "同屏2人", "同屏5人", "同屏10人", "同屏20人" };

        //数据库连接字串
        public static string strConn(){
            string mdbPath = "";  //声明MDB文件的路径
            string strConn; //连接字串
            string filePath = System.IO.Directory.GetCurrentDirectory() + @"\\template\\db_config.ini";  //配置文件路径
            if (File.Exists(filePath))  //如果文件存在，那么读取网络的数据库配置
            {
                FileStream fileStream = new FileStream(filePath, FileMode.Open);
                StreamReader sr = new StreamReader(fileStream);
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    mdbPath = line.ToString();
                }
                fileStream.Close();
            }
            if (mdbPath == "") mdbPath = System.IO.Directory.GetCurrentDirectory() + "\\database.mdb;";   //如果没有配置网络版，则使用本地MDB
            strConn = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + mdbPath;
            return strConn;                      
        }
        //过滤非法字符
        public static string CheckSql(string str)
        {
            string s = string.Empty;
            if (str == null)
            {
                s = string.Empty;
            }
            else
            {
                s = str.Replace("'", "").Replace("*", "").Replace("select", "");                       
            }            
            return s;
        }
        //时间戳转日期
        public static string DataChange(string timeStamp)
        {
            if (timeStamp == "0") return "";
            if (timeStamp == "") return "";
            if (timeStamp.Length > 10)
            {
                timeStamp = timeStamp.Substring(0, 10);
            }
            DateTime dateTimeStart = TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1));
            long lTime = long.Parse(timeStamp + "0000000");
            TimeSpan toNow = new TimeSpan(lTime);
            DateTime pdate = dateTimeStart.Add(toNow);
            string pubdate = pdate.ToString("yyyy-MM-dd HH:mm:ss");
            return pubdate;
        }
        //返回当前时间戳
        public static string NowStamp()
        {
            DateTime dt = DateTime.Now;
            System.DateTime startTime = TimeZone.CurrentTimeZone.ToLocalTime(new System.DateTime(1970, 1, 1, 0, 0, 0, 0));
            long t = (dt.Ticks - startTime.Ticks) / 10000000;   //除10000调整为10位      
            return t.ToString();
        }

        //写日志
        public static void WriteLog(string Logtext)
        {
            try
            {
                if (!Directory.Exists(System.IO.Directory.GetCurrentDirectory() + "/log/"))
                {
                    Directory.CreateDirectory("log");
                }
                DateTime dt = DateTime.Now;
                string Save_file = System.IO.Directory.GetCurrentDirectory() + "/log/" + dt.ToString("yyyyMMdd") + ".log";
                //创建一个文件流，用以写入或者创建一个StreamWriter
                FileStream fs = new FileStream(Save_file, FileMode.Append, FileAccess.Write);
                Logtext = dt.ToString("yyyy-MM-dd HH:mm:ss") + "   " + Logtext + "\r\n";
                byte[] p = System.Text.Encoding.UTF8.GetBytes(Logtext);
                fs.Write(p, 0, p.Length);
                fs.Close();
            }
            catch
            {
            }
        }
        //替换掉非法字符
        public static string RemoveNotNumber(string src)
        {
            if (src == null)
                return "";
            StringBuilder result = new StringBuilder();
            if (src != null)
            {
                src = src.Trim();
                for (int pos = 0; pos < src.Length; pos++)
                {
                    switch (src[pos])
                    {
                        case '.': result.Append(""); break;
                        case ',': result.Append(""); break;
                        case '<': result.Append(""); break;
                        case '>': result.Append(""); break;
                        case '#': result.Append(""); break;
                        case '?': result.Append(""); break;
                        default: result.Append(src[pos]); break;
                    }
                }
            }
            return result.ToString();
        }

        ///MD5加密 
        public static string MD5Encrypt(string txt)
        {
            using (MD5 mi = MD5.Create())
            {
                byte[] buffer = Encoding.Default.GetBytes(txt);
                //开始加密
                byte[] newBuffer = mi.ComputeHash(buffer);
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < newBuffer.Length; i++)
                {
                    sb.Append(newBuffer[i].ToString("x2"));
                }
                return sb.ToString();
            }        
        }
        //AES解密
        public static string AESDecrypt(String Data)
        {
            String Key = "tvxtFawnLjTYtL6r";
            Byte[] encryptedBytes = Convert.FromBase64String(Data);
            Byte[] bKey = new Byte[16];
            Array.Copy(Encoding.UTF8.GetBytes(Key.PadRight(bKey.Length)), bKey, bKey.Length);

            MemoryStream mStream = new MemoryStream(encryptedBytes);
            RijndaelManaged aes = new RijndaelManaged();
            aes.Mode = CipherMode.ECB;
            aes.Padding = PaddingMode.PKCS7;
            aes.KeySize = 128;
            aes.Key = bKey;
            CryptoStream cryptoStream = new CryptoStream(mStream, aes.CreateDecryptor(), CryptoStreamMode.Read);
            try
            {
                byte[] tmp = new byte[encryptedBytes.Length + 32];
                int len = cryptoStream.Read(tmp, 0, encryptedBytes.Length + 32);
                byte[] ret = new byte[len];
                Array.Copy(tmp, 0, ret, 0, len);
                return Encoding.UTF8.GetString(ret);
            }
            finally
            {
                cryptoStream.Close();
                mStream.Close();
                aes.Clear();
            }
        }
        public static string AesEncrypt(string str)
        {
            string key = "Adrklseqoerjcdrp";
            if (string.IsNullOrEmpty(str)) return null;
            Byte[] toEncryptArray = Encoding.UTF8.GetBytes(str);

            RijndaelManaged rm = new RijndaelManaged
            {
                Key = Encoding.UTF8.GetBytes(key),
                Mode = CipherMode.ECB,
                Padding = PaddingMode.PKCS7
            };

            ICryptoTransform cTransform = rm.CreateEncryptor();
            Byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);

            return Convert.ToBase64String(resultArray, 0, resultArray.Length);
        }
    }
}
