﻿using System;
using System.Drawing;
using System.Text;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;

namespace ConferenceSupport
{
    public partial class FrmAwardUserList : Form
    {
        public FrmAwardUserList()
        {
            InitializeComponent();
        }
        private string FileName = System.IO.Directory.GetCurrentDirectory() + @"\\template\\config.ini";
        //参数说明：section：INI文件中的段落；key：INI文件中的关键字；val：INI文件中关键字的数值；filePath：INI文件的完整的路径和名称。
        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);
        //关闭窗体
        private void labelExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //窗体启动
        private void FrmAwardUserList_Load(object sender, EventArgs e)
        {
            //屏幕自适应
            int SW = Screen.PrimaryScreen.Bounds.Width;
            int SH = Screen.PrimaryScreen.Bounds.Height;
            this.Width = SW;
            this.Height = SH;
            int subSW = (SW - 840) / 2;
            int subSH = (SH - 600) / 2;
            BackBoard.Location = new Point(subSW, subSH);
            labelExit.Location = new Point(0, 0);
            ReadiniFile();
            ReLoagDeedpool();

            //ListView排序
            this.SeedList.ListViewItemSorter = new CommonListView.ListViewColumnSorter();
            this.SeedList.ColumnClick += new ColumnClickEventHandler(CommonListView.ListViewHelper.ListView_ColumnClick);
        }
        //读取奖池//////////////////
        private void ReLoagDeedpool()
        {           
            SeedList.Items.Clear();
            OleDbConnection odcConnection = new OleDbConnection(Common.strConn());
            if (odcConnection.State == System.Data.ConnectionState.Open) odcConnection.Close();
            odcConnection.Open();
            OleDbCommand odCommand = odcConnection.CreateCommand();
            odCommand.CommandText = "select id,dept_name,person,employee_no,award_name,award_item from Seedlist order by id asc";
            OleDbDataReader odrReader = odCommand.ExecuteReader();
            while (odrReader.Read())
            {
                ListViewItem li = new ListViewItem();
                li.SubItems.Clear();
                li.SubItems[0].Text = odrReader[0].ToString();
                li.SubItems.Add(odrReader[1].ToString());
                li.SubItems.Add(odrReader[2].ToString());
                li.SubItems.Add(odrReader[3].ToString());
                li.SubItems.Add(odrReader[4].ToString());
                li.SubItems.Add(odrReader[5].ToString());
                SeedList.Items.Add(li);
                Application.DoEvents();
            }
            odrReader.Close();
            odCommand.Dispose();
            odcConnection.Close();
        }
        //读取ini配置
        private void ReadiniFile()
        {
            if (File.Exists(FileName))
            {
                try
                {
                    StringBuilder temp = new StringBuilder(256);
                    string ColorStr = temp.ToString();
                    string[] sArray = ColorStr.Split('|');
                    GetPrivateProfileString("AwardSetup", "AwardBGColor", "", temp, 256, FileName);   //抽奖文字背景颜色
                    ColorStr = temp.ToString();
                    sArray = ColorStr.Split('|');
                    this.BackColor = Color.FromArgb(Int32.Parse(sArray[0]), Int32.Parse(sArray[1]), Int32.Parse(sArray[2]));
                    BackBoard.BackColor = Color.FromArgb(Int32.Parse(sArray[0]), Int32.Parse(sArray[1]), Int32.Parse(sArray[2]));
                    
                    GetPrivateProfileString("AwardSetup", "AwardFontColor", "", temp, 256, FileName);   //抽奖背景颜色
                    ColorStr = temp.ToString();
                    sArray = ColorStr.Split('|');                    
                    LabMessageInfo.ForeColor = Color.FromArgb(Int32.Parse(sArray[0]), Int32.Parse(sArray[1]), Int32.Parse(sArray[2]));

                    GetPrivateProfileString("AwardSetup", "AwardBGpath", "", temp, 256, FileName);   //签到背景图路径
                    string backpicpath = temp.ToString();
                    if (File.Exists(@backpicpath))
                    {
                        this.BackgroundImage = Image.FromFile(@backpicpath);
                    }
                }
                catch
                {
                    MessageBox.Show("配置文件错误，请检查文件是否完整");
                    Application.Exit();
                }
            }
        }
        //获取签到名单中已签到的人员到奖池
        private void BtnMarkdata_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("生成奖池将清空所有历史中奖记录，是否已导出重要数据？", "导入确认", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                FrmWait wait = new FrmWait();
                wait.TopMost = true;
                wait.StartPosition = FormStartPosition.CenterScreen;
                wait.Show();
                Application.DoEvents();
                SeedList.Items.Clear();
                Application.DoEvents();
                ClearAllPersondate();
                OleDbConnection odcConnection = new OleDbConnection(Common.strConn());
                if (odcConnection.State == System.Data.ConnectionState.Open) odcConnection.Close();
                odcConnection.Open();
                OleDbCommand odCommand = odcConnection.CreateCommand();
                odCommand.CommandText = "select company_name,person,comp_no from [employee] where check_flag = '1' and award_flag = '1' and del_flag = '0'";
                OleDbDataReader odrReader = odCommand.ExecuteReader();
                string sqlstr = "";
                int k = 0;
                while (odrReader.Read())
                {
                    Application.DoEvents();
                    sqlstr = "insert into [seedlist] (dept_name,person,employee_no,award_name,award_item,award_flag) values (";
                    sqlstr += "'" + odrReader["company_name"].ToString() + "',";
                    sqlstr += "'" + odrReader["person"].ToString() + "',";
                    sqlstr += "'" + odrReader["comp_no"].ToString() + "','--','--',0)";
                    k++;
                    if (Access.Export_to_DB(sqlstr) == false) MessageBox.Show("执行失败，请检查数据格式是否正确");
                }
                odrReader.Close();
                odCommand.Dispose();
                odcConnection.Close();
                ReLoagDeedpool();
                wait.Close();
                MessageBox.Show("生成抽奖人员名单成功！共导入 " + k.ToString() + " 位参加抽奖人员。");
                
            }
        }
        //禁止拖动列宽
        private void SeedList_ColumnWidthChanging(object sender, ColumnWidthChangingEventArgs e)
        {
            if (e.ColumnIndex > 0) return;
            ColumnHeader header = SeedList.Columns[e.ColumnIndex];
            e.NewWidth = SeedList.Columns[e.ColumnIndex].Width;
            e.Cancel = true;
        }
        //清除数据操作
        private void ClearAllPersondate()
        {
            string sql = "delete from [seedlist]";
            if (Access.Export_to_DB(sql) == false)
            {
                MessageBox.Show("执行清除数据操作失败，请检查数据格式是否正确");
                return;
            }
            sql = "alter table [seedlist] alter id counter(1,1);";
            Access.Export_to_DB(sql);
        }
        //返回主选单
        private void Btn_BackHome_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //数据统计
        private void BtnDatashow_Click(object sender, EventArgs e)
        {
            string Awardstr = "【中奖人员统计表】\n\n";
            string sql = "select count(*) as result from [seedlist]";
            string result = Access.RunSqlToDB(sql);
            Awardstr += "参加抽奖总人数：" + result .ToString()+ " 人 \n";
            sql = "select count(*) as result from [seedlist] where award_flag = 1";
            result = Access.RunSqlToDB(sql);
            Awardstr += "已中奖人员：" + result.ToString() + " 人 \n\n";
            sql = "SELECT award_item ,count(award_item) as result from [seedlist] where award_flag = 1 group by award_item";
            //读取数据库，保存文件
            OleDbConnection odcConnection = new OleDbConnection(Common.strConn());
            if (odcConnection.State == System.Data.ConnectionState.Open) odcConnection.Close();
            odcConnection.Open();
            OleDbCommand odCommand = odcConnection.CreateCommand();
            odCommand.CommandText = sql;
            OleDbDataReader odrReader = odCommand.ExecuteReader();
            while (odrReader.Read())
            {
                Application.DoEvents();
                Awardstr += "奖项：" + odrReader["award_item"] + "   ----    " + odrReader["result"] + " 人\n";
            }
            odrReader.Close();
            odCommand.Dispose();
            odcConnection.Close();
            MessageBox.Show(Awardstr);
        }
        //导出中奖信息
        private void BtnExportAwardList_Click(object sender, EventArgs e)
        {
            //选择导出目录
            string FilePath = string.Empty;
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Title = "导出到CSV文件";
            sfd.Filter = "中奖人员列表l(*.csv)|*.csv";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                FilePath = sfd.FileName.ToString();           
            //弹出等待窗            
            FrmWait wait = new FrmWait();
            wait.TopMost = true;
            wait.StartPosition = FormStartPosition.CenterScreen;
            wait.Show();
            Application.DoEvents();
            //读取数据库，保存文件
            OleDbConnection odcConnection = new OleDbConnection(Common.strConn());
            if (odcConnection.State == System.Data.ConnectionState.Open) odcConnection.Close();
            odcConnection.Open();
            OleDbCommand odCommand = odcConnection.CreateCommand();
            odCommand.CommandText = "select award_name,award_item,person,employee_no,dept_name from [seedlist] where award_flag = 1 order by award_name asc,award_item asc";
            OleDbDataReader odrReader = odCommand.ExecuteReader();
            string Awardstr = "";
            int k = 1;
            while (odrReader.Read())
            {
                Application.DoEvents();
                Awardstr += k.ToString() + "," + odrReader["award_name"] + "," + odrReader["award_item"] + "," + odrReader["person"] + "," + odrReader["employee_no"] + "," + odrReader["dept_name"] + "\n";
                k++;                
            }
            odrReader.Close();
            odCommand.Dispose();
            odcConnection.Close();
            //读取完毕，保存此文件
            StreamWriter sw = File.CreateText(FilePath);
            sw.Write(Awardstr);  //写入文件中
                sw.Flush();//清理缓冲区
                sw.Close();//关闭文件
            //关闭等待窗
            wait.Close();
            MessageBox.Show("中奖信息保存完成");
            }
        }
        //导出到Excel
        private void Btn_ExploreExcel_Click(object sender, EventArgs e)
        {
            SaveFileDialog exe = new SaveFileDialog();
            exe.Filter = "中奖模板 (*.awd)|*.awd";
            exe.FilterIndex = 0;
            exe.RestoreDirectory = true;            
            exe.Title = "中奖名单模板";
            exe.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            exe.FileName = string.Format("{0}_{1}", DateTime.Now.ToString("HHmmss"), "_中奖名单");
            DialogResult dr = exe.ShowDialog();
            if (dr != DialogResult.OK)
            {
                return;
            }
            //导出
            Stream ms;
            ms = exe.OpenFile();
            StreamWriter sw = new StreamWriter(ms, System.Text.Encoding.UTF8);            
            try
            {
                //弹出等待窗            
                FrmWait wait = new FrmWait();
                wait.TopMost = true;
                wait.StartPosition = FormStartPosition.CenterScreen;
                wait.Show();
                Application.DoEvents();
                //读取数据库，保存文件
                OleDbConnection odcConnection = new OleDbConnection(Common.strConn());
                if (odcConnection.State == System.Data.ConnectionState.Open) odcConnection.Close();
                odcConnection.Open();
                OleDbCommand odCommand = odcConnection.CreateCommand();
                odCommand.CommandText = "select seedlist.award_name,seedlist.award_item,seedlist.person,seedlist.employee_no,employee.barcode from [seedlist] LEFT JOIN [employee] ON seedlist.employee_no = employee.comp_no  where seedlist.award_flag = 1 order by seedlist.award_name asc,seedlist.award_item asc";
                OleDbDataReader odrReader = odCommand.ExecuteReader();
                string Awardstr = "";                
                while (odrReader.Read())
                {
                    Application.DoEvents();
                    Awardstr = odrReader["barcode"] + "\t" + odrReader["person"] + "\t" + odrReader["employee_no"] + "\t" + odrReader["award_name"] + " " + odrReader["award_item"] + "\t" + odrReader["award_name"] + "\n";
                    sw.Write(Awardstr);  //写入文件中                    
                }
                odrReader.Close();
                odCommand.Dispose();
                odcConnection.Close();
                //关闭等待窗
                wait.Close();
                sw.Close();
                ms.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            finally
            {
                sw.Close();
                ms.Close();
            }
            MessageBox.Show("导出中奖名单完成！");
        }
    }
}
