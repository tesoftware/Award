﻿using System;
using System.Windows.Forms;

namespace ConferenceSupport
{
    public partial class FrmSplash : Form
    {
        public FrmSplash()
        {
            InitializeComponent();
        }
        //启动界面
        private void FrmSplash_Load(object sender, EventArgs e)
        {
            Common.WriteLog("软件启动");
        }

    }
}
