﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using System.Runtime.InteropServices;
using System.Data.OleDb;

namespace ConferenceSupport
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }
        public string ProgramName = @"会务活动支持软件 【通用版】";
        #region 内存回收
        [DllImport("kernel32.dll", EntryPoint = "SetProcessWorkingSetSize")]
        public static extern int SetProcessWorkingSetSize(IntPtr process, int minSize, int maxSize);
        /// <summary>
        /// 释放内存
        /// </summary>
        public static void ClearMemory()
        {
            GC.Collect();
            GC.WaitForPendingFinalizers();
            if (Environment.OSVersion.Platform == PlatformID.Win32NT)
            {
                SetProcessWorkingSetSize(System.Diagnostics.Process.GetCurrentProcess().Handle, -1, -1);
            }
        }
        #endregion
        #region 公共函数
        //显示信息
        private void Trace(string msg, int c = 0)
        {
            if (TxtResult.Text.Length > 12000) TxtResult.Text = "";
            TxtResult.AppendText("\r\n");
            string LogTime = System.DateTime.Parse(Convert.ToString(System.DateTime.Now)).ToString("yyyy-MM-dd HH:mm:ss");
            switch (c)
            {
                case 1:
                    this.TxtResult.SelectionColor = Color.FromArgb(107, 170, 255);
                    msg = msg + "     " + LogTime;
                    break;
                case 2:
                    this.TxtResult.SelectionColor = Color.Red;
                    msg = msg + "    " + LogTime;
                    break;
                case 3:
                    this.TxtResult.SelectionColor = Color.FromArgb(0, 255, 18);
                    msg = msg + "     " + LogTime;
                    break;
                case 4:
                    this.TxtResult.SelectionColor = Color.Pink;
                    break;
                case 5:
                    this.TxtResult.SelectionColor = Color.Green;
                    break;
                default:
                    this.TxtResult.SelectionColor = Color.White;
                    break;
            }
            TxtResult.AppendText(msg);
            TxtResult.Select(TxtResult.Text.Length, 1);
            TxtResult.ScrollToCaret();
            this.TxtResult.SelectionColor = Color.White;
        }
        //时钟
        private void ClockTimer_Tick(object sender, EventArgs e)
        {
            ClockShow.Text = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        }       
        #endregion
        #region 窗体
        //窗体启动
        private void FrmMain_Load(object sender, EventArgs e)
        {
            ClearMemory();
            ClockShow.Text = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            TxtResult.SelectionColor = Color.FromArgb(0, 150, 250);
            TxtResult.SelectionFont = new Font("微软雅黑", 12, FontStyle.Bold);
            TxtResult.AppendText(ProgramName);
            Trace("软件所属  焦点科技股份有限公司", 4);
            Trace("程序设计  陆  鹰", 4);
            string ver = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString();
            this.Text = ProgramName + "   " + ver;
            Trace("版    本  " + ver);
            Trace("数据源：" + Common.strConn(),4);
            Trace("启动自检中....................Wait");
            if (ConnectTest() == false)
            {
                MessageBox.Show("数据库连接失败，请检查配置文件是否正确");
                Application.ExitThread();
            }
            else
            {
                //ListView排序
                this.UserListTable.ListViewItemSorter = new CommonListView.ListViewColumnSorter();
                this.UserListTable.ColumnClick += new ColumnClickEventHandler(CommonListView.ListViewHelper.ListView_ColumnClick);
                FrmSplash wait = new FrmSplash();
                wait.TopMost = true;
                wait.StartPosition = FormStartPosition.CenterScreen;
                wait.Show();
                Application.DoEvents();
                //判断数据库是否可以连接
                Trace("系统自检完毕\n");
                ShowAllList("");
                Application.DoEvents();
                System.Threading.Thread.Sleep(100); //暂停执行
                wait.Close();
            }
        }
        //事件处理显示信息
        void frm_TransfEvent(string action_str)
        {
            switch (action_str)
            {
                case "batchin":
                    Trace("导入增加人员信息成功", 1);
                    ShowAllList("");
                    break;
                case "AwardMain":
                    Trace("关闭抽奖窗口", 1);
                    break;
                case "SetupUpdate":
                    Trace("更新配置操作成功", 1);
                    break;
                case "SetupClose":
                    Trace("更新配置结束", 1);
                    break;
                case "close":
                    break;
                case "add":
                    Trace("增加人员信息成功", 1);
                    ShowAllList("");
                    break;
                case "edit":
                    Trace("编辑人员信息成功", 1);
                    ShowAllList("");
                    break;
                case "clear":
                    Trace("清除所有人员信息", 1);
                    ShowAllList("");
                    break;
                case "SetupRestore":
                    Trace("恢复默认设置", 1);
                    break;
                case "ok":
                    Trace("刷新人员信息列表", 1);
                    FrmWait wait = new FrmWait();
                    wait.TopMost = true;
                    wait.StartPosition = FormStartPosition.CenterScreen;
                    wait.Show();
                    ShowAllList("");
                    wait.Close();
                    break;
            }
        }
        //数据库连接测试
        private bool ConnectTest()
        {
            bool result = false;
            try
            {
                OleDbConnection odcConnection = new OleDbConnection(Common.strConn());
                odcConnection.Open();
                OleDbCommand odCommand = odcConnection.CreateCommand();
                odCommand.CommandText = "select COUNT(*) AS result from [employee]";
                OleDbDataReader odrReader = odCommand.ExecuteReader();
                odrReader.Read();
                Trace("数据库连接成功，现存记录 " + odrReader[0].ToString() + "条", 3);
                odCommand.Dispose();
                odrReader.Close();
                odrReader.Dispose();
                result = true;
            }
            catch
            {
                Trace("数据库连接失败", 3);
            }
            return result;
        }
        //窗体关闭
        private void FrmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult result;
            result = MessageBox.Show("确定退出吗？", "退出", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (result == DialogResult.OK)
            {
                Common.WriteLog("软件退出");
                Application.ExitThread();
            }
            else
            {
                e.Cancel = true;
            }
        }
        private void ShowAllList(string keywords)
        {
            Application.DoEvents();
            keywords = Common.CheckSql(keywords); //过滤
            UserListTable.Items.Clear();
            ClearMemory();
            OleDbConnection odcConnection = new OleDbConnection(Common.strConn());
            if (odcConnection.State == System.Data.ConnectionState.Open) odcConnection.Close();
            odcConnection.Open();
            OleDbCommand odCommand = odcConnection.CreateCommand();
            string sql = "select TOP 500 eid,person,comp_no,company_name,remark,spe_flag,award_flag,check_flag,signdate,sales_name,sales_dept from employee where del_flag = '0'";
            switch (keywords){
                case "CheckedList":
                    sql += " and check_flag = '1' ";
                    break;
                case "NoCheckedList":
                    sql += " and check_flag = '0' ";
                    break;
                case "SpecialPersonnel":
                    sql += " and spe_flag = '1' ";
                    break;
                default:
                    if (keywords.Length > 0) sql += " and (person like '%" + keywords + "%' or comp_no like '%" + keywords + "%' or company_name like '%" + keywords + "%' or remark like '%" + keywords + "%' )";                        
                    break;
            }
            //有搜索条件的，加条件搜索
            sql += " order by eid asc";

            odCommand.CommandText = sql;
            OleDbDataReader DBReader = odCommand.ExecuteReader();
            while (DBReader.Read())
                  {
                ListViewItem li = new ListViewItem();
                li.SubItems.Clear();
                li.SubItems[0].Text = DBReader["eid"].ToString();
                li.SubItems.Add(DBReader["person"].ToString());
                li.SubItems.Add(DBReader["comp_no"].ToString().PadLeft(6, '0'));
                li.SubItems.Add(DBReader["company_name"].ToString());
                li.SubItems.Add(DBReader["remark"].ToString());
                li.SubItems.Add((DBReader["spe_flag"].ToString() == "1")?("是"):("否"));
                li.SubItems.Add((DBReader["award_flag"].ToString()== "1")?("是"):("否"));
                li.SubItems.Add((DBReader["check_flag"].ToString()== "1")?("已签到"):("未签到"));
                li.SubItems.Add(Common.DataChange(DBReader["signdate"].ToString()));

                li.SubItems.Add(DBReader["sales_name"].ToString());
                li.SubItems.Add(DBReader["sales_dept"].ToString());
                
                if (DBReader["check_flag"].ToString() == "1")
                {
                    li.UseItemStyleForSubItems = false; //必须设置为用户可编辑
                    li.SubItems[7].ForeColor = Color.Red;
                }
                UserListTable.Items.Add(li);
            }
            Trace("查找结果：" + UserListTable.Items.Count.ToString() + "条", 1);                   
            DBReader.Close();
            odCommand.Dispose(); 
            odcConnection.Close();
            odcConnection.Dispose();

              //如果是全部列表，则计算签到率
            if (keywords.Length == 0)
            {
                sql = "SELECT COUNT(*) AS result FROM employee WHERE del_flag = '0'";
                int Allsum = Int32.Parse(Access.RunSqlToDB(sql));
                if (Allsum > 0)
                {
                    sql = "SELECT COUNT(*) AS result FROM employee WHERE del_flag = '0' and check_flag = '1'";
                    string s = Access.RunSqlToDB(sql);
                    float bfb = Convert.ToSingle(Int32.Parse(s)) / Convert.ToSingle(Allsum) * 100;
                    Trace("应到：" + Allsum.ToString() + " 名，实到：" + s.ToString() + " 名，签到率：" + bfb.ToString() + "%", 3);
                    lab_GZD.Text = Math.Round(bfb, 2).ToString() + "%";
                }else{
                    lab_GZD.Text = "0" + "%";
                }
            }
        }
        #endregion
        #region 按钮
        //显示全部按钮
        private void BtnTableRelist_Click(object sender, EventArgs e)
        {
            Trace("显示全部人员", 4);
            FrmWait wait = new FrmWait();
            wait.TopMost = true;
            wait.StartPosition = FormStartPosition.CenterScreen;
            wait.Show();
            ShowAllList("");
            wait.Close();
        }
        //搜索按钮
        private void BtnSearch_Click(object sender, EventArgs e)
        {
            string keywords = Common.CheckSql(TxtKeywords.Text);
            if (keywords == "")
            {
                Trace("请填写搜索关键字",2);
                return;
            }
            Trace("根据关键字查询列表", 4);
            FrmWait wait = new FrmWait();
            wait.TopMost = true;
            wait.StartPosition = FormStartPosition.CenterScreen;
            wait.Show();
            ShowAllList(keywords);
            wait.Close();
        }        
        //已签到列表
        private void BtnCheckedList_Click(object sender, EventArgs e)
        {
            Trace("查询已签到人员列表", 4);
            FrmWait wait = new FrmWait();
            wait.TopMost = true;
            wait.StartPosition = FormStartPosition.CenterScreen;
            wait.Show();
            ShowAllList("CheckedList");
            wait.Close();
        }        
        //未签到列表
        private void BtnNoCheckedList_Click(object sender, EventArgs e)
        {
            Trace("查询未签到人员列表", 4);
            FrmWait wait = new FrmWait();
            wait.TopMost = true;
            wait.StartPosition = FormStartPosition.CenterScreen;
            wait.Show();
            ShowAllList("NoCheckedList");
            wait.Close();
        }
        //特殊人员
        private void BtnSpe_Click(object sender, EventArgs e)
        {
            Trace("查询特殊人员列表", 4);
            FrmWait wait = new FrmWait();
            wait.TopMost = true;
            wait.StartPosition = FormStartPosition.CenterScreen;
            wait.Show();
            ShowAllList("SpecialPersonnel");
            wait.Close();
        }
        //双击编辑人员
        private void UserListTable_DoubleClick(object sender, EventArgs e)
        {
            string eid = UserListTable.SelectedItems[0].SubItems[0].Text.Trim();
            FrmUserEdit frmuseradd = new FrmUserEdit();
            frmuseradd.TransfEvent += frm_TransfEvent;
            frmuseradd.StartPosition = FormStartPosition.Manual;
            frmuseradd.Personeid = eid;
            int fm_x, fm_y;
            fm_x = this.Location.X + (this.Width / 2) - (frmuseradd.Width / 2);
            fm_y = this.Location.Y + (this.Height / 2) - (frmuseradd.Height / 2);
            frmuseradd.Location = new Point(fm_x, fm_y);
            frmuseradd.ShowDialog(this);   
        }
        #endregion
        #region 主菜单
        //退出软件
        private void BtnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //数据管理
        private void BtnMain_Click(object sender, EventArgs e)
        {
            FrmUserEdit frmuseradd = new FrmUserEdit();
            frmuseradd.TransfEvent += frm_TransfEvent;
            frmuseradd.StartPosition = FormStartPosition.Manual;
            frmuseradd.Personeid = "0";
            int fm_x, fm_y;
            fm_x = this.Location.X + (this.Width / 2) - (frmuseradd.Width / 2);
            fm_y = this.Location.Y + (this.Height / 2) - (frmuseradd.Height / 2);
            frmuseradd.Location = new Point(fm_x, fm_y);
            frmuseradd.ShowDialog(this);
        }
        //参会签到
        private void BtnMeetingList_Click(object sender, EventArgs e)
        {
            FrmSignIn frmsignin = new FrmSignIn();
            frmsignin.TransfEvent += frm_TransfEvent;
            frmsignin.StartPosition = FormStartPosition.Manual;
            frmsignin.ShowDialog(this);   
        }
        //系统配置
        private void BtnSetup_Click(object sender, EventArgs e)
        {
            FrmSetup frmsetup = new FrmSetup();
            frmsetup.TransfEvent += frm_TransfEvent;
            frmsetup.StartPosition = FormStartPosition.Manual;            
            int fm_x, fm_y;
            fm_x = this.Location.X + (this.Width / 2) - (frmsetup.Width / 2);
            fm_y = this.Location.Y + (this.Height / 2) - (frmsetup.Height / 2);
            frmsetup.Location = new Point(fm_x, fm_y);
            frmsetup.ShowDialog(this);  
        }
        //进入关于软件
        private void BtnAbout_Click(object sender, EventArgs e)
        {
            AboutBox aboutbox = new AboutBox();            
            aboutbox.StartPosition = FormStartPosition.Manual;            
            int fm_x, fm_y;
            fm_x = this.Location.X + (this.Width / 2) - (aboutbox.Width / 2);
            fm_y = this.Location.Y + (this.Height / 2) - (aboutbox.Height / 2);
            aboutbox.Location = new Point(fm_x, fm_y);
            aboutbox.ShowDialog(this);
        }
        //进入抽奖
        private void BtnAward_Click(object sender, EventArgs e)
        {
            FrmAwardMain frmawardmain = new FrmAwardMain();
            frmawardmain.TransfEvent += frm_TransfEvent;
            frmawardmain.StartPosition = FormStartPosition.Manual;
            frmawardmain.ShowDialog(this);
        }
        #endregion



    }
}
