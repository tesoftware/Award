﻿namespace ConferenceSupport
{
    partial class FrmAwardMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmAwardMain));
            this.BtnItemSelect = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.AwarditemList = new System.Windows.Forms.ListView();
            this.ID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.AwardStyle = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.AwardPage = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Awarditem = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.LabMessageInfo = new System.Windows.Forms.Label();
            this.labelExit = new System.Windows.Forms.Label();
            this.BtnItemSelect.SuspendLayout();
            this.SuspendLayout();
            // 
            // BtnItemSelect
            // 
            this.BtnItemSelect.Controls.Add(this.button1);
            this.BtnItemSelect.Controls.Add(this.AwarditemList);
            this.BtnItemSelect.Controls.Add(this.LabMessageInfo);
            this.BtnItemSelect.Location = new System.Drawing.Point(79, 66);
            this.BtnItemSelect.Name = "BtnItemSelect";
            this.BtnItemSelect.Size = new System.Drawing.Size(840, 520);
            this.BtnItemSelect.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("微软雅黑", 14F);
            this.button1.Location = new System.Drawing.Point(329, 477);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(182, 40);
            this.button1.TabIndex = 23;
            this.button1.Text = "确   定";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // AwarditemList
            // 
            this.AwarditemList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ID,
            this.AwardStyle,
            this.AwardPage,
            this.Awarditem});
            this.AwarditemList.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AwarditemList.Font = new System.Drawing.Font("微软雅黑", 14F);
            this.AwarditemList.ForeColor = System.Drawing.Color.Black;
            this.AwarditemList.FullRowSelect = true;
            this.AwarditemList.GridLines = true;
            this.AwarditemList.HideSelection = false;
            this.AwarditemList.Location = new System.Drawing.Point(9, 45);
            this.AwarditemList.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.AwarditemList.Name = "AwarditemList";
            this.AwarditemList.Size = new System.Drawing.Size(822, 425);
            this.AwarditemList.TabIndex = 22;
            this.AwarditemList.UseCompatibleStateImageBehavior = false;
            this.AwarditemList.View = System.Windows.Forms.View.Details;
            this.AwarditemList.ColumnWidthChanging += new System.Windows.Forms.ColumnWidthChangingEventHandler(this.AwarditemList_ColumnWidthChanging);
            this.AwarditemList.Click += new System.EventHandler(this.AwarditemList_Click);
            // 
            // ID
            // 
            this.ID.Text = "ID";
            this.ID.Width = 0;
            // 
            // AwardStyle
            // 
            this.AwardStyle.Text = "奖项";
            this.AwardStyle.Width = 229;
            // 
            // AwardPage
            // 
            this.AwardPage.Text = "屏显人数";
            this.AwardPage.Width = 0;
            // 
            // Awarditem
            // 
            this.Awarditem.Text = "奖项功能说明";
            this.Awarditem.Width = 556;
            // 
            // LabMessageInfo
            // 
            this.LabMessageInfo.Font = new System.Drawing.Font("微软雅黑", 18F, System.Drawing.FontStyle.Bold);
            this.LabMessageInfo.Location = new System.Drawing.Point(279, 1);
            this.LabMessageInfo.Name = "LabMessageInfo";
            this.LabMessageInfo.Size = new System.Drawing.Size(282, 40);
            this.LabMessageInfo.TabIndex = 24;
            this.LabMessageInfo.Text = "主选单";
            this.LabMessageInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelExit
            // 
            this.labelExit.BackColor = System.Drawing.Color.Transparent;
            this.labelExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.labelExit.Image = ((System.Drawing.Image)(resources.GetObject("labelExit.Image")));
            this.labelExit.Location = new System.Drawing.Point(0, 0);
            this.labelExit.Name = "labelExit";
            this.labelExit.Size = new System.Drawing.Size(32, 32);
            this.labelExit.TabIndex = 9;
            this.labelExit.Click += new System.EventHandler(this.labelExit_Click);
            // 
            // FrmAwardMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1024, 768);
            this.Controls.Add(this.labelExit);
            this.Controls.Add(this.BtnItemSelect);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmAwardMain";
            this.ShowInTaskbar = false;
            this.Text = "FrmAwardMain";
            this.Load += new System.EventHandler(this.FrmAwardMain_Load);
            this.BtnItemSelect.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel BtnItemSelect;
        private System.Windows.Forms.Label labelExit;
        private System.Windows.Forms.ListView AwarditemList;
        private System.Windows.Forms.ColumnHeader ID;
        private System.Windows.Forms.ColumnHeader AwardStyle;
        private System.Windows.Forms.ColumnHeader AwardPage;
        private System.Windows.Forms.ColumnHeader Awarditem;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label LabMessageInfo;
    }
}