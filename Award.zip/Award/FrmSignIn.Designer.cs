﻿namespace ConferenceSupport
{
    partial class FrmSignIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmSignIn));
            this.BackBoard = new System.Windows.Forms.Panel();
            this.LabSalesDept = new System.Windows.Forms.Label();
            this.LabSales = new System.Windows.Forms.Label();
            this.ScannerText = new System.Windows.Forms.TextBox();
            this.LabDeptname = new System.Windows.Forms.Label();
            this.LabUsername = new System.Windows.Forms.Label();
            this.LabMessageInfo = new System.Windows.Forms.Label();
            this.BtnExit = new System.Windows.Forms.Label();
            this.ClearTimer = new System.Windows.Forms.Timer(this.components);
            this.BackBoard.SuspendLayout();
            this.SuspendLayout();
            // 
            // BackBoard
            // 
            this.BackBoard.Controls.Add(this.LabUsername);
            this.BackBoard.Controls.Add(this.LabSalesDept);
            this.BackBoard.Controls.Add(this.LabSales);
            this.BackBoard.Controls.Add(this.ScannerText);
            this.BackBoard.Controls.Add(this.LabDeptname);
            this.BackBoard.Controls.Add(this.LabMessageInfo);
            this.BackBoard.Location = new System.Drawing.Point(2, -1);
            this.BackBoard.Name = "BackBoard";
            this.BackBoard.Size = new System.Drawing.Size(1920, 1080);
            this.BackBoard.TabIndex = 0;
            // 
            // LabSalesDept
            // 
            this.LabSalesDept.BackColor = System.Drawing.Color.Transparent;
            this.LabSalesDept.Font = new System.Drawing.Font("微软雅黑", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.LabSalesDept.ForeColor = System.Drawing.SystemColors.ControlText;
            this.LabSalesDept.Location = new System.Drawing.Point(279, 871);
            this.LabSalesDept.Name = "LabSalesDept";
            this.LabSalesDept.Size = new System.Drawing.Size(1420, 34);
            this.LabSalesDept.TabIndex = 5;
            this.LabSalesDept.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LabSales
            // 
            this.LabSales.BackColor = System.Drawing.Color.Transparent;
            this.LabSales.Font = new System.Drawing.Font("微软雅黑", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.LabSales.ForeColor = System.Drawing.SystemColors.ControlText;
            this.LabSales.Location = new System.Drawing.Point(279, 811);
            this.LabSales.Name = "LabSales";
            this.LabSales.Size = new System.Drawing.Size(1420, 34);
            this.LabSales.TabIndex = 4;
            this.LabSales.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ScannerText
            // 
            this.ScannerText.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ScannerText.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ScannerText.Location = new System.Drawing.Point(22, 3);
            this.ScannerText.Name = "ScannerText";
            this.ScannerText.Size = new System.Drawing.Size(230, 16);
            this.ScannerText.TabIndex = 3;
            this.ScannerText.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ScannerText_KeyPress);
            // 
            // LabDeptname
            // 
            this.LabDeptname.BackColor = System.Drawing.Color.Transparent;
            this.LabDeptname.Font = new System.Drawing.Font("微软雅黑", 43.75F);
            this.LabDeptname.Location = new System.Drawing.Point(279, 655);
            this.LabDeptname.Name = "LabDeptname";
            this.LabDeptname.Size = new System.Drawing.Size(1420, 110);
            this.LabDeptname.TabIndex = 2;
            this.LabDeptname.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LabUsername
            // 
            this.LabUsername.BackColor = System.Drawing.Color.Transparent;
            this.LabUsername.Font = new System.Drawing.Font("微软雅黑", 63.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.LabUsername.Location = new System.Drawing.Point(279, 509);
            this.LabUsername.Name = "LabUsername";
            this.LabUsername.Size = new System.Drawing.Size(1420, 110);
            this.LabUsername.TabIndex = 1;
            this.LabUsername.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LabMessageInfo
            // 
            this.LabMessageInfo.BackColor = System.Drawing.Color.Transparent;
            this.LabMessageInfo.Font = new System.Drawing.Font("微软雅黑", 60F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.LabMessageInfo.Location = new System.Drawing.Point(0, 283);
            this.LabMessageInfo.Name = "LabMessageInfo";
            this.LabMessageInfo.Size = new System.Drawing.Size(1920, 100);
            this.LabMessageInfo.TabIndex = 0;
            this.LabMessageInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BtnExit
            // 
            this.BtnExit.BackColor = System.Drawing.Color.Transparent;
            this.BtnExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnExit.Image = ((System.Drawing.Image)(resources.GetObject("BtnExit.Image")));
            this.BtnExit.Location = new System.Drawing.Point(0, -1);
            this.BtnExit.Name = "BtnExit";
            this.BtnExit.Size = new System.Drawing.Size(33, 33);
            this.BtnExit.TabIndex = 3;
            this.BtnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // ClearTimer
            // 
            this.ClearTimer.Interval = 500;
            this.ClearTimer.Tick += new System.EventHandler(this.ClearTimer_Tick);
            // 
            // FrmSignIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1920, 1080);
            this.Controls.Add(this.BtnExit);
            this.Controls.Add(this.BackBoard);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmSignIn";
            this.Text = "FrmSignIn";
            this.Load += new System.EventHandler(this.FrmSignIn_Load);
            this.BackBoard.ResumeLayout(false);
            this.BackBoard.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel BackBoard;
        private System.Windows.Forms.Label LabDeptname;
        private System.Windows.Forms.Label LabUsername;
        private System.Windows.Forms.Label LabMessageInfo;
        private System.Windows.Forms.Label BtnExit;
        private System.Windows.Forms.TextBox ScannerText;
        private System.Windows.Forms.Timer ClearTimer;
        private System.Windows.Forms.Label LabSalesDept;
        private System.Windows.Forms.Label LabSales;
    }
}