﻿namespace ConferenceSupport
{
    partial class FrmUserEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmUserEdit));
            this.BtnCloseFrm = new System.Windows.Forms.Button();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.TabUserDushboard = new System.Windows.Forms.TabControl();
            this.Page1 = new System.Windows.Forms.TabPage();
            this.BtnAddNew = new System.Windows.Forms.Button();
            this.chkdel_flag = new System.Windows.Forms.CheckBox();
            this.GroupBox = new System.Windows.Forms.GroupBox();
            this.txtsalesdept = new System.Windows.Forms.TextBox();
            this.txtsales = new System.Windows.Forms.TextBox();
            this.txtremark = new System.Windows.Forms.TextBox();
            this.chkok_flag = new System.Windows.Forms.CheckBox();
            this.chkcheck_flag = new System.Windows.Forms.CheckBox();
            this.chkspe_flag = new System.Windows.Forms.CheckBox();
            this.chkaward_flag = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtbarcode = new System.Windows.Forms.TextBox();
            this.txtcomp_no = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtcompany_name = new System.Windows.Forms.TextBox();
            this.txtPerson = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Page2 = new System.Windows.Forms.TabPage();
            this.BtnAllSign = new System.Windows.Forms.Button();
            this.LabDatashow = new System.Windows.Forms.Label();
            this.BroupGuest = new System.Windows.Forms.GroupBox();
            this.GuestUpload = new System.Windows.Forms.Button();
            this.GuestRenew = new System.Windows.Forms.Button();
            this.GuestListCom = new System.Windows.Forms.ComboBox();
            this.GetGuestList = new System.Windows.Forms.Button();
            this.BtnDataRepoet = new System.Windows.Forms.Button();
            this.BroupAreaFroWebService = new System.Windows.Forms.GroupBox();
            this.StrWebUrl = new System.Windows.Forms.ComboBox();
            this.BtnPostToOSS = new System.Windows.Forms.Button();
            this.txtmeeting_id = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.BtnGetWebRequest = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.BtnExplort = new System.Windows.Forms.Button();
            this.BtnClearList = new System.Windows.Forms.Button();
            this.BtnCloseSec = new System.Windows.Forms.Button();
            this.BroupAreaSynchronize = new System.Windows.Forms.GroupBox();
            this.Labmsg = new System.Windows.Forms.Label();
            this.ProgressBarLOC = new System.Windows.Forms.ProgressBar();
            this.BtnSynchronize = new System.Windows.Forms.Button();
            this.TabUserDushboard.SuspendLayout();
            this.Page1.SuspendLayout();
            this.GroupBox.SuspendLayout();
            this.Page2.SuspendLayout();
            this.BroupGuest.SuspendLayout();
            this.BroupAreaFroWebService.SuspendLayout();
            this.BroupAreaSynchronize.SuspendLayout();
            this.SuspendLayout();
            // 
            // BtnCloseFrm
            // 
            this.BtnCloseFrm.Location = new System.Drawing.Point(461, 334);
            this.BtnCloseFrm.Name = "BtnCloseFrm";
            this.BtnCloseFrm.Size = new System.Drawing.Size(100, 30);
            this.BtnCloseFrm.TabIndex = 45;
            this.BtnCloseFrm.Text = "关  闭";
            this.BtnCloseFrm.UseVisualStyleBackColor = true;
            this.BtnCloseFrm.Click += new System.EventHandler(this.BtnCloseFrm_Click);
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(330, 334);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(126, 30);
            this.btnSubmit.TabIndex = 10;
            this.btnSubmit.Text = "修改人员信息";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // TabUserDushboard
            // 
            this.TabUserDushboard.Controls.Add(this.Page1);
            this.TabUserDushboard.Controls.Add(this.Page2);
            this.TabUserDushboard.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TabUserDushboard.ItemSize = new System.Drawing.Size(84, 30);
            this.TabUserDushboard.Location = new System.Drawing.Point(0, 0);
            this.TabUserDushboard.Name = "TabUserDushboard";
            this.TabUserDushboard.SelectedIndex = 0;
            this.TabUserDushboard.Size = new System.Drawing.Size(582, 423);
            this.TabUserDushboard.TabIndex = 47;
            // 
            // Page1
            // 
            this.Page1.BackColor = System.Drawing.SystemColors.Control;
            this.Page1.Controls.Add(this.BtnAddNew);
            this.Page1.Controls.Add(this.chkdel_flag);
            this.Page1.Controls.Add(this.btnSubmit);
            this.Page1.Controls.Add(this.BtnCloseFrm);
            this.Page1.Controls.Add(this.GroupBox);
            this.Page1.Location = new System.Drawing.Point(4, 34);
            this.Page1.Name = "Page1";
            this.Page1.Padding = new System.Windows.Forms.Padding(3);
            this.Page1.Size = new System.Drawing.Size(574, 385);
            this.Page1.TabIndex = 0;
            this.Page1.Text = "  用户编辑  ";
            // 
            // BtnAddNew
            // 
            this.BtnAddNew.Location = new System.Drawing.Point(8, 334);
            this.BtnAddNew.Name = "BtnAddNew";
            this.BtnAddNew.Size = new System.Drawing.Size(126, 30);
            this.BtnAddNew.TabIndex = 49;
            this.BtnAddNew.Text = "增加新人员";
            this.BtnAddNew.UseVisualStyleBackColor = true;
            this.BtnAddNew.Click += new System.EventHandler(this.BtnAddNew_Click);
            // 
            // chkdel_flag
            // 
            this.chkdel_flag.AutoSize = true;
            this.chkdel_flag.ForeColor = System.Drawing.Color.Red;
            this.chkdel_flag.Location = new System.Drawing.Point(242, 342);
            this.chkdel_flag.Name = "chkdel_flag";
            this.chkdel_flag.Size = new System.Drawing.Size(72, 16);
            this.chkdel_flag.TabIndex = 48;
            this.chkdel_flag.Text = "是否删除";
            this.chkdel_flag.UseVisualStyleBackColor = true;
            this.chkdel_flag.Visible = false;
            // 
            // GroupBox
            // 
            this.GroupBox.Controls.Add(this.txtsalesdept);
            this.GroupBox.Controls.Add(this.txtsales);
            this.GroupBox.Controls.Add(this.txtremark);
            this.GroupBox.Controls.Add(this.chkok_flag);
            this.GroupBox.Controls.Add(this.chkcheck_flag);
            this.GroupBox.Controls.Add(this.chkspe_flag);
            this.GroupBox.Controls.Add(this.chkaward_flag);
            this.GroupBox.Controls.Add(this.label5);
            this.GroupBox.Controls.Add(this.txtbarcode);
            this.GroupBox.Controls.Add(this.txtcomp_no);
            this.GroupBox.Controls.Add(this.label3);
            this.GroupBox.Controls.Add(this.txtcompany_name);
            this.GroupBox.Controls.Add(this.txtPerson);
            this.GroupBox.Controls.Add(this.label9);
            this.GroupBox.Controls.Add(this.label10);
            this.GroupBox.Controls.Add(this.label6);
            this.GroupBox.Controls.Add(this.label4);
            this.GroupBox.Controls.Add(this.label2);
            this.GroupBox.Controls.Add(this.label1);
            this.GroupBox.Location = new System.Drawing.Point(8, 15);
            this.GroupBox.Name = "GroupBox";
            this.GroupBox.Size = new System.Drawing.Size(553, 306);
            this.GroupBox.TabIndex = 47;
            this.GroupBox.TabStop = false;
            this.GroupBox.Text = "用户信息";
            // 
            // txtsalesdept
            // 
            this.txtsalesdept.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtsalesdept.Location = new System.Drawing.Point(87, 204);
            this.txtsalesdept.Name = "txtsalesdept";
            this.txtsalesdept.Size = new System.Drawing.Size(386, 21);
            this.txtsalesdept.TabIndex = 15;
            // 
            // txtsales
            // 
            this.txtsales.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtsales.Location = new System.Drawing.Point(87, 171);
            this.txtsales.Name = "txtsales";
            this.txtsales.Size = new System.Drawing.Size(137, 21);
            this.txtsales.TabIndex = 14;
            // 
            // txtremark
            // 
            this.txtremark.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtremark.Location = new System.Drawing.Point(87, 138);
            this.txtremark.Name = "txtremark";
            this.txtremark.Size = new System.Drawing.Size(386, 21);
            this.txtremark.TabIndex = 5;
            // 
            // chkok_flag
            // 
            this.chkok_flag.AutoSize = true;
            this.chkok_flag.Location = new System.Drawing.Point(271, 272);
            this.chkok_flag.Name = "chkok_flag";
            this.chkok_flag.Size = new System.Drawing.Size(144, 16);
            this.chkok_flag.TabIndex = 9;
            this.chkok_flag.Text = "是否已领取活动纪念品";
            this.chkok_flag.UseVisualStyleBackColor = true;
            this.chkok_flag.Visible = false;
            // 
            // chkcheck_flag
            // 
            this.chkcheck_flag.AutoSize = true;
            this.chkcheck_flag.Location = new System.Drawing.Point(271, 239);
            this.chkcheck_flag.Name = "chkcheck_flag";
            this.chkcheck_flag.Size = new System.Drawing.Size(108, 16);
            this.chkcheck_flag.TabIndex = 7;
            this.chkcheck_flag.Text = "是否已会场签到";
            this.chkcheck_flag.UseVisualStyleBackColor = true;
            // 
            // chkspe_flag
            // 
            this.chkspe_flag.AutoSize = true;
            this.chkspe_flag.Location = new System.Drawing.Point(87, 272);
            this.chkspe_flag.Name = "chkspe_flag";
            this.chkspe_flag.Size = new System.Drawing.Size(96, 16);
            this.chkspe_flag.TabIndex = 8;
            this.chkspe_flag.Text = "是否特别关注";
            this.chkspe_flag.UseVisualStyleBackColor = true;
            // 
            // chkaward_flag
            // 
            this.chkaward_flag.AutoSize = true;
            this.chkaward_flag.Location = new System.Drawing.Point(87, 239);
            this.chkaward_flag.Name = "chkaward_flag";
            this.chkaward_flag.Size = new System.Drawing.Size(96, 16);
            this.chkaward_flag.TabIndex = 6;
            this.chkaward_flag.Text = "是否参加抽奖";
            this.chkaward_flag.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Tomato;
            this.label5.Location = new System.Drawing.Point(479, 108);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 12);
            this.label5.TabIndex = 7;
            this.label5.Text = "*重要标识";
            // 
            // txtbarcode
            // 
            this.txtbarcode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtbarcode.Location = new System.Drawing.Point(87, 105);
            this.txtbarcode.Name = "txtbarcode";
            this.txtbarcode.Size = new System.Drawing.Size(386, 21);
            this.txtbarcode.TabIndex = 4;
            // 
            // txtcomp_no
            // 
            this.txtcomp_no.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtcomp_no.Location = new System.Drawing.Point(336, 37);
            this.txtcomp_no.Name = "txtcomp_no";
            this.txtcomp_no.Size = new System.Drawing.Size(137, 21);
            this.txtcomp_no.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(251, 40);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 12);
            this.label3.TabIndex = 4;
            this.label3.Text = "编号（工号）：";
            // 
            // txtcompany_name
            // 
            this.txtcompany_name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtcompany_name.Location = new System.Drawing.Point(87, 71);
            this.txtcompany_name.Name = "txtcompany_name";
            this.txtcompany_name.Size = new System.Drawing.Size(386, 21);
            this.txtcompany_name.TabIndex = 3;
            // 
            // txtPerson
            // 
            this.txtPerson.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPerson.Location = new System.Drawing.Point(87, 37);
            this.txtPerson.Name = "txtPerson";
            this.txtPerson.Size = new System.Drawing.Size(137, 21);
            this.txtPerson.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(26, 210);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 12);
            this.label9.TabIndex = 17;
            this.label9.Text = "所属部门：";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(26, 177);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 12);
            this.label10.TabIndex = 16;
            this.label10.Text = "对接销售：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(50, 142);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 12);
            this.label6.TabIndex = 13;
            this.label6.Text = "备注：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 106);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 12);
            this.label4.TabIndex = 6;
            this.label4.Text = "二维码字串：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "公司名称：";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "用户姓名：";
            // 
            // Page2
            // 
            this.Page2.BackColor = System.Drawing.SystemColors.Control;
            this.Page2.Controls.Add(this.BtnAllSign);
            this.Page2.Controls.Add(this.LabDatashow);
            this.Page2.Controls.Add(this.BroupGuest);
            this.Page2.Controls.Add(this.BtnDataRepoet);
            this.Page2.Controls.Add(this.BroupAreaFroWebService);
            this.Page2.Controls.Add(this.BtnExplort);
            this.Page2.Controls.Add(this.BtnClearList);
            this.Page2.Controls.Add(this.BtnCloseSec);
            this.Page2.Controls.Add(this.BroupAreaSynchronize);
            this.Page2.Location = new System.Drawing.Point(4, 34);
            this.Page2.Name = "Page2";
            this.Page2.Padding = new System.Windows.Forms.Padding(13);
            this.Page2.Size = new System.Drawing.Size(574, 385);
            this.Page2.TabIndex = 1;
            this.Page2.Text = "  参会人员数据管理  ";
            // 
            // BtnAllSign
            // 
            this.BtnAllSign.ForeColor = System.Drawing.Color.Red;
            this.BtnAllSign.Location = new System.Drawing.Point(327, 282);
            this.BtnAllSign.Name = "BtnAllSign";
            this.BtnAllSign.Size = new System.Drawing.Size(105, 28);
            this.BtnAllSign.TabIndex = 53;
            this.BtnAllSign.Text = "全设为可抽奖";
            this.BtnAllSign.UseVisualStyleBackColor = true;
            this.BtnAllSign.Click += new System.EventHandler(this.BtnAllSign_Click);
            // 
            // LabDatashow
            // 
            this.LabDatashow.ForeColor = System.Drawing.Color.DarkRed;
            this.LabDatashow.Location = new System.Drawing.Point(8, 319);
            this.LabDatashow.Name = "LabDatashow";
            this.LabDatashow.Size = new System.Drawing.Size(549, 53);
            this.LabDatashow.TabIndex = 51;
            this.LabDatashow.Text = "数据管理";
            // 
            // BroupGuest
            // 
            this.BroupGuest.Controls.Add(this.GuestUpload);
            this.BroupGuest.Controls.Add(this.GuestRenew);
            this.BroupGuest.Controls.Add(this.GuestListCom);
            this.BroupGuest.Controls.Add(this.GetGuestList);
            this.BroupGuest.Location = new System.Drawing.Point(8, 108);
            this.BroupGuest.Name = "BroupGuest";
            this.BroupGuest.Size = new System.Drawing.Size(554, 70);
            this.BroupGuest.TabIndex = 52;
            this.BroupGuest.TabStop = false;
            this.BroupGuest.Text = "从OA \"活动会议“模块同步数据";
            // 
            // GuestUpload
            // 
            this.GuestUpload.Location = new System.Drawing.Point(445, 25);
            this.GuestUpload.Name = "GuestUpload";
            this.GuestUpload.Size = new System.Drawing.Size(100, 28);
            this.GuestUpload.TabIndex = 11;
            this.GuestUpload.Text = "上报签到数据";
            this.GuestUpload.UseVisualStyleBackColor = true;
            this.GuestUpload.Click += new System.EventHandler(this.GuestUpload_Click);
            // 
            // GuestRenew
            // 
            this.GuestRenew.Location = new System.Drawing.Point(6, 25);
            this.GuestRenew.Name = "GuestRenew";
            this.GuestRenew.Size = new System.Drawing.Size(70, 28);
            this.GuestRenew.TabIndex = 10;
            this.GuestRenew.Text = "获取会议";
            this.GuestRenew.UseVisualStyleBackColor = true;
            this.GuestRenew.Click += new System.EventHandler(this.GuestRenew_Click);
            // 
            // GuestListCom
            // 
            this.GuestListCom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.GuestListCom.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.GuestListCom.FormattingEnabled = true;
            this.GuestListCom.Location = new System.Drawing.Point(82, 25);
            this.GuestListCom.Name = "GuestListCom";
            this.GuestListCom.Size = new System.Drawing.Size(254, 28);
            this.GuestListCom.TabIndex = 9;
            // 
            // GetGuestList
            // 
            this.GetGuestList.Location = new System.Drawing.Point(342, 25);
            this.GetGuestList.Name = "GetGuestList";
            this.GetGuestList.Size = new System.Drawing.Size(100, 28);
            this.GetGuestList.TabIndex = 0;
            this.GetGuestList.Text = "下载人员数据";
            this.GetGuestList.UseVisualStyleBackColor = true;
            this.GetGuestList.Click += new System.EventHandler(this.GetGuestList_Click);
            // 
            // BtnDataRepoet
            // 
            this.BtnDataRepoet.Location = new System.Drawing.Point(221, 282);
            this.BtnDataRepoet.Name = "BtnDataRepoet";
            this.BtnDataRepoet.Size = new System.Drawing.Size(100, 28);
            this.BtnDataRepoet.TabIndex = 50;
            this.BtnDataRepoet.Text = "数据统计";
            this.BtnDataRepoet.UseVisualStyleBackColor = true;
            this.BtnDataRepoet.Click += new System.EventHandler(this.BtnDataRepoet_Click);
            // 
            // BroupAreaFroWebService
            // 
            this.BroupAreaFroWebService.Controls.Add(this.StrWebUrl);
            this.BroupAreaFroWebService.Controls.Add(this.BtnPostToOSS);
            this.BroupAreaFroWebService.Controls.Add(this.txtmeeting_id);
            this.BroupAreaFroWebService.Controls.Add(this.label7);
            this.BroupAreaFroWebService.Controls.Add(this.BtnGetWebRequest);
            this.BroupAreaFroWebService.Controls.Add(this.label8);
            this.BroupAreaFroWebService.Location = new System.Drawing.Point(5, 184);
            this.BroupAreaFroWebService.Name = "BroupAreaFroWebService";
            this.BroupAreaFroWebService.Size = new System.Drawing.Size(554, 92);
            this.BroupAreaFroWebService.TabIndex = 49;
            this.BroupAreaFroWebService.TabStop = false;
            this.BroupAreaFroWebService.Text = "从MIC服务端同步数据";
            this.BroupAreaFroWebService.Visible = false;
            // 
            // StrWebUrl
            // 
            this.StrWebUrl.FormattingEnabled = true;
            this.StrWebUrl.Items.AddRange(new object[] {
            "http://sales.vemic.com/conferenceQrSignIn.sg?method=getEnrolmentCustom&keyValue="});
            this.StrWebUrl.Location = new System.Drawing.Point(6, 24);
            this.StrWebUrl.Name = "StrWebUrl";
            this.StrWebUrl.Size = new System.Drawing.Size(279, 20);
            this.StrWebUrl.TabIndex = 8;
            // 
            // BtnPostToOSS
            // 
            this.BtnPostToOSS.Location = new System.Drawing.Point(448, 57);
            this.BtnPostToOSS.Name = "BtnPostToOSS";
            this.BtnPostToOSS.Size = new System.Drawing.Size(100, 28);
            this.BtnPostToOSS.TabIndex = 52;
            this.BtnPostToOSS.Text = "提交结果到OSS";
            this.BtnPostToOSS.UseVisualStyleBackColor = true;
            this.BtnPostToOSS.Click += new System.EventHandler(this.BtnPostToOSS_Click);
            // 
            // txtmeeting_id
            // 
            this.txtmeeting_id.Location = new System.Drawing.Point(338, 23);
            this.txtmeeting_id.Name = "txtmeeting_id";
            this.txtmeeting_id.Size = new System.Drawing.Size(104, 21);
            this.txtmeeting_id.TabIndex = 6;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.label7.Location = new System.Drawing.Point(6, 53);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(197, 12);
            this.label7.TabIndex = 4;
            this.label7.Text = "请选择填写服务端地址获取用户数据";
            // 
            // BtnGetWebRequest
            // 
            this.BtnGetWebRequest.Location = new System.Drawing.Point(448, 23);
            this.BtnGetWebRequest.Name = "BtnGetWebRequest";
            this.BtnGetWebRequest.Size = new System.Drawing.Size(100, 28);
            this.BtnGetWebRequest.TabIndex = 0;
            this.BtnGetWebRequest.Text = "获取用户数据";
            this.BtnGetWebRequest.UseVisualStyleBackColor = true;
            this.BtnGetWebRequest.Click += new System.EventHandler(this.BtnGetWebRequest_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(291, 27);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 12);
            this.label8.TabIndex = 7;
            this.label8.Text = "会议ID：";
            // 
            // BtnExplort
            // 
            this.BtnExplort.Location = new System.Drawing.Point(115, 282);
            this.BtnExplort.Name = "BtnExplort";
            this.BtnExplort.Size = new System.Drawing.Size(100, 28);
            this.BtnExplort.TabIndex = 48;
            this.BtnExplort.Text = "导出人员列表";
            this.BtnExplort.UseVisualStyleBackColor = true;
            this.BtnExplort.Click += new System.EventHandler(this.BtnExplort_Click);
            // 
            // BtnClearList
            // 
            this.BtnClearList.ForeColor = System.Drawing.Color.Red;
            this.BtnClearList.Location = new System.Drawing.Point(9, 282);
            this.BtnClearList.Name = "BtnClearList";
            this.BtnClearList.Size = new System.Drawing.Size(100, 28);
            this.BtnClearList.TabIndex = 47;
            this.BtnClearList.Text = "清除所有人员";
            this.BtnClearList.UseVisualStyleBackColor = true;
            this.BtnClearList.Click += new System.EventHandler(this.BtnClearList_Click);
            // 
            // BtnCloseSec
            // 
            this.BtnCloseSec.Location = new System.Drawing.Point(453, 282);
            this.BtnCloseSec.Name = "BtnCloseSec";
            this.BtnCloseSec.Size = new System.Drawing.Size(100, 28);
            this.BtnCloseSec.TabIndex = 46;
            this.BtnCloseSec.Text = "关  闭";
            this.BtnCloseSec.UseVisualStyleBackColor = true;
            this.BtnCloseSec.Click += new System.EventHandler(this.BtnCloseSec_Click);
            // 
            // BroupAreaSynchronize
            // 
            this.BroupAreaSynchronize.Controls.Add(this.Labmsg);
            this.BroupAreaSynchronize.Controls.Add(this.ProgressBarLOC);
            this.BroupAreaSynchronize.Controls.Add(this.BtnSynchronize);
            this.BroupAreaSynchronize.Location = new System.Drawing.Point(8, 16);
            this.BroupAreaSynchronize.Name = "BroupAreaSynchronize";
            this.BroupAreaSynchronize.Size = new System.Drawing.Size(554, 86);
            this.BroupAreaSynchronize.TabIndex = 34;
            this.BroupAreaSynchronize.TabStop = false;
            this.BroupAreaSynchronize.Text = "导入用户数据 (.xlsx .xls .awd)";
            // 
            // Labmsg
            // 
            this.Labmsg.AutoSize = true;
            this.Labmsg.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Labmsg.ForeColor = System.Drawing.Color.Red;
            this.Labmsg.Location = new System.Drawing.Point(9, 58);
            this.Labmsg.Name = "Labmsg";
            this.Labmsg.Size = new System.Drawing.Size(267, 17);
            this.Labmsg.TabIndex = 4;
            this.Labmsg.Text = "注意：Excel是清空后导入；中奖名单是追加导入";
            // 
            // ProgressBarLOC
            // 
            this.ProgressBarLOC.Location = new System.Drawing.Point(6, 20);
            this.ProgressBarLOC.Name = "ProgressBarLOC";
            this.ProgressBarLOC.Size = new System.Drawing.Size(436, 28);
            this.ProgressBarLOC.TabIndex = 3;
            // 
            // BtnSynchronize
            // 
            this.BtnSynchronize.Location = new System.Drawing.Point(448, 20);
            this.BtnSynchronize.Name = "BtnSynchronize";
            this.BtnSynchronize.Size = new System.Drawing.Size(100, 28);
            this.BtnSynchronize.TabIndex = 0;
            this.BtnSynchronize.Text = "导入模板";
            this.BtnSynchronize.UseVisualStyleBackColor = true;
            this.BtnSynchronize.Click += new System.EventHandler(this.BtnSynchronize_Click);
            // 
            // FrmUserEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(582, 423);
            this.Controls.Add(this.TabUserDushboard);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmUserEdit";
            this.ShowInTaskbar = false;
            this.Text = "参会人员数据管理";
            this.Load += new System.EventHandler(this.FrmUserList_Load);
            this.TabUserDushboard.ResumeLayout(false);
            this.Page1.ResumeLayout(false);
            this.Page1.PerformLayout();
            this.GroupBox.ResumeLayout(false);
            this.GroupBox.PerformLayout();
            this.Page2.ResumeLayout(false);
            this.BroupGuest.ResumeLayout(false);
            this.BroupAreaFroWebService.ResumeLayout(false);
            this.BroupAreaFroWebService.PerformLayout();
            this.BroupAreaSynchronize.ResumeLayout(false);
            this.BroupAreaSynchronize.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnCloseFrm;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.TabControl TabUserDushboard;
        private System.Windows.Forms.TabPage Page1;
        private System.Windows.Forms.CheckBox chkdel_flag;
        private System.Windows.Forms.GroupBox GroupBox;
        private System.Windows.Forms.TextBox txtremark;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox chkok_flag;
        private System.Windows.Forms.CheckBox chkcheck_flag;
        private System.Windows.Forms.CheckBox chkspe_flag;
        private System.Windows.Forms.CheckBox chkaward_flag;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtbarcode;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtcomp_no;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtcompany_name;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtPerson;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage Page2;
        private System.Windows.Forms.Button BtnCloseSec;
        private System.Windows.Forms.GroupBox BroupAreaSynchronize;
        private System.Windows.Forms.ProgressBar ProgressBarLOC;
        private System.Windows.Forms.Button BtnSynchronize;
        private System.Windows.Forms.Label Labmsg;
        private System.Windows.Forms.Button BtnClearList;
        private System.Windows.Forms.Button BtnExplort;
        private System.Windows.Forms.GroupBox BroupAreaFroWebService;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button BtnGetWebRequest;
        private System.Windows.Forms.Button BtnDataRepoet;
        private System.Windows.Forms.Label LabDatashow;
        private System.Windows.Forms.TextBox txtmeeting_id;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox StrWebUrl;
        private System.Windows.Forms.Button BtnPostToOSS;
        private System.Windows.Forms.GroupBox BroupGuest;
        private System.Windows.Forms.ComboBox GuestListCom;
        private System.Windows.Forms.Button GetGuestList;
        private System.Windows.Forms.Button GuestRenew;
        private System.Windows.Forms.Button GuestUpload;
        private System.Windows.Forms.Button BtnAllSign;
        private System.Windows.Forms.TextBox txtsalesdept;
        private System.Windows.Forms.TextBox txtsales;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button BtnAddNew;
    }
}