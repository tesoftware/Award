﻿namespace ConferenceSupport
{
    partial class FormAwardLucky
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAwardLucky));
            this.Mainpanel = new System.Windows.Forms.Panel();
            this.BtnStart = new System.Windows.Forms.PictureBox();
            this.SeedsList = new System.Windows.Forms.ListBox();
            this.labelExit = new System.Windows.Forms.Label();
            this.timer_lottery = new System.Windows.Forms.Timer(this.components);
            this.LabSeedInfo = new System.Windows.Forms.Label();
            this.Mainpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BtnStart)).BeginInit();
            this.SuspendLayout();
            // 
            // Mainpanel
            // 
            this.Mainpanel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Mainpanel.Controls.Add(this.BtnStart);
            this.Mainpanel.Controls.Add(this.SeedsList);
            this.Mainpanel.Location = new System.Drawing.Point(262, 211);
            this.Mainpanel.Name = "Mainpanel";
            this.Mainpanel.Size = new System.Drawing.Size(1300, 700);
            this.Mainpanel.TabIndex = 0;
            // 
            // BtnStart
            // 
            this.BtnStart.BackColor = System.Drawing.Color.Transparent;
            this.BtnStart.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnStart.Location = new System.Drawing.Point(559, 631);
            this.BtnStart.Name = "BtnStart";
            this.BtnStart.Size = new System.Drawing.Size(202, 66);
            this.BtnStart.TabIndex = 14;
            this.BtnStart.TabStop = false;
            this.BtnStart.Click += new System.EventHandler(this.BtnStart_Click);
            // 
            // SeedsList
            // 
            this.SeedsList.FormattingEnabled = true;
            this.SeedsList.ItemHeight = 12;
            this.SeedsList.Location = new System.Drawing.Point(-88, -102);
            this.SeedsList.Name = "SeedsList";
            this.SeedsList.Size = new System.Drawing.Size(258, 88);
            this.SeedsList.TabIndex = 11;
            this.SeedsList.Visible = false;
            // 
            // labelExit
            // 
            this.labelExit.BackColor = System.Drawing.Color.Transparent;
            this.labelExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.labelExit.Image = ((System.Drawing.Image)(resources.GetObject("labelExit.Image")));
            this.labelExit.Location = new System.Drawing.Point(0, 0);
            this.labelExit.Name = "labelExit";
            this.labelExit.Size = new System.Drawing.Size(32, 32);
            this.labelExit.TabIndex = 10;
            this.labelExit.Click += new System.EventHandler(this.labelExit_Click);
            // 
            // timer_lottery
            // 
            this.timer_lottery.Interval = 10;
            this.timer_lottery.Tick += new System.EventHandler(this.timer_lottery_Tick);
            // 
            // LabSeedInfo
            // 
            this.LabSeedInfo.BackColor = System.Drawing.Color.Transparent;
            this.LabSeedInfo.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabSeedInfo.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.LabSeedInfo.Location = new System.Drawing.Point(32, 2);
            this.LabSeedInfo.Name = "LabSeedInfo";
            this.LabSeedInfo.Size = new System.Drawing.Size(600, 14);
            this.LabSeedInfo.TabIndex = 15;
            // 
            // FormAwardLucky
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1920, 1080);
            this.Controls.Add(this.LabSeedInfo);
            this.Controls.Add(this.labelExit);
            this.Controls.Add(this.Mainpanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormAwardLucky";
            this.ShowInTaskbar = false;
            this.Text = "FormAwardLucky";
            this.Load += new System.EventHandler(this.FormAwardLucky_Load);
            this.Mainpanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BtnStart)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Mainpanel;
        private System.Windows.Forms.Label labelExit;
        private System.Windows.Forms.PictureBox BtnStart;
        private System.Windows.Forms.Timer timer_lottery;
        private System.Windows.Forms.ListBox SeedsList;
        private System.Windows.Forms.Label LabSeedInfo;
    }
}