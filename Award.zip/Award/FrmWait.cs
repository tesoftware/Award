﻿using System;
using System.Windows.Forms;

namespace ConferenceSupport
{
    public partial class FrmWait : Form
    {
        public FrmWait()
        {
            InitializeComponent();
        }

        private void FrmWait_Load(object sender, EventArgs e)
        {

        }
    }
}
