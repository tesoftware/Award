﻿using System;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Runtime.InteropServices;
using System.Data.OleDb;

namespace ConferenceSupport
{
    public partial class FormAwardLucky : Form
    {
        public FormAwardLucky()
        {
            InitializeComponent();
        }
        private string FileName = System.IO.Directory.GetCurrentDirectory() + @"\\template\\config.ini";
        private int MaxPeopro = 0;
        private int R, G, B;
        private int Rt, Gt, Bt;
        private string ColorStr;
        private int Maxnum = 0;  // 本轮最大数
        private int Nownum = 0; // 当前轮
        
        //参数说明：section：INI文件中的段落；key：INI文件中的关键字；val：INI文件中关键字的数值；filePath：INI文件的完整的路径和名称。
        [DllImport("kernel32", CharSet = CharSet.Auto)]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);
        //页面配置
        public string PagestyleID
        {
            get { return pagestyle; }
            set { pagestyle = value; }
        }
        //奖项名称
        public string AwardName
        {
            get { return awardstr; }
            set { awardstr = value; }
        }

        private string pagestyle = "0";           //编辑人员ID
        private string awardname = "";          //奖项
        private string awardstr = "";               //奖项
        private string MainpanelSize = "0";     //屏幕尺寸

        private Label[] lb = new Label[20];     //定义20个控件数据 用于显示姓名[工号]
        private Label[] cb = new Label[20];    //定义20个控件数据 用于显示公司/部门

        #region 内存回收
        [DllImport("kernel32.dll", EntryPoint = "SetProcessWorkingSetSize")]
        public static extern int SetProcessWorkingSetSize(IntPtr process, int minSize, int maxSize);
        /// <summary>
        /// 释放内存
        /// </summary>
        public static void ClearMemory()
        {
            GC.Collect();
            GC.WaitForPendingFinalizers();
            if (Environment.OSVersion.Platform == PlatformID.Win32NT)
            {
                SetProcessWorkingSetSize(System.Diagnostics.Process.GetCurrentProcess().Handle, -1, -1);
            }
        }
        #endregion

        ////   加载窗体    //////////////////////////////////////////////////////////////////////////
        private void FormAwardLucky_Load(object sender, EventArgs e)
        {
            ////_______________________________________________________________________________________________>>>>>>>>>>>>  传值
            string BackGroundPicture = "";
            if (awardstr != "")     //传值不为空，则获取奖项及奖品     
            {
                OleDbConnection odcConnection = new OleDbConnection(Common.strConn());
                if (odcConnection.State == System.Data.ConnectionState.Open) odcConnection.Close();
                odcConnection.Open();
                OleDbCommand odCommand = odcConnection.CreateCommand();
                odCommand.CommandText = "SELECT * FROM  [award] WHERE ID = " + awardstr;
                OleDbDataReader DBReader = odCommand.ExecuteReader();
                if (DBReader.Read())
                {
                    awardname = Common.AwardStyleArr[Int32.Parse(DBReader["AwardStyle"].ToString())] + ";" + DBReader["AwardItem"].ToString();
                    BackGroundPicture = DBReader["AwardBG"].ToString().Trim();
                    Maxnum = Int32.Parse(DBReader["AwardNum"].ToString().Trim());
                }
                DBReader.Close();
                odCommand.Dispose();
                odcConnection.Close();
            }
            else
            {
                MessageBox.Show("没有选择对应的奖项，请重新选择");
                this.Dispose();
                this.Close();
            }
            ////_______________________________________________________________________________________________>>>>>>>>>>>>  背景图加载
            //设置自定义背景
            if (File.Exists(BackGroundPicture))
            {
                this.BackgroundImage = Image.FromFile(BackGroundPicture);
            }
            else
            {
                BackGroundPicture = ""; //不是文件，将背景置空
            }

            if (awardname == "")
            {
                MessageBox.Show("没有选择对应的奖项，请重新选择");
                this.Dispose();
                this.Close();
            }
            ////_______________________________________________________________________________________________>>>>>>>>>>>>  主题加载
            //加载样式
            try
            {
                StringBuilder temp = new StringBuilder(256);
                GetPrivateProfileString("AwardSetup", "AwardBGColor", "", temp, 256, FileName);   //抽奖背景颜色
                ColorStr = temp.ToString();
                string[] sArray = ColorStr.Split('|');
                R = Int32.Parse(sArray[0]);
                G = Int32.Parse(sArray[1]);
                B = Int32.Parse(sArray[2]);
                this.BackColor = Color.FromArgb(R, G, B);  //背景色
                Mainpanel.BackColor = Color.FromArgb(R, G, B);  //背景色

                GetPrivateProfileString("AwardSetup", "AwardFontColor", "255|255|0", temp, 256, FileName);   //文字颜色
                ColorStr = temp.ToString();
                sArray = ColorStr.Split('|');
                Rt = Int32.Parse(sArray[0]);
                Gt = Int32.Parse(sArray[1]);
                Bt = Int32.Parse(sArray[2]);

                GetPrivateProfileString("AwardSetup", "AwardBGpath", "", temp, 256, FileName);   //签到背景图路径
                string backpicpath = temp.ToString();
                if (File.Exists(@backpicpath))
                {
                    if (BackGroundPicture == "")
                    {
                        this.BackgroundImage = Image.FromFile(@backpicpath);
                    }
                }
                GetPrivateProfileString("AwardSetup", "BGStyleFlag", "", temp, 256, FileName);   //页面尺寸配置 1920 或 1024
                MainpanelSize = temp.ToString();
                if (MainpanelSize  == "0")
                {
                    Mainpanel.Size = new System.Drawing.Size(800, 124);
                }
                else
                {
                    Mainpanel.Size = new System.Drawing.Size(840, 570);
                }
            }
            catch
            {
                MessageBox.Show("配置文件错误，请检查文件是否完整");
                Application.Exit();
            }

            ////_______________________________________________________________________________________________>>>>>>>>>>>> 屏幕配置
             //屏幕自适应
            int SW = Screen.PrimaryScreen.Bounds.Width;
            int SH = Screen.PrimaryScreen.Bounds.Height;
            this.Width = SW;
            this.Height = SH;
            //主要内容窗口配置
            int subSW = 0;
            int subSH = 0;
            if (MainpanelSize == "0")
            {
                subSW = (SW - 1300) / 2;
                subSH = (SH - 700) / 2 + 40;
            }
            else
            {
                subSW = (SW - 840) / 2;
                subSH = (SH - 570) / 2 + 40;                
            }
            Mainpanel.Location = new Point(subSW, subSH);
            if (MainpanelSize == "0") //1920分辨率时
            {
                Mainpanel.Size = new System.Drawing.Size(1300, 700);
                //Mainpanel.BackColor = Color.FromArgb(0, 0, 0); 
            }
            else
            {
                Mainpanel.Size = new System.Drawing.Size(840, 570);                
            }            
            labelExit.Location = new Point(0, 0);
            LabSeedInfo.Location = new Point(20, 0);
            ////_______________________________________________________________________________________________>>>>>>>>>>>> 主按钮生成
            string Btnimg = string.Empty;
            Btnimg = System.IO.Directory.GetCurrentDirectory() + "\\template\\btn_start.png";
            if (File.Exists(Btnimg)) BtnStart.Image = Image.FromFile(Btnimg);
            if (MainpanelSize == "0")//1920分辨率时
            {
                BtnStart.Location = new System.Drawing.Point(545, 631);
            }
            else
            {
                BtnStart.Location = new System.Drawing.Point(340, 480);                
            }

            timer_lottery.Enabled = false;
            ////_______________________________________________________________________________________________>>>>>>>>>>>>  数据相关
            PreparingSeeds();  //数据准备
            CreatLabelGroup();  //建立显示文本框
        }
        //关闭窗体
        private void labelExit_Click(object sender, EventArgs e)
        {
            this.Dispose();
            this.Close();
        }
        //生成抽奖的人员名单控件集
        private void CreatLabelGroup()
        {
            //生成 1 2 5 10 20 几种不同模板
            switch (pagestyle)
            {
                case "0":  //同屏一人
                        MaxPeopro = 1;
                        lb[0] = new Label();                        
                        this.Mainpanel.Controls.Add(lb[0]);                        
                        lb[0].BackColor = Color.FromArgb(R, G, B);     //背景色
                        lb[0].ForeColor = Color.FromArgb(Rt, Gt, Bt);  //文字色 

                        if (MainpanelSize == "0")
                        {
                            lb[0].Font = new System.Drawing.Font("微软雅黑", 64F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
                            lb[0].Location = new System.Drawing.Point(138, 173);
                            lb[0].Size = new System.Drawing.Size(1040, 120);
                        }
                        else
                        {
                            lb[0].Font = new System.Drawing.Font("微软雅黑", 50F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
                            lb[0].Location = new System.Drawing.Point(20, 110);
                            lb[0].Size = new System.Drawing.Size(800, 124);
                        }
                        lb[0].Name = "emp_1";                        
                        lb[0].TabIndex = 11;
                        lb[0].Text = " ";
                        lb[0].TextAlign = System.Drawing.ContentAlignment.MiddleCenter; 
                        cb[0] = new Label();                        
                        this.Mainpanel.Controls.Add(cb[0]);                        
                        cb[0].BackColor = Color.FromArgb(R, G, B);     //背景色
                        cb[0].ForeColor = Color.FromArgb(Rt, Gt, Bt);  //文字色                                                
                        cb[0].Name = "dep_1";                        
                        cb[0].TabIndex = 12;
                        cb[0].Text = " ";
                        cb[0].TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

                        if (MainpanelSize == "0")
                        {
                            cb[0].Font = new System.Drawing.Font("微软雅黑", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
                            cb[0].Location = new System.Drawing.Point(137, 300);
                            cb[0].Size = new System.Drawing.Size(1040, 120);
                        }
                        else
                        {
                            cb[0].Font = new System.Drawing.Font("微软雅黑", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
                            cb[0].Location = new System.Drawing.Point(19, 233);
                            cb[0].Size = new System.Drawing.Size(800, 124);
                        }
                    break;
                case "1":  //同屏两人
                    MaxPeopro = 2;                       
                    for (int i = 0; i < 2; i++)
                    {
                        int s = 0;
                        if (MainpanelSize == "0")
                        {
                            s = i * 300;
                        }
                        else
                        {
                            s = i * 200;
                        }
                        lb[i] = new Label();                        
                        this.Mainpanel.Controls.Add(lb[i]);
                        lb[i].BackColor = Color.FromArgb(R, G, B);     //背景色
                        lb[i].ForeColor = Color.FromArgb(Rt, Gt, Bt);  //文字色
                        lb[i].Name = "emp_" + i.ToString();
                        lb[i].TabIndex = 100 + i;
                        lb[i].Text = " ";
                        lb[i].TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

                        if (MainpanelSize == "0")
                        {
                            lb[i].Font = new System.Drawing.Font("微软雅黑", 38F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
                            lb[i].Location = new System.Drawing.Point(60, 30 + s);
                            lb[i].Size = new System.Drawing.Size(1050, 80);
                        }
                        else
                        {
                            lb[i].Font = new System.Drawing.Font("微软雅黑", 32F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
                            lb[i].Location = new System.Drawing.Point(60, 30 + s);
                            lb[i].Size = new System.Drawing.Size(750, 80);
                        }
                        cb[i] = new Label();                        
                        this.Mainpanel.Controls.Add(cb[i]);
                        cb[i].BackColor = Color.FromArgb(R, G, B);     //背景色
                        cb[i].ForeColor = Color.FromArgb(Rt, Gt, Bt);  //文字色 
                        cb[i].Name = "dep_" + i.ToString();
                        cb[i].TabIndex = 200 + i;
                        cb[i].Text = " ";
                        cb[i].TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
                        if (MainpanelSize == "0")
                        {
                            cb[i].Font = new System.Drawing.Font("微软雅黑", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
                            cb[i].Location = new System.Drawing.Point(60, 120 + s);
                            cb[i].Size = new System.Drawing.Size(1050, 80);
                        }
                        else
                        {
                            cb[i].Font = new System.Drawing.Font("微软雅黑", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
                            cb[i].Location = new System.Drawing.Point(60, 100 + s);
                            cb[i].Size = new System.Drawing.Size(750, 80);
                        }                        
                    }                                       
                    break;
                case "2":  //同屏五人
                    MaxPeopro = 5;
                    for (int i = 0; i < 5; i++)
                    {
                        int s = 0;
                        if (MainpanelSize == "0")
                        {
                            s = i * 100;
                        }
                        else
                        {
                            s = i * 70;
                        }
                        lb[i] = new Label();
                        this.Mainpanel.Controls.Add(lb[i]);
                        lb[i].BackColor = Color.FromArgb(R, G, B);     //背景色
                        lb[i].ForeColor = Color.FromArgb(Rt, Gt, Bt);  //文字色
                        lb[i].Name = "emp_" + i.ToString();
                        lb[i].TabIndex = 100 + i;
                        lb[i].Text = " ";
                        lb[i].TextAlign = System.Drawing.ContentAlignment.MiddleRight;
                        if (MainpanelSize == "0")
                        {
                            lb[i].Font = new System.Drawing.Font("微软雅黑", 32F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
                            lb[i].Location = new System.Drawing.Point(10, 50 + s);
                            lb[i].Size = new System.Drawing.Size(500, 80);
                        }
                        else
                        {
                            lb[i].Font = new System.Drawing.Font("微软雅黑", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
                            lb[i].Location = new System.Drawing.Point(10, 70 + s);
                            lb[i].Size = new System.Drawing.Size(350, 50);
                        }
                        cb[i] = new Label();
                        this.Mainpanel.Controls.Add(cb[i]);
                        cb[i].BackColor = Color.FromArgb(R, G, B);     //背景色
                        cb[i].ForeColor = Color.FromArgb(Rt, Gt, Bt);  //文字色                                                                        
                        cb[i].Name = "dep_" + i.ToString();                        
                        cb[i].TabIndex = 200 + i;
                        cb[i].Text = " ";
                        cb[i].TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
                        if (MainpanelSize == "0")
                        {
                            cb[i].Font = new System.Drawing.Font("微软雅黑", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
                            cb[i].Location = new System.Drawing.Point(520, 50 + s);
                            cb[i].Size = new System.Drawing.Size(760, 80);
                        }
                        else
                        {
                            cb[i].Font = new System.Drawing.Font("微软雅黑", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
                            cb[i].Location = new System.Drawing.Point(360, 70 + s);
                            cb[i].Size = new System.Drawing.Size(510, 50);
                        }
                    }                    
                    break;
                case "3":  //同屏十人
                    MaxPeopro = 10;
                    for (int i = 0; i < 5; i++)
                    {
                        int s  = 0;
                        if (MainpanelSize == "0")
                        {
                            s = i * 120;
                        }
                        else
                        {
                            s = i * 95;
                        }
                        lb[i] = new Label();
                        this.Mainpanel.Controls.Add(lb[i]);
                        lb[i].BackColor = Color.FromArgb(R, G, B);     //背景色
                        lb[i].ForeColor = Color.FromArgb(Rt, Gt, Bt);  //文字色
                        lb[i].Name = "emp_" + i.ToString();                        
                        lb[i].TabIndex = 100 + i;
                        lb[i].Text = " ";
                        lb[i].TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
                        if (MainpanelSize == "0")
                        {
                            lb[i].Font = new System.Drawing.Font("微软雅黑", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
                            lb[i].Location = new System.Drawing.Point(20, 5 + s);
                            lb[i].Size = new System.Drawing.Size(620, 60);
                        }
                        else
                        {
                            lb[i].Font = new System.Drawing.Font("微软雅黑", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
                            lb[i].Location = new System.Drawing.Point(20, 5 + s);
                            lb[i].Size = new System.Drawing.Size(380, 40);
                        }

                        cb[i] = new Label();
                        this.Mainpanel.Controls.Add(cb[i]);                        
                        cb[i].BackColor = Color.FromArgb(R, G, B);     //背景色
                        cb[i].ForeColor = Color.FromArgb(Rt, Gt, Bt);  //文字色
                        cb[i].Name = "dep_" + i.ToString();
                        cb[i].TabIndex = 200 + i;
                        cb[i].Text = " ";
                        cb[i].TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

                        if (MainpanelSize == "0")
                        {
                            cb[i].Font = new System.Drawing.Font("微软雅黑", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
                            cb[i].Location = new System.Drawing.Point(20, 50 + s);
                            cb[i].Size = new System.Drawing.Size(620, 60);
                        }
                        else
                        {
                            cb[i].Font = new System.Drawing.Font("微软雅黑", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
                            cb[i].Location = new System.Drawing.Point(20, 40 + s);
                            cb[i].Size = new System.Drawing.Size(380, 40);
                        }
                    }
                    for (int i = 5; i < 10; i++)
                    {
                        int s = 0;
                        if (MainpanelSize == "0")
                        {
                            s = (i - 5) * 120;
                        }
                        else
                        {
                            s = (i - 5) * 95;
                        }
                        lb[i] = new Label();                        
                        this.Mainpanel.Controls.Add(lb[i]);                        
                        lb[i].BackColor = Color.FromArgb(R, G, B);     //背景色
                        lb[i].ForeColor = Color.FromArgb(Rt, Gt, Bt);  //文字色                        
                        lb[i].Name = "emp_" + i.ToString();                        
                        lb[i].TabIndex = 100 + i;
                        lb[i].Text = " ";
                        lb[i].TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

                        if (MainpanelSize == "0")
                        {
                            lb[i].Font = new System.Drawing.Font("微软雅黑", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
                            lb[i].Location = new System.Drawing.Point(660, 5 + s);
                            lb[i].Size = new System.Drawing.Size(620, 60);
                        }
                        else
                        {
                            lb[i].Font = new System.Drawing.Font("微软雅黑", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
                            lb[i].Location = new System.Drawing.Point(420, 5 + s);
                            lb[i].Size = new System.Drawing.Size(380, 40);
                        }
                        cb[i] = new Label();                        
                        this.Mainpanel.Controls.Add(cb[i]);                        
                        cb[i].BackColor = Color.FromArgb(R, G, B);     //背景色
                        cb[i].ForeColor = Color.FromArgb(Rt, Gt, Bt);  //文字色 
                        cb[i].Name = "dep_" + i.ToString();                        
                        cb[i].TabIndex = 200 + i;
                        cb[i].Text = " ";
                        cb[i].TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
                        if (MainpanelSize == "0")
                        {
                            cb[i].Font = new System.Drawing.Font("微软雅黑", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
                            cb[i].Location = new System.Drawing.Point(660, 50 + s);
                            cb[i].Size = new System.Drawing.Size(620, 60);
                        }
                        else
                        {
                            cb[i].Font = new System.Drawing.Font("微软雅黑", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
                            cb[i].Location = new System.Drawing.Point(420, 40 + s);
                            cb[i].Size = new System.Drawing.Size(380, 40);
                        }
                    }
                    break;
                case "4":  //同屏二十人
                    MaxPeopro = 20;
                    int key = 0;
                    for (int j = 0; j< 4; j++)
                    {
                        int s = 0;
                        int h = 0;                                
                        for (int i = 0; i < 5; i++)
                        {
                            if (MainpanelSize == "0")
                            {
                                s = i * 124;
                                h = j * 320;
                            }
                            else
                            {
                                s = i * 100;
                                h = j * 200;
                            }                            
                            lb[key] = new Label();
                            this.Mainpanel.Controls.Add(lb[key]);
                            lb[key].BackColor = Color.FromArgb(R, G, B);     //背景色
                            lb[key].ForeColor = Color.FromArgb(Rt, Gt, Bt);  //文字色                            
                            lb[key].Name = "emp_" + key.ToString();                            
                            lb[key].TabIndex = 100 + key;
                            lb[key].Text = " ";
                            lb[key].TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
                            if (MainpanelSize == "0")
                            {
                                lb[key].Font = new System.Drawing.Font("微软雅黑", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
                                lb[key].Location = new System.Drawing.Point(8 + h, 15 + s);
                                lb[key].Size = new System.Drawing.Size(310, 40);
                            }
                            else
                            {
                                lb[key].Font = new System.Drawing.Font("微软雅黑", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
                                lb[key].Location = new System.Drawing.Point(10 + h, 15 + s);
                                lb[key].Size = new System.Drawing.Size(200, 25);
                            }

                            cb[key] = new Label();
                            this.Mainpanel.Controls.Add(cb[key]);
                            cb[key].BackColor = Color.FromArgb(R, G, B);     //背景色
                            cb[key].ForeColor = Color.FromArgb(Rt, Gt, Bt);  //文字色
                            cb[key].Name = "dep_" + key.ToString();                            
                            cb[key].TabIndex = 200 + key;
                            cb[key].Text = " ";
                            cb[key].TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
                            if (MainpanelSize == "0")
                            {
                                cb[key].Font = new System.Drawing.Font("微软雅黑", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
                                cb[key].Location = new System.Drawing.Point(10 + h, 45 + s);
                                cb[key].Size = new System.Drawing.Size(310, 50);
                            }
                            else
                            {
                                cb[key].Font = new System.Drawing.Font("微软雅黑", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
                                cb[key].Location = new System.Drawing.Point(10 + h, 42 + s);
                                cb[key].Size = new System.Drawing.Size(200, 40);
                            }
                            key++;
                        }
                    }
                    break;
                default:
                    MessageBox.Show("没有模板");
                    break;
            }
        }
        //开始抽奖按钮
        private void BtnStart_Click(object sender, EventArgs e)
        {
            if (Maxnum <= Nownum)
            {
                MessageBox.Show("本期抽奖轮次已满");
                return;
            }
            string sql = "select count(*) as result from [seedlist] where award_flag = 0";
            string result = Access.RunSqlToDB(sql);            
            LabSeedInfo.Text = result + "," + Maxnum.ToString() + "," + Nownum.ToString();

            if (Int32.Parse(result) == 0)
            {
                MessageBox.Show("可供抽奖的人数为零，请先生成抽奖者名单。");
                return;
            }
            if (Int32.Parse(result) < (MaxPeopro + 1))
            {
                MessageBox.Show("可供抽奖的人数不足以滚动屏幕，抽奖中止");
                return;
            }   
            
            string Btnimg = string.Empty;
            if (timer_lottery.Enabled == false)
            {
                Btnimg = System.IO.Directory.GetCurrentDirectory() + "\\template\\btn_end.png";
                 if (File.Exists(Btnimg)){
                     BtnStart.Image = Image.FromFile(Btnimg);
                 }
                 timer_lottery.Enabled = true; //开始滚动
            }
            else
            { 
                timer_lottery.Enabled = false; //停止滚动
                PickLuckyOnes();                
                Nownum++;
                result = Access.RunSqlToDB(sql);            
                LabSeedInfo.Text = result + "," + Maxnum.ToString() + "," + Nownum.ToString();
                //清理内存，待下次抽奖
                ClearMemory();
                if (Nownum == Maxnum)
                {
                    Btnimg = System.IO.Directory.GetCurrentDirectory() + "\\template\\btn_over.png";
                }
                else
                {
                    Btnimg = System.IO.Directory.GetCurrentDirectory() + "\\template\\btn_start.png";
                }
                if (File.Exists(Btnimg))
                {
                    BtnStart.Image = Image.FromFile(Btnimg);
                }
            }
        }
        //从种子库中抽N名幸运儿
        private void PickLuckyOnes()
        {
            string sql = string.Empty;
            char[] delimiterChars = { ';' };
            string[] AwardArray = awardname.Split(delimiterChars);
            byte[] bytes = new byte[4];            
            for (int i = 0; i < MaxPeopro; i++)  //抽N个奖
            {                
                System.Security.Cryptography.RNGCryptoServiceProvider rng = new System.Security.Cryptography.RNGCryptoServiceProvider();
                rng.GetBytes(bytes);
                Random rnd2 = new Random(BitConverter.ToInt32(bytes, 0));
                int rndNum = rnd2.Next(0, SeedsList.Items.Count);
                string Rtext = SeedsList.Items[rndNum].ToString();
                string[] sArray = Rtext.Split(delimiterChars);
                lb[i].Text = sArray[2] + "[" + sArray[3] + "]";
                cb[i].Text = sArray[1];                
                //数据库设置为中奖了
                string seedid = sArray[0].ToString();
                //然后要删掉这个种子
                SeedsList.Items.RemoveAt(rndNum);
                Application.DoEvents();
                sql = "update [seedlist] set award_flag = '1' ,award_name = '" + AwardArray[0] + "', award_item = '" + AwardArray[1] + "' where ID = " + seedid + ";";                
                Access.Export_to_DB(sql); //最后将结果写入数据库
            }
            
        }
        //数据库准备
        private void PreparingSeeds()
        {
            string sql = "";
            Application.DoEvents();
            SeedsList.Items.Clear();
            OleDbConnection odcConnection = new OleDbConnection(Common.strConn());
            if (odcConnection.State == System.Data.ConnectionState.Open) odcConnection.Close();
            odcConnection.Open();
            OleDbCommand odCommand = odcConnection.CreateCommand();
            sql = "select ID,dept_name,person,employee_no  from [seedlist] where award_flag = 0 order by ID asc";  //取出库里所有未中奖人员
            odCommand.CommandText = sql;
            OleDbDataReader DBReader = odCommand.ExecuteReader();
            while (DBReader.Read())
            {
                SeedsList.Items.Add(DBReader[0].ToString() + ";" + DBReader[1].ToString() + ";" + DBReader[2].ToString() + ";" + DBReader[3].ToString());
            }
            DBReader.Close();
            odCommand.Dispose();
            odcConnection.Close();

            string swapstr = string.Empty;
            //洗牌，池里超过10个人触发
            if (SeedsList.Items.Count > 10)
            {
                for (int i = 0; i < SeedsList.Items.Count; i++)
                {
                    byte[] bytes = new byte[4];
                    System.Security.Cryptography.RNGCryptoServiceProvider rng = new System.Security.Cryptography.RNGCryptoServiceProvider();
                    rng.GetBytes(bytes);
                    Random rnd2 = new Random(BitConverter.ToInt32(bytes, 0));
                    int rndNum = rnd2.Next(0, SeedsList.Items.Count);
                    swapstr = SeedsList.Items[i].ToString();
                    SeedsList.Items[i] = SeedsList.Items[rndNum];
                    SeedsList.Items[rndNum] = swapstr;
                }
            }
        }
        //随机取一行，取一个从列表里删一个
        private string rndshow()
        {
            byte[] bytes = new byte[4];
            System.Security.Cryptography.RNGCryptoServiceProvider rng = new System.Security.Cryptography.RNGCryptoServiceProvider();
            rng.GetBytes(bytes);
            Random rnd2 = new Random(BitConverter.ToInt32(bytes, 0));
            int rndNum = rnd2.Next(0, SeedsList.Items.Count);
            string Rtext = SeedsList.Items[rndNum].ToString();
            return Rtext;
        }
        //滚动
        private void timer_lottery_Tick(object sender, EventArgs e)
        {
            string Rtext = "";
            char[] delimiterChars = { ';' };
            for (int i = 0; i < MaxPeopro; i++)
            {
                Rtext = rndshow();
                string[] sArray = Rtext.Split(delimiterChars);
                lb[i].Text = sArray[2] + "[" + sArray[3] + "]";
                cb[i].Text = sArray[1];
            }
        }
    }
}
