﻿using System;
using System.Drawing;
using System.Text;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;

namespace ConferenceSupport
{
    public partial class FrmSetup : Form
    {
        public FrmSetup()
        {
            InitializeComponent();
        }
        public event TransfDelegate TransfEvent;
        private string FileName = System.IO.Directory.GetCurrentDirectory() + @"\\template\\config.ini";
        private string  AwardSelID = "0";
        //参数说明：section：INI文件中的段落；key：INI文件中的关键字；val：INI文件中关键字的数值；filePath：INI文件的完整的路径和名称。
        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);
        //加载窗体
        private void FrmSetup_Load(object sender, EventArgs e)
        {
            ReadiniFile();
            ReadAwardData();
        }
        //关闭窗口
        private void BtnCloseFrm_Click(object sender, EventArgs e)
        {
            TransfEvent("SetupClose");
            this.Close();
        }
        //读取ini文件，从中获得相关数据库的各项资料
        private void ReadiniFile()
        {
            if (File.Exists(FileName))
            {
                try
                {
                    StringBuilder temp = new StringBuilder(256);
                    GetPrivateProfileString("SignInSetup", "title", "", temp, 256, FileName);   //签到标题文字
                    txtTitle.Text = temp.ToString();
                    GetPrivateProfileString("SignInSetup", "backpicpath", "", temp, 256, FileName);   //签到背景图路径
                    txtbackpicpath.Text = temp.ToString();                    
                    GetPrivateProfileString("SignInSetup", "titlecolor", "", temp, 256, FileName);   //签到标题颜色
                    string ColorStr = temp.ToString();
                    string[] sArray = ColorStr.Split('|');
                    TitleColor.BackColor = Color.FromArgb(Int32.Parse(sArray[0]), Int32.Parse(sArray[1]), Int32.Parse(sArray[2]));
                    GetPrivateProfileString("SignInSetup", "bgcolor", "", temp, 256, FileName);   //签到文字颜色
                    ColorStr = temp.ToString();
                    sArray = ColorStr.Split('|');
                    TxtBGColor.BackColor = Color.FromArgb(Int32.Parse(sArray[0]), Int32.Parse(sArray[1]), Int32.Parse(sArray[2]));
                    GetPrivateProfileString("SignInSetup", "fontcolor", "", temp, 256, FileName);   //签到文字颜色
                    ColorStr = temp.ToString();
                    sArray = ColorStr.Split('|');
                    TxtFontColor.BackColor = Color.FromArgb(Int32.Parse(sArray[0]), Int32.Parse(sArray[1]), Int32.Parse(sArray[2]));
                    GetPrivateProfileString("AwardSetup", "BGStyleFlag", "", temp, 256, FileName);   //抽奖模板类型
                    if (temp.ToString() == "0") { BGStyleFlag1.Checked = true; } else { BGStyleFlag2.Checked = true; }
                    GetPrivateProfileString("AwardSetup", "AwardBGColor", "", temp, 256, FileName);   //抽奖文字背景颜色
                    ColorStr = temp.ToString();
                    sArray = ColorStr.Split('|');
                    PicAwardTextBG.BackColor = Color.FromArgb(Int32.Parse(sArray[0]), Int32.Parse(sArray[1]), Int32.Parse(sArray[2]));
                    GetPrivateProfileString("AwardSetup", "AwardFontColor", "", temp, 256, FileName);   //抽奖文字背景颜色
                    ColorStr = temp.ToString();
                    sArray = ColorStr.Split('|');
                    TxtAwardFontColor.BackColor = Color.FromArgb(Int32.Parse(sArray[0]), Int32.Parse(sArray[1]), Int32.Parse(sArray[2]));
                    GetPrivateProfileString("AwardSetup", "AwardBGpath", "", temp, 256, FileName);   //抽奖背景图路径
                    txtAwardBGpath.Text = temp.ToString();  
                }
                catch
                {
                    MessageBox.Show("配置文件错误，请检查文件是否完整");
                    Application.Exit();
                }
            }
        }
        //读取奖池设定
        private void ReadAwardData()
        {
            Application.DoEvents();            
            AwarditemList.Items.Clear();          

            OleDbConnection odcConnection = new OleDbConnection(Common.strConn());
            if (odcConnection.State == System.Data.ConnectionState.Open) odcConnection.Close();
            odcConnection.Open();
            OleDbCommand odCommand = odcConnection.CreateCommand();
            string sql = "select ID,AwardStyle,AwardPage,AwardItem,AwardBG,AwardNum  from [award] order by ID asc";
            odCommand.CommandText = sql;
            OleDbDataReader DBReader = odCommand.ExecuteReader();
            while (DBReader.Read())
            {
                ListViewItem li = new ListViewItem();
                li.SubItems.Clear();
                li.SubItems[0].Text = DBReader["ID"].ToString();
                li.SubItems.Add(Common.AwardStyleArr[Int32.Parse(DBReader["AwardStyle"].ToString())]);
                li.SubItems.Add(Common.AwardPageArr[Int32.Parse(DBReader["AwardPage"].ToString())]);
                li.SubItems.Add(DBReader["AwardNum"].ToString());
                li.SubItems.Add(DBReader["AwardItem"].ToString());
                li.SubItems.Add(DBReader["AwardBG"].ToString());
                AwarditemList.Items.Add(li);
            }            
            DBReader.Close();
            odCommand.Dispose();
            odcConnection.Close();
        }
        //保存配置ini文件
        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            File.Delete(FileName);
            string SaveStr;

            ///签到相关内容

            SaveStr = "[SignInSetup]\r\n";
            SaveStr += "title=" + txtTitle.Text + "\r\n";
            SaveStr += "backpicpath=" + txtbackpicpath.Text + "\r\n";
            int r, g, b;
            r = TitleColor.BackColor.R;
            g = TitleColor.BackColor.G;
            b = TitleColor.BackColor.B;
            SaveStr += "titlecolor=" + r.ToString() + "|" + g.ToString() + "|" + b.ToString() + "\r\n";

            r = TxtBGColor.BackColor.R;
            g = TxtBGColor.BackColor.G;
            b = TxtBGColor.BackColor.B;
            SaveStr += "bgcolor=" + r.ToString() + "|" + g.ToString() + "|" + b.ToString() + "\r\n";

            r = TxtFontColor.BackColor.R;
            g = TxtFontColor.BackColor.G;
            b = TxtFontColor.BackColor.B;
            SaveStr += "fontcolor=" + r.ToString() + "|" + g.ToString() + "|" + b.ToString() + "\r\n";

            //抽奖相关内容
            SaveStr += "[AwardSetup]\r\n";

            if (BGStyleFlag1.Checked == true)
            {
                SaveStr += "BGStyleFlag=0\r\n";     //0 为默认的 1920*1080
            }
            else
            {
                SaveStr += "BGStyleFlag=1\r\n";     //1 为 1024*768
            }
            r = PicAwardTextBG.BackColor.R;
            g = PicAwardTextBG.BackColor.G;
            b = PicAwardTextBG.BackColor.B;
            SaveStr += "AwardBGColor=" + r.ToString() + "|" + g.ToString() + "|" + b.ToString() + "\r\n";
            r = TxtAwardFontColor.BackColor.R;
            g = TxtAwardFontColor.BackColor.G;
            b = TxtAwardFontColor.BackColor.B;
            SaveStr += "AwardFontColor=" + r.ToString() + "|" + g.ToString() + "|" + b.ToString() + "\r\n";
            SaveStr += "AwardBGpath=" + txtAwardBGpath.Text + "\r\n";
            FileStream fs = new FileStream(FileName, FileMode.OpenOrCreate, FileAccess.Write);
            StreamWriter m_streamWriter = new StreamWriter(fs, Encoding.Default);
            m_streamWriter.Flush();
            //  使用StreamWriter来往文件中写入内容
            m_streamWriter.BaseStream.Seek(0, SeekOrigin.Begin);
            m_streamWriter.Write(SaveStr);
            //关闭此文件
            m_streamWriter.Flush();
            m_streamWriter.Close();
            TransfEvent("SetupUpdate");
        }
        #region 签到相关功能
        //标颜文字颜色选择
        private void TitleColor_Click(object sender, EventArgs e)
        {
            DialogResult dr = ColorDialog.ShowDialog();
            //如果选中颜色，单击“确定”按钮则改变文本框的文本颜色
            if (dr == DialogResult.OK)
            {
                TitleColor.BackColor = ColorDialog.Color;
            }
        }
        //背景颜色
        private void TxtBGColor_Click(object sender, EventArgs e)
        {
            DialogResult dr = ColorDialog.ShowDialog();
            //如果选中颜色，单击“确定”按钮则改变文本框的文本颜色
            if (dr == DialogResult.OK)
            {
                TxtBGColor.BackColor = ColorDialog.Color;
            }            
        }
        //文字颜色
        private void TxtFontColor_Click(object sender, EventArgs e)
        {
            DialogResult dr = ColorDialog.ShowDialog();
            //如果选中颜色，单击“确定”按钮则改变文本框的文本颜色
            if (dr == DialogResult.OK)
            {
                TxtFontColor.BackColor = ColorDialog.Color;
            }
        }
        //浏览图片文件
        private void BtnBrower_Click(object sender, EventArgs e)
        {
            txtbackpicpath.Text = GetBrowerPicPath();
        }
        //公共获取图片背景的函数
        private string GetBrowerPicPath()
        {
            string OpenFilePath = "";
            OpenFileDialog opf = new OpenFileDialog();
            opf.Title = "请选择签到界面的背景图片";
            opf.Filter = "图像文件(*.png,*.jpg,*.bmp)|*.png;*.jpg;*.bmp";
            if (opf.ShowDialog() == DialogResult.OK)
            {
                OpenFilePath = opf.FileName;
            }
            return OpenFilePath;
        }

        #endregion        
        #region 抽奖相关功能
        //抽奖背景颜色
        private void PicAwardTextBG_Click(object sender, EventArgs e)
        {
            DialogResult dr = ColorDialog.ShowDialog();
            //如果选中颜色，单击“确定”按钮则改变文本框的文本颜色
            if (dr == DialogResult.OK)
            {
                PicAwardTextBG.BackColor = ColorDialog.Color;
            }
        }        
        //浏览抽奖背景图
        private void BtnAwardBGBrower_Click(object sender, EventArgs e)
        {
            txtAwardBGpath.Text = GetBrowerPicPath();
        }
        //点击行获取信息，并更新ID
        private void AwarditemList_Click(object sender, EventArgs e)
        {
            AwardSelID = AwarditemList.SelectedItems[0].SubItems[0].Text.Trim(); //得到选中的行
            try
                {
                    string sql = "";
                    OleDbConnection odcConnection = new OleDbConnection(Common.strConn());
                    if (odcConnection.State == System.Data.ConnectionState.Open) odcConnection.Close();
                    odcConnection.Open();
                    OleDbCommand odCommand = odcConnection.CreateCommand();
                    sql = "SELECT ID,AwardStyle,AwardPage,AwardItem,AwardBG,AwardNum FROM  [award] WHERE ID = " + AwardSelID;
                    odCommand.CommandText = sql;
                    OleDbDataReader DBReader = odCommand.ExecuteReader();
                    if (DBReader.Read())
                    {
                        //判断数据元素的指针
                        for (int i =0 ;i< Common.AwardStyleArr.Length;i++){
                            if (i == Int32.Parse(DBReader["AwardStyle"].ToString())) CombAwardStyle.SelectedIndex = i;
                        }
                        //判断数据元素的指针
                        for (int i =0 ;i< Common.AwardPageArr.Length;i++){
                            if (i == Int32.Parse(DBReader["AwardPage"].ToString())) CombAwardNum.SelectedIndex = i;
                        }
                        txtAwarditem.Text = DBReader["AwardItem"].ToString().Trim();
                        txtAwardBG.Text = DBReader["AwardBG"].ToString().Trim();
                        AwardNumVal.Value = Int32.Parse(DBReader["AwardNum"].ToString());
                    }
                    DBReader.Close();
                    odCommand.Dispose();
                    odcConnection.Close();
                }
                catch { }
        }        
        //初始化按钮
        private void BtnAwardReday_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("确定要执行初始化操作吗?\n初始化后所有抽奖相关数据都将恢复到初始状态，有效数据请做好备份", "初始化确认", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                string sql = "delete from [award]";
                if (Access.Export_to_DB(sql) == false)
                {
                    MessageBox.Show("执行失败，请检查数据库是否正确");
                    return;
                }
                sql = "alter table [award] alter ID counter(1,1);";
                Access.Export_to_DB(sql);
                sql = "INSERT INTO [award] (ID,AwardStyle,AwardPage,AwardItem,AwardNum) Values (1,'0','0','特等奖奖品',1)";
                Access.Export_to_DB(sql);
                sql = "INSERT INTO [award] (ID,AwardStyle,AwardPage,AwardItem,AwardNum) Values (2,'1','0','一等奖奖品',1)";
                Access.Export_to_DB(sql);
                sql = "INSERT INTO [award] (ID,AwardStyle,AwardPage,AwardItem,AwardNum) Values (3,'2','1','二等奖奖品',1)";
                Access.Export_to_DB(sql);
                sql = "INSERT INTO [award] (ID,AwardStyle,AwardPage,AwardItem,AwardNum) Values (4,'3','2','三等奖奖品',1)";
                Access.Export_to_DB(sql);
                ReadAwardData();
                txtAwardBG.Text = "";
                txtAwarditem.Text = "";
                CombAwardStyle.SelectedIndex = 0;
                CombAwardNum.SelectedIndex = 0;
                MessageBox.Show("数据初始化完成！");
            }
        }
        //验证表单
        private bool CheckAwardValue()
        {
            if (CombAwardStyle.SelectedIndex == -1)
            {
                MessageBox.Show("请选择奖项");
                return false;
            }
            if (CombAwardNum.SelectedIndex == -1)
            {
                MessageBox.Show("请选择同屏人数");
                return false;
            }
            if (Common.CheckSql(txtAwarditem.Text.Trim()) == "")
            {
                MessageBox.Show("请填写奖品");
                return false;
            }
            return true;
        }
        //清空表单
        private void ClearAwardValue()
        {
            CombAwardStyle.SelectedIndex = -1;
            CombAwardNum.SelectedIndex = -1;
            txtAwarditem.Text = "";
            AwardSelID = "0";
        }
        //新增奖项
        private void BtnAwardAdd_Click(object sender, EventArgs e)
        {
            if (CheckAwardValue() == false) return;
            string sql = "INSERT INTO [award] (AwardStyle,AwardPage,AwardItem,AwardBG,AwardNum) Values ('" + CombAwardStyle.SelectedIndex.ToString() + "','" + CombAwardNum.SelectedIndex.ToString() + "','" + Common.CheckSql(txtAwarditem.Text.Trim()) + "','" + txtAwardBG.Text + "'," + AwardNumVal.Text + ")";
            Access.Export_to_DB(sql);
             ReadAwardData();
             MessageBox.Show("新增奖项 " + CombAwardStyle.Items[CombAwardStyle.SelectedIndex].ToString() +" 成功！");
             ClearAwardValue();
        }
        //修改奖项
        private void BtnAwardEdit_Click(object sender, EventArgs e)
        {
            if (CheckAwardValue() == false) return;
            string sql = "UPDATE [award] SET AwardStyle = '" + CombAwardStyle.SelectedIndex.ToString() + "', AwardPage = '" + CombAwardNum.SelectedIndex.ToString() + "',AwardItem ='" + Common.CheckSql(txtAwarditem.Text.Trim()) + "', AwardBG = '" + txtAwardBG.Text + "' , AwardNum = " + AwardNumVal.Text + "   WHERE ID = " + AwardSelID;
            Access.Export_to_DB(sql);
            ReadAwardData();            
        }       
        //删除奖项
        private void BtnAwardDel_Click(object sender, EventArgs e)
        {
            if (AwardSelID == "0") return;
            if (MessageBox.Show("确定要删除奖项吗？", "删除确认", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                string sql = "DELETE FROM [award]  WHERE ID = " + AwardSelID;
                Access.Export_to_DB(sql);
                ClearAwardValue();
                ReadAwardData();
            }
        }
        //禁止改变第一列列宽
        private void AwarditemList_ColumnWidthChanging(object sender, ColumnWidthChangingEventArgs e)
        {
            if (e.ColumnIndex > 0) return;
            ColumnHeader header = this.AwarditemList.Columns[e.ColumnIndex];
            e.NewWidth = AwarditemList.Columns[e.ColumnIndex].Width;
            e.Cancel = true;
        }
        //获得自定义背景图
        private void BtnCustomBG_Click(object sender, EventArgs e)
        {
            txtAwardBG.Text = GetBrowerPicPath();
        }
        //设置文本的背景色
        private void TxtAwardFontColor_Click(object sender, EventArgs e)
        {
            DialogResult dr = ColorDialog.ShowDialog();
            //如果选中颜色，单击“确定”按钮则改变文本框的文本颜色
            if (dr == DialogResult.OK)
            {
                TxtAwardFontColor.BackColor = ColorDialog.Color;
            }
        }        
        //恢复默认配置功能
        private void BtnRestore_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("确定要恢复默认配置吗?", "确认", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                File.Delete(FileName);     
                string SaveStr = "";
                SaveStr = "[SignInSetup]\n";
                SaveStr += "title=来宾请在此签到\n";
                SaveStr += "backpicpath=\n";
                SaveStr += "titlecolor=217|210|247\n";
                SaveStr += "bgcolor=128|0|128\n";
                SaveStr += "fontcolor=255|255|255\n";
                SaveStr += "[AwardSetup]\n";
                SaveStr += "BGStyleFlag=0\n";
                SaveStr += "AwardBGColor=128|0|64\n";
                SaveStr += "AwardFontColor=255|255|0\n";
                SaveStr += "AwardBGpath=\n";
                //保存到文件
                FileStream fs = new FileStream(FileName, FileMode.OpenOrCreate, FileAccess.Write);
                StreamWriter m_streamWriter = new StreamWriter(fs, Encoding.Default);
                m_streamWriter.Flush();
                //  使用StreamWriter来往文件中写入内容
                m_streamWriter.BaseStream.Seek(0, SeekOrigin.Begin);
                m_streamWriter.Write(SaveStr);
                //关闭此文件
                m_streamWriter.Flush();
                m_streamWriter.Close();
                //恢复完重读一次
                ReadiniFile();
                TransfEvent("SetupRestore");
            }
        }
        #endregion

        private void tabControl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl.SelectedIndex == 0)
            {
                labPlanInfo.Text = "【配置】可进行界面风格的个性化设定";
            }
            else
            {
                labPlanInfo.Text = "【奖项】可进行抽奖的奖项配置";
            }
        }
    }
}
