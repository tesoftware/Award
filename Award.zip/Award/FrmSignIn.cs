﻿using System;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.IO;


namespace ConferenceSupport
{
    public partial class FrmSignIn : Form
    {
        public FrmSignIn()
        {
            InitializeComponent();
        }
        private string FileName = System.IO.Directory.GetCurrentDirectory() + @"\\template\\config.ini";
        private int ClearTimerNum = 0;
        private int R, G, B;
        private int Rt, Gt, Bt;
        private string OldScanStr;

        [DllImport("user32", EntryPoint = "HideCaret")]
        private static extern bool HideCaret(IntPtr hWnd);

        //参数说明：section：INI文件中的段落；key：INI文件中的关键字；val：INI文件中关键字的数值；filePath：INI文件的完整的路径和名称。
        [DllImport("kernel32", CharSet = CharSet.Auto)]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);
        public event TransfDelegate TransfEvent; 
        //点击则关闭窗体
        private void BtnExit_Click(object sender, EventArgs e)
        {
            TransfEvent("close");
            this.Close();
        }

        private void FrmSignIn_Load(object sender, EventArgs e)
        {
            //屏幕自适应
            int SW = Screen.PrimaryScreen.Bounds.Width;
            int SH = Screen.PrimaryScreen.Bounds.Height;
            this.Width = SW;
            this.Height = SH;
            int subSW = (SW - 1920) / 2;
            int subSH = (SH - 1080) / 2;
            BackBoard.Location = new Point(subSW, subSH);
            BtnExit.Location = new Point(0, 0);
            LabDeptname.Text = "请扫码/刷卡签到";
            ScannerText.Location = new Point(0, 0);

            try
            {
                StringBuilder temp = new StringBuilder(256);
                GetPrivateProfileString("SignInSetup", "title", "", temp, 256, FileName);   //签到标题文字
                LabMessageInfo.Text = temp.ToString();
                GetPrivateProfileString("SignInSetup", "backpicpath", "", temp, 256, FileName);   //签到背景图路径
                string backpicpath = temp.ToString();
                if (File.Exists(@backpicpath)){
                    BackBoard.BackgroundImage = Image.FromFile(@backpicpath);               
                }                
                GetPrivateProfileString("SignInSetup", "titlecolor", "255|255|255", temp, 256, FileName);   //签到标题颜色
                string ColorStr = temp.ToString();                
                string[] sArray = ColorStr.Split('|');
                LabMessageInfo.ForeColor = Color.FromArgb(Int32.Parse(sArray[0]), Int32.Parse(sArray[1]), Int32.Parse(sArray[2]));

                GetPrivateProfileString("SignInSetup", "bgcolor", "255|0|0", temp, 256, FileName);   //签到背景颜色
                ColorStr = temp.ToString();
                sArray = ColorStr.Split('|');
                R = Int32.Parse(sArray[0]);
                G = Int32.Parse(sArray[1]);
                B = Int32.Parse(sArray[2]);
                this.BackColor = Color.FromArgb(R,G,B);  //背景色
                ScannerText.BackColor = Color.FromArgb(R, G, B);  //背景色
                ScannerText.ForeColor = Color.FromArgb(R, G, B);  //背景色

                GetPrivateProfileString("SignInSetup", "fontcolor", "255|255|0", temp, 256, FileName);   //签到文字颜色

                ColorStr = temp.ToString();
                sArray = ColorStr.Split('|');
                Rt = Int32.Parse(sArray[0]);
                Gt = Int32.Parse(sArray[1]);
                Bt = Int32.Parse(sArray[2]);
                LabDeptname.ForeColor = Color.FromArgb(Rt, Gt, Bt);
                LabUsername.ForeColor = Color.FromArgb(Rt, Gt, Bt);
                LabSales.Text = "";
                LabSalesDept.Text = "";
                LabSales.ForeColor = Color.FromArgb(Rt, Gt, Bt);
                LabSalesDept.ForeColor = Color.FromArgb(Rt, Gt, Bt);
                GetPrivateProfileString("SignInSetup", "title", "", temp, 256, FileName);   //签到标题颜色
                LabMessageInfo.Text = temp.ToString();
            }
            catch
            {
                MessageBox.Show("配置文件错误，请检查文件是否完整");
                Application.Exit();
            }
            HideCaret(ScannerText.Handle);
        }
        //计算时间差
        private string DateDiff(DateTime DateTime2)
        {
            DateTime DateTime1 = DateTime.Now;
            string dateDiff = null;
            TimeSpan ts = DateTime1.Subtract(DateTime2).Duration();
            dateDiff = ts.TotalSeconds.ToString();
            return dateDiff;
        }
        //自动清空文字
        private void ClearTimer_Tick(object sender, EventArgs e)
        {
            ClearTimerNum--;
            if (ClearTimerNum < 1)
            {
                LabDeptname.Text = "请扫码/刷卡签到";
                LabUsername.Text = "";
                LabSales.Text = "";
                LabSalesDept.Text = "";
                //如果背景色不对，要换掉
                this.BackColor = Color.FromArgb(R, G, B);  //背景色
                LabUsername.ForeColor = Color.FromArgb(Rt, Gt, Bt);
                LabDeptname.ForeColor = Color.FromArgb(Rt, Gt, Bt);
                LabSales.ForeColor = Color.FromArgb(Rt, Gt, Bt);
                LabSalesDept.ForeColor = Color.FromArgb(Rt, Gt, Bt);
                ScannerText.BackColor = Color.FromArgb(R, G, B);  //背景色
                ScannerText.ForeColor = Color.FromArgb(R, G, B);  //背景色
                ClearTimer.Enabled = false;
            }            
        }
        //扫码后执行的操作
        private void ScannerText_KeyPress(object sender, KeyPressEventArgs e)
        {
            HideCaret(ScannerText.Handle);
            string Barcode = @"";
            string ResultStr = @"none";
            if ((e.KeyChar == 13) && (ScannerText.Text.Length > 1))
            {
                if (ScannerText.Text == OldScanStr)
                {
                    ScannerText.Text = "";
                    LabDeptname.Text = "请不要重复签到";
                    LabSales.Text = "";
                    LabSalesDept.Text = "";
                    ClearTimerNum = 10;
                    ClearTimer.Enabled = true;
                    return; //如果两次扫码一样，则不做处理
                }
                //测试码
                if (ScannerText.Text == "THISISTESTCODE20220825")
                {
                    ScannerText.Text = "";
                    LabUsername.Text = "扫码成功";
                    LabDeptname.Text = "检测到测试码，扫码功能可以正常使用";
                    LabSales.Text = "";
                    LabSalesDept.Text = "";
                    ClearTimerNum = 10;
                    ClearTimer.Enabled = true;
                    return; 
                }

                Barcode = ScannerText.Text.Trim();
                Barcode = Barcode.Replace("'", "").Replace(";", "");   //扫码结果里不允许出现特殊符号                                
                OldScanStr = ScannerText.Text; //记下本次扫码结果
                ScannerText.Text = "";
                string sql = @"";
                if (Barcode.Length < 4) return; //至少四个字符才能用作验证码                
                sql = "SELECT([check_flag] + ';' + CStr([eid]) + ';' + [person] + ';' + [comp_no] + ';' + [company_name] + ';' + [remark]+ ';' + [sales_name]+ ';' + [sales_dept]) as result  FROM employee WHERE del_flag = '0' and barcode = '" + Barcode + "'";
                Common.WriteLog(sql);
                ResultStr = Access.RunSqlToDB(sql);
                
                if (ResultStr == "none")
                {
                    //生成页面显示信息
                    LabUsername.Text = "签到不成功";
                    LabDeptname.Text = "来宾列表无未匹配的信息";
                    LabSales.Text = "";
                    LabSalesDept.Text = "";
                    Common.WriteLog("失败：" + Barcode); //记日志
                }
                else
                {                    
                    string[] sArray = ResultStr.Split(';');
                    if (sArray.Count() != 8) return;
                    switch (sArray[0].ToString())
                    {
                        case "0": //没签到
                            //生成签到记录
                            DateTime dt = DateTime.Now;
                            sql = "update [employee] set check_flag = '1', signdate = '" + Common.NowStamp() + "' where eid =" + sArray[1].ToString();
                            Common.WriteLog(sql);
                            Access.Export_to_DB(sql);
                            //生成页面显示信息
                            LabUsername.Text = sArray[2].ToString() + " [" + sArray[3].ToString() + "]" + "  " + sArray[5].ToString();
                            LabDeptname.Text = sArray[4].ToString();
                            LabSales.Text = sArray[6].ToString();
                            LabSalesDept.Text = sArray[7].ToString();
                            break;
                        case "1": //已签过了
                            //生成页面显示信息
                            LabUsername.Text = "重复签到";
                            LabDeptname.Text = "您已经签过到了，请勿重复签到";           
                            LabSales.Text = "";
                            LabSalesDept.Text = "";                 
                            break;
                        default:
                            LabUsername.Text = "";
                            LabDeptname.Text = "数据不符，请检查数据库";
                            LabSales.Text = "";
                            LabSalesDept.Text = "";
                            break;
                    }
                }
                Common.WriteLog("扫码：" + LabDeptname.Text + "   " + Barcode); //记日志
                ClearTimerNum = 10;
                ClearTimer.Enabled = true;
            }
        } 
    }
}
