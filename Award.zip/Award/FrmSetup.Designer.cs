﻿namespace ConferenceSupport
{
    partial class FrmSetup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmSetup));
            this.GroupSign = new System.Windows.Forms.GroupBox();
            this.LabTips4 = new System.Windows.Forms.Label();
            this.TxtFontColor = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.BtnBrower = new System.Windows.Forms.Button();
            this.txtbackpicpath = new System.Windows.Forms.TextBox();
            this.LabPicture = new System.Windows.Forms.Label();
            this.TxtBGColor = new System.Windows.Forms.PictureBox();
            this.LabBGColor = new System.Windows.Forms.Label();
            this.TitleColor = new System.Windows.Forms.PictureBox();
            this.txtTitle = new System.Windows.Forms.TextBox();
            this.LabTitlefont = new System.Windows.Forms.Label();
            this.LabTitleTxtColor = new System.Windows.Forms.Label();
            this.BtnCloseFrm = new System.Windows.Forms.Button();
            this.BtnUpdate = new System.Windows.Forms.Button();
            this.ColorDialog = new System.Windows.Forms.ColorDialog();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.SetSign = new System.Windows.Forms.TabPage();
            this.BtnRestore = new System.Windows.Forms.Button();
            this.GrpAward = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.TxtAwardFontColor = new System.Windows.Forms.PictureBox();
            this.LabAwardFontColor = new System.Windows.Forms.Label();
            this.LabTips3 = new System.Windows.Forms.Label();
            this.LabTips1 = new System.Windows.Forms.Label();
            this.LabTips2 = new System.Windows.Forms.Label();
            this.PicAwardTextBG = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.BGStyleFlag2 = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.BGStyleFlag1 = new System.Windows.Forms.RadioButton();
            this.BtnAwardBGBrower = new System.Windows.Forms.Button();
            this.txtAwardBGpath = new System.Windows.Forms.TextBox();
            this.LabAwardBg = new System.Windows.Forms.Label();
            this.SetAward = new System.Windows.Forms.TabPage();
            this.groupBox = new System.Windows.Forms.GroupBox();
            this.AwardNumVal = new System.Windows.Forms.NumericUpDown();
            this.LabTps9 = new System.Windows.Forms.Label();
            this.BtnCustomBG = new System.Windows.Forms.Button();
            this.txtAwardBG = new System.Windows.Forms.TextBox();
            this.BtnAwardAdd = new System.Windows.Forms.Button();
            this.BtnAwardReday = new System.Windows.Forms.Button();
            this.BtnAwardDel = new System.Windows.Forms.Button();
            this.BtnAwardEdit = new System.Windows.Forms.Button();
            this.txtAwarditem = new System.Windows.Forms.TextBox();
            this.CombAwardNum = new System.Windows.Forms.ComboBox();
            this.CombAwardStyle = new System.Windows.Forms.ComboBox();
            this.AwarditemList = new System.Windows.Forms.ListView();
            this.ID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.AwardStyle = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.AwardPage = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.AwardNumber = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Awarditem = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.AwardBG = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label4 = new System.Windows.Forms.Label();
            this.LabTps10 = new System.Windows.Forms.Label();
            this.labPlanInfo = new System.Windows.Forms.Label();
            this.GroupSign.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TxtFontColor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtBGColor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TitleColor)).BeginInit();
            this.tabControl.SuspendLayout();
            this.SetSign.SuspendLayout();
            this.GrpAward.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TxtAwardFontColor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicAwardTextBG)).BeginInit();
            this.SetAward.SuspendLayout();
            this.groupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AwardNumVal)).BeginInit();
            this.SuspendLayout();
            // 
            // GroupSign
            // 
            this.GroupSign.Controls.Add(this.LabTips4);
            this.GroupSign.Controls.Add(this.TxtFontColor);
            this.GroupSign.Controls.Add(this.label1);
            this.GroupSign.Controls.Add(this.BtnBrower);
            this.GroupSign.Controls.Add(this.txtbackpicpath);
            this.GroupSign.Controls.Add(this.LabPicture);
            this.GroupSign.Controls.Add(this.TxtBGColor);
            this.GroupSign.Controls.Add(this.LabBGColor);
            this.GroupSign.Controls.Add(this.TitleColor);
            this.GroupSign.Controls.Add(this.txtTitle);
            this.GroupSign.Controls.Add(this.LabTitlefont);
            this.GroupSign.Controls.Add(this.LabTitleTxtColor);
            this.GroupSign.Location = new System.Drawing.Point(10, 23);
            this.GroupSign.Name = "GroupSign";
            this.GroupSign.Size = new System.Drawing.Size(500, 128);
            this.GroupSign.TabIndex = 0;
            this.GroupSign.TabStop = false;
            this.GroupSign.Text = "签到界面 设置";
            // 
            // LabTips4
            // 
            this.LabTips4.AutoSize = true;
            this.LabTips4.ForeColor = System.Drawing.Color.DodgerBlue;
            this.LabTips4.Location = new System.Drawing.Point(17, 97);
            this.LabTips4.Name = "LabTips4";
            this.LabTips4.Size = new System.Drawing.Size(173, 12);
            this.LabTips4.TabIndex = 18;
            this.LabTips4.Text = "设定签到界面的背景及主题颜色";
            // 
            // TxtFontColor
            // 
            this.TxtFontColor.BackColor = System.Drawing.Color.Black;
            this.TxtFontColor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TxtFontColor.Location = new System.Drawing.Point(450, 92);
            this.TxtFontColor.Name = "TxtFontColor";
            this.TxtFontColor.Size = new System.Drawing.Size(28, 21);
            this.TxtFontColor.TabIndex = 10;
            this.TxtFontColor.TabStop = false;
            this.TxtFontColor.Click += new System.EventHandler(this.TxtFontColor_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(386, 97);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 9;
            this.label1.Text = "文字颜色：";
            // 
            // BtnBrower
            // 
            this.BtnBrower.Location = new System.Drawing.Point(302, 61);
            this.BtnBrower.Name = "BtnBrower";
            this.BtnBrower.Size = new System.Drawing.Size(48, 22);
            this.BtnBrower.TabIndex = 8;
            this.BtnBrower.Text = "浏览";
            this.BtnBrower.UseVisualStyleBackColor = true;
            this.BtnBrower.Click += new System.EventHandler(this.BtnBrower_Click);
            // 
            // txtbackpicpath
            // 
            this.txtbackpicpath.Location = new System.Drawing.Point(76, 61);
            this.txtbackpicpath.Name = "txtbackpicpath";
            this.txtbackpicpath.ReadOnly = true;
            this.txtbackpicpath.Size = new System.Drawing.Size(220, 21);
            this.txtbackpicpath.TabIndex = 7;
            // 
            // LabPicture
            // 
            this.LabPicture.AutoSize = true;
            this.LabPicture.Location = new System.Drawing.Point(17, 64);
            this.LabPicture.Name = "LabPicture";
            this.LabPicture.Size = new System.Drawing.Size(65, 12);
            this.LabPicture.TabIndex = 6;
            this.LabPicture.Text = "背景图片：";
            // 
            // TxtBGColor
            // 
            this.TxtBGColor.BackColor = System.Drawing.Color.Black;
            this.TxtBGColor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TxtBGColor.Location = new System.Drawing.Point(450, 58);
            this.TxtBGColor.Name = "TxtBGColor";
            this.TxtBGColor.Size = new System.Drawing.Size(28, 21);
            this.TxtBGColor.TabIndex = 5;
            this.TxtBGColor.TabStop = false;
            this.TxtBGColor.Click += new System.EventHandler(this.TxtBGColor_Click);
            // 
            // LabBGColor
            // 
            this.LabBGColor.AutoSize = true;
            this.LabBGColor.Location = new System.Drawing.Point(386, 62);
            this.LabBGColor.Name = "LabBGColor";
            this.LabBGColor.Size = new System.Drawing.Size(65, 12);
            this.LabBGColor.TabIndex = 4;
            this.LabBGColor.Text = "背景颜色：";
            // 
            // TitleColor
            // 
            this.TitleColor.BackColor = System.Drawing.Color.Black;
            this.TitleColor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TitleColor.Location = new System.Drawing.Point(450, 24);
            this.TitleColor.Name = "TitleColor";
            this.TitleColor.Size = new System.Drawing.Size(28, 21);
            this.TitleColor.TabIndex = 3;
            this.TitleColor.TabStop = false;
            this.TitleColor.Click += new System.EventHandler(this.TitleColor_Click);
            // 
            // txtTitle
            // 
            this.txtTitle.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.txtTitle.Location = new System.Drawing.Point(76, 24);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.Size = new System.Drawing.Size(274, 21);
            this.txtTitle.TabIndex = 1;
            // 
            // LabTitlefont
            // 
            this.LabTitlefont.AutoSize = true;
            this.LabTitlefont.Location = new System.Drawing.Point(17, 27);
            this.LabTitlefont.Name = "LabTitlefont";
            this.LabTitlefont.Size = new System.Drawing.Size(65, 12);
            this.LabTitlefont.TabIndex = 0;
            this.LabTitlefont.Text = "标题文字：";
            // 
            // LabTitleTxtColor
            // 
            this.LabTitleTxtColor.AutoSize = true;
            this.LabTitleTxtColor.Location = new System.Drawing.Point(386, 27);
            this.LabTitleTxtColor.Name = "LabTitleTxtColor";
            this.LabTitleTxtColor.Size = new System.Drawing.Size(65, 12);
            this.LabTitleTxtColor.TabIndex = 2;
            this.LabTitleTxtColor.Text = "标题颜色：";
            // 
            // BtnCloseFrm
            // 
            this.BtnCloseFrm.Location = new System.Drawing.Point(430, 458);
            this.BtnCloseFrm.Name = "BtnCloseFrm";
            this.BtnCloseFrm.Size = new System.Drawing.Size(100, 28);
            this.BtnCloseFrm.TabIndex = 46;
            this.BtnCloseFrm.Text = "关  闭";
            this.BtnCloseFrm.UseVisualStyleBackColor = true;
            this.BtnCloseFrm.Click += new System.EventHandler(this.BtnCloseFrm_Click);
            // 
            // BtnUpdate
            // 
            this.BtnUpdate.Location = new System.Drawing.Point(360, 366);
            this.BtnUpdate.Name = "BtnUpdate";
            this.BtnUpdate.Size = new System.Drawing.Size(150, 28);
            this.BtnUpdate.TabIndex = 47;
            this.BtnUpdate.Text = "保存/更新";
            this.BtnUpdate.UseVisualStyleBackColor = true;
            this.BtnUpdate.Click += new System.EventHandler(this.BtnUpdate_Click);
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.SetSign);
            this.tabControl.Controls.Add(this.SetAward);
            this.tabControl.ItemSize = new System.Drawing.Size(100, 34);
            this.tabControl.Location = new System.Drawing.Point(6, 0);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(528, 449);
            this.tabControl.TabIndex = 48;
            this.tabControl.SelectedIndexChanged += new System.EventHandler(this.tabControl_SelectedIndexChanged);
            // 
            // SetSign
            // 
            this.SetSign.Controls.Add(this.BtnRestore);
            this.SetSign.Controls.Add(this.GrpAward);
            this.SetSign.Controls.Add(this.GroupSign);
            this.SetSign.Controls.Add(this.BtnUpdate);
            this.SetSign.Location = new System.Drawing.Point(4, 38);
            this.SetSign.Margin = new System.Windows.Forms.Padding(13);
            this.SetSign.Name = "SetSign";
            this.SetSign.Padding = new System.Windows.Forms.Padding(3);
            this.SetSign.Size = new System.Drawing.Size(520, 407);
            this.SetSign.TabIndex = 0;
            this.SetSign.Text = "界面风格配置 ";
            this.SetSign.UseVisualStyleBackColor = true;
            // 
            // BtnRestore
            // 
            this.BtnRestore.Location = new System.Drawing.Point(10, 366);
            this.BtnRestore.Name = "BtnRestore";
            this.BtnRestore.Size = new System.Drawing.Size(107, 28);
            this.BtnRestore.TabIndex = 2;
            this.BtnRestore.Text = "恢复默认设置";
            this.BtnRestore.UseVisualStyleBackColor = true;
            this.BtnRestore.Click += new System.EventHandler(this.BtnRestore_Click);
            // 
            // GrpAward
            // 
            this.GrpAward.Controls.Add(this.label6);
            this.GrpAward.Controls.Add(this.label5);
            this.GrpAward.Controls.Add(this.TxtAwardFontColor);
            this.GrpAward.Controls.Add(this.LabAwardFontColor);
            this.GrpAward.Controls.Add(this.LabTips3);
            this.GrpAward.Controls.Add(this.LabTips1);
            this.GrpAward.Controls.Add(this.LabTips2);
            this.GrpAward.Controls.Add(this.PicAwardTextBG);
            this.GrpAward.Controls.Add(this.label3);
            this.GrpAward.Controls.Add(this.BGStyleFlag2);
            this.GrpAward.Controls.Add(this.label2);
            this.GrpAward.Controls.Add(this.BGStyleFlag1);
            this.GrpAward.Controls.Add(this.BtnAwardBGBrower);
            this.GrpAward.Controls.Add(this.txtAwardBGpath);
            this.GrpAward.Controls.Add(this.LabAwardBg);
            this.GrpAward.Location = new System.Drawing.Point(12, 166);
            this.GrpAward.Name = "GrpAward";
            this.GrpAward.Size = new System.Drawing.Size(498, 188);
            this.GrpAward.TabIndex = 1;
            this.GrpAward.TabStop = false;
            this.GrpAward.Text = "抽奖界面 设置";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label6.Location = new System.Drawing.Point(15, 156);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(449, 12);
            this.label6.TabIndex = 23;
            this.label6.Text = "【注】：背景中显示抽奖区域请设成与文本底色相同，否则文字底色会与图片冲突。";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label5.Location = new System.Drawing.Point(310, 91);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(173, 12);
            this.label5.TabIndex = 22;
            this.label5.Text = "请设置成与底色对比明显的颜色";
            // 
            // TxtAwardFontColor
            // 
            this.TxtAwardFontColor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.TxtAwardFontColor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TxtAwardFontColor.Location = new System.Drawing.Point(90, 88);
            this.TxtAwardFontColor.Name = "TxtAwardFontColor";
            this.TxtAwardFontColor.Size = new System.Drawing.Size(28, 21);
            this.TxtAwardFontColor.TabIndex = 21;
            this.TxtAwardFontColor.TabStop = false;
            this.TxtAwardFontColor.Click += new System.EventHandler(this.TxtAwardFontColor_Click);
            // 
            // LabAwardFontColor
            // 
            this.LabAwardFontColor.AutoSize = true;
            this.LabAwardFontColor.Location = new System.Drawing.Point(19, 93);
            this.LabAwardFontColor.Name = "LabAwardFontColor";
            this.LabAwardFontColor.Size = new System.Drawing.Size(65, 12);
            this.LabAwardFontColor.TabIndex = 20;
            this.LabAwardFontColor.Text = "文本颜色：";
            // 
            // LabTips3
            // 
            this.LabTips3.AutoSize = true;
            this.LabTips3.ForeColor = System.Drawing.Color.DodgerBlue;
            this.LabTips3.Location = new System.Drawing.Point(418, 123);
            this.LabTips3.Name = "LabTips3";
            this.LabTips3.Size = new System.Drawing.Size(65, 12);
            this.LabTips3.TabIndex = 19;
            this.LabTips3.Text = "默认背景图";
            // 
            // LabTips1
            // 
            this.LabTips1.AutoSize = true;
            this.LabTips1.ForeColor = System.Drawing.Color.DodgerBlue;
            this.LabTips1.Location = new System.Drawing.Point(382, 34);
            this.LabTips1.Name = "LabTips1";
            this.LabTips1.Size = new System.Drawing.Size(101, 12);
            this.LabTips1.TabIndex = 18;
            this.LabTips1.Text = "指定屏幕的分辨率";
            // 
            // LabTips2
            // 
            this.LabTips2.AutoSize = true;
            this.LabTips2.ForeColor = System.Drawing.Color.DodgerBlue;
            this.LabTips2.Location = new System.Drawing.Point(274, 63);
            this.LabTips2.Name = "LabTips2";
            this.LabTips2.Size = new System.Drawing.Size(209, 12);
            this.LabTips2.TabIndex = 17;
            this.LabTips2.Text = "请设置成与背景滚动文字区域同一颜色";
            // 
            // PicAwardTextBG
            // 
            this.PicAwardTextBG.BackColor = System.Drawing.Color.Purple;
            this.PicAwardTextBG.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.PicAwardTextBG.Location = new System.Drawing.Point(90, 58);
            this.PicAwardTextBG.Name = "PicAwardTextBG";
            this.PicAwardTextBG.Size = new System.Drawing.Size(28, 21);
            this.PicAwardTextBG.TabIndex = 16;
            this.PicAwardTextBG.TabStop = false;
            this.PicAwardTextBG.Click += new System.EventHandler(this.PicAwardTextBG_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 12);
            this.label3.TabIndex = 15;
            this.label3.Text = "文本底色：";
            // 
            // BGStyleFlag2
            // 
            this.BGStyleFlag2.AutoSize = true;
            this.BGStyleFlag2.Location = new System.Drawing.Point(174, 32);
            this.BGStyleFlag2.Name = "BGStyleFlag2";
            this.BGStyleFlag2.Size = new System.Drawing.Size(71, 16);
            this.BGStyleFlag2.TabIndex = 14;
            this.BGStyleFlag2.Text = "1024x768";
            this.BGStyleFlag2.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 13;
            this.label2.Text = "大屏尺寸：";
            // 
            // BGStyleFlag1
            // 
            this.BGStyleFlag1.AutoSize = true;
            this.BGStyleFlag1.Checked = true;
            this.BGStyleFlag1.Location = new System.Drawing.Point(90, 32);
            this.BGStyleFlag1.Name = "BGStyleFlag1";
            this.BGStyleFlag1.Size = new System.Drawing.Size(77, 16);
            this.BGStyleFlag1.TabIndex = 12;
            this.BGStyleFlag1.TabStop = true;
            this.BGStyleFlag1.Text = "1920x1080";
            this.BGStyleFlag1.UseVisualStyleBackColor = true;
            // 
            // BtnAwardBGBrower
            // 
            this.BtnAwardBGBrower.Location = new System.Drawing.Point(358, 118);
            this.BtnAwardBGBrower.Name = "BtnAwardBGBrower";
            this.BtnAwardBGBrower.Size = new System.Drawing.Size(48, 22);
            this.BtnAwardBGBrower.TabIndex = 11;
            this.BtnAwardBGBrower.Text = "浏览";
            this.BtnAwardBGBrower.UseVisualStyleBackColor = true;
            this.BtnAwardBGBrower.Click += new System.EventHandler(this.BtnAwardBGBrower_Click);
            // 
            // txtAwardBGpath
            // 
            this.txtAwardBGpath.Location = new System.Drawing.Point(90, 118);
            this.txtAwardBGpath.Name = "txtAwardBGpath";
            this.txtAwardBGpath.ReadOnly = true;
            this.txtAwardBGpath.Size = new System.Drawing.Size(262, 21);
            this.txtAwardBGpath.TabIndex = 10;
            // 
            // LabAwardBg
            // 
            this.LabAwardBg.AutoSize = true;
            this.LabAwardBg.Location = new System.Drawing.Point(19, 121);
            this.LabAwardBg.Name = "LabAwardBg";
            this.LabAwardBg.Size = new System.Drawing.Size(65, 12);
            this.LabAwardBg.TabIndex = 9;
            this.LabAwardBg.Text = "背景图片：";
            // 
            // SetAward
            // 
            this.SetAward.Controls.Add(this.groupBox);
            this.SetAward.Location = new System.Drawing.Point(4, 38);
            this.SetAward.Margin = new System.Windows.Forms.Padding(13);
            this.SetAward.Name = "SetAward";
            this.SetAward.Padding = new System.Windows.Forms.Padding(3);
            this.SetAward.Size = new System.Drawing.Size(520, 407);
            this.SetAward.TabIndex = 1;
            this.SetAward.Text = " 抽奖奖项配置 ";
            this.SetAward.UseVisualStyleBackColor = true;
            // 
            // groupBox
            // 
            this.groupBox.Controls.Add(this.AwardNumVal);
            this.groupBox.Controls.Add(this.LabTps9);
            this.groupBox.Controls.Add(this.BtnCustomBG);
            this.groupBox.Controls.Add(this.txtAwardBG);
            this.groupBox.Controls.Add(this.BtnAwardAdd);
            this.groupBox.Controls.Add(this.BtnAwardReday);
            this.groupBox.Controls.Add(this.BtnAwardDel);
            this.groupBox.Controls.Add(this.BtnAwardEdit);
            this.groupBox.Controls.Add(this.txtAwarditem);
            this.groupBox.Controls.Add(this.CombAwardNum);
            this.groupBox.Controls.Add(this.CombAwardStyle);
            this.groupBox.Controls.Add(this.AwarditemList);
            this.groupBox.Controls.Add(this.label4);
            this.groupBox.Controls.Add(this.LabTps10);
            this.groupBox.Location = new System.Drawing.Point(10, 6);
            this.groupBox.Name = "groupBox";
            this.groupBox.Size = new System.Drawing.Size(498, 395);
            this.groupBox.TabIndex = 1;
            this.groupBox.TabStop = false;
            this.groupBox.Text = "奖项设置";
            // 
            // AwardNumVal
            // 
            this.AwardNumVal.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AwardNumVal.Location = new System.Drawing.Point(88, 300);
            this.AwardNumVal.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.AwardNumVal.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.AwardNumVal.Name = "AwardNumVal";
            this.AwardNumVal.ReadOnly = true;
            this.AwardNumVal.Size = new System.Drawing.Size(46, 22);
            this.AwardNumVal.TabIndex = 59;
            this.AwardNumVal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.AwardNumVal.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // LabTps9
            // 
            this.LabTps9.AutoSize = true;
            this.LabTps9.ForeColor = System.Drawing.Color.DodgerBlue;
            this.LabTps9.Location = new System.Drawing.Point(15, 329);
            this.LabTps9.Name = "LabTps9";
            this.LabTps9.Size = new System.Drawing.Size(233, 12);
            this.LabTps9.TabIndex = 56;
            this.LabTps9.Text = "抽奖界面可设定自定义背景，实现最佳体验";
            // 
            // BtnCustomBG
            // 
            this.BtnCustomBG.Location = new System.Drawing.Point(444, 300);
            this.BtnCustomBG.Name = "BtnCustomBG";
            this.BtnCustomBG.Size = new System.Drawing.Size(48, 22);
            this.BtnCustomBG.TabIndex = 55;
            this.BtnCustomBG.Text = "浏览";
            this.BtnCustomBG.UseVisualStyleBackColor = true;
            this.BtnCustomBG.Click += new System.EventHandler(this.BtnCustomBG_Click);
            // 
            // txtAwardBG
            // 
            this.txtAwardBG.Location = new System.Drawing.Point(185, 300);
            this.txtAwardBG.Name = "txtAwardBG";
            this.txtAwardBG.ReadOnly = true;
            this.txtAwardBG.Size = new System.Drawing.Size(253, 21);
            this.txtAwardBG.TabIndex = 54;
            // 
            // BtnAwardAdd
            // 
            this.BtnAwardAdd.Location = new System.Drawing.Point(432, 356);
            this.BtnAwardAdd.Name = "BtnAwardAdd";
            this.BtnAwardAdd.Size = new System.Drawing.Size(60, 28);
            this.BtnAwardAdd.TabIndex = 52;
            this.BtnAwardAdd.Text = "新增";
            this.BtnAwardAdd.UseVisualStyleBackColor = true;
            this.BtnAwardAdd.Click += new System.EventHandler(this.BtnAwardAdd_Click);
            // 
            // BtnAwardReday
            // 
            this.BtnAwardReday.ForeColor = System.Drawing.Color.Maroon;
            this.BtnAwardReday.Location = new System.Drawing.Point(8, 356);
            this.BtnAwardReday.Name = "BtnAwardReday";
            this.BtnAwardReday.Size = new System.Drawing.Size(109, 28);
            this.BtnAwardReday.TabIndex = 51;
            this.BtnAwardReday.Text = "奖项初始化";
            this.BtnAwardReday.UseVisualStyleBackColor = true;
            this.BtnAwardReday.Click += new System.EventHandler(this.BtnAwardReday_Click);
            // 
            // BtnAwardDel
            // 
            this.BtnAwardDel.Location = new System.Drawing.Point(300, 356);
            this.BtnAwardDel.Name = "BtnAwardDel";
            this.BtnAwardDel.Size = new System.Drawing.Size(60, 28);
            this.BtnAwardDel.TabIndex = 49;
            this.BtnAwardDel.Text = "删除";
            this.BtnAwardDel.UseVisualStyleBackColor = true;
            this.BtnAwardDel.Click += new System.EventHandler(this.BtnAwardDel_Click);
            // 
            // BtnAwardEdit
            // 
            this.BtnAwardEdit.Location = new System.Drawing.Point(366, 356);
            this.BtnAwardEdit.Name = "BtnAwardEdit";
            this.BtnAwardEdit.Size = new System.Drawing.Size(60, 28);
            this.BtnAwardEdit.TabIndex = 48;
            this.BtnAwardEdit.Text = "修改";
            this.BtnAwardEdit.UseVisualStyleBackColor = true;
            this.BtnAwardEdit.Click += new System.EventHandler(this.BtnAwardEdit_Click);
            // 
            // txtAwarditem
            // 
            this.txtAwarditem.Location = new System.Drawing.Point(185, 269);
            this.txtAwarditem.Name = "txtAwarditem";
            this.txtAwarditem.Size = new System.Drawing.Size(307, 21);
            this.txtAwarditem.TabIndex = 24;
            // 
            // CombAwardNum
            // 
            this.CombAwardNum.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CombAwardNum.FormattingEnabled = true;
            this.CombAwardNum.Items.AddRange(new object[] {
            "同屏1人",
            "同屏2人",
            "同屏5人",
            "同屏10人",
            "同屏20人"});
            this.CombAwardNum.Location = new System.Drawing.Point(86, 269);
            this.CombAwardNum.Name = "CombAwardNum";
            this.CombAwardNum.Size = new System.Drawing.Size(93, 20);
            this.CombAwardNum.TabIndex = 23;
            // 
            // CombAwardStyle
            // 
            this.CombAwardStyle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CombAwardStyle.FormattingEnabled = true;
            this.CombAwardStyle.Items.AddRange(new object[] {
            "特等奖",
            "一等奖",
            "二等奖",
            "三等奖",
            "四等奖",
            "五等奖",
            "幸运奖"});
            this.CombAwardStyle.Location = new System.Drawing.Point(6, 269);
            this.CombAwardStyle.Name = "CombAwardStyle";
            this.CombAwardStyle.Size = new System.Drawing.Size(74, 20);
            this.CombAwardStyle.TabIndex = 22;
            // 
            // AwarditemList
            // 
            this.AwarditemList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ID,
            this.AwardStyle,
            this.AwardPage,
            this.AwardNumber,
            this.Awarditem,
            this.AwardBG});
            this.AwarditemList.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AwarditemList.Dock = System.Windows.Forms.DockStyle.Top;
            this.AwarditemList.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.AwarditemList.ForeColor = System.Drawing.Color.Black;
            this.AwarditemList.FullRowSelect = true;
            this.AwarditemList.GridLines = true;
            this.AwarditemList.HideSelection = false;
            this.AwarditemList.Location = new System.Drawing.Point(3, 17);
            this.AwarditemList.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.AwarditemList.Name = "AwarditemList";
            this.AwarditemList.Size = new System.Drawing.Size(492, 245);
            this.AwarditemList.TabIndex = 21;
            this.AwarditemList.UseCompatibleStateImageBehavior = false;
            this.AwarditemList.View = System.Windows.Forms.View.Details;
            this.AwarditemList.ColumnWidthChanging += new System.Windows.Forms.ColumnWidthChangingEventHandler(this.AwarditemList_ColumnWidthChanging);
            this.AwarditemList.Click += new System.EventHandler(this.AwarditemList_Click);
            // 
            // ID
            // 
            this.ID.Text = "ID";
            this.ID.Width = 0;
            // 
            // AwardStyle
            // 
            this.AwardStyle.Text = "奖项";
            this.AwardStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.AwardStyle.Width = 80;
            // 
            // AwardPage
            // 
            this.AwardPage.Text = "每屏人数";
            this.AwardPage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.AwardPage.Width = 80;
            // 
            // AwardNumber
            // 
            this.AwardNumber.Text = "抽取次数";
            this.AwardNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.AwardNumber.Width = 80;
            // 
            // Awarditem
            // 
            this.Awarditem.Text = "奖品";
            this.Awarditem.Width = 181;
            // 
            // AwardBG
            // 
            this.AwardBG.Text = "背景图路径";
            this.AwardBG.Width = 109;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 304);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 12);
            this.label4.TabIndex = 58;
            this.label4.Text = "本轮抽取次数：";
            // 
            // LabTps10
            // 
            this.LabTps10.AutoSize = true;
            this.LabTps10.Location = new System.Drawing.Point(137, 304);
            this.LabTps10.Name = "LabTps10";
            this.LabTps10.Size = new System.Drawing.Size(53, 12);
            this.LabTps10.TabIndex = 53;
            this.LabTps10.Text = "背景图：";
            // 
            // labPlanInfo
            // 
            this.labPlanInfo.AutoSize = true;
            this.labPlanInfo.ForeColor = System.Drawing.Color.SteelBlue;
            this.labPlanInfo.Location = new System.Drawing.Point(11, 467);
            this.labPlanInfo.Name = "labPlanInfo";
            this.labPlanInfo.Size = new System.Drawing.Size(209, 12);
            this.labPlanInfo.TabIndex = 49;
            this.labPlanInfo.Text = "【配置】可进行界面风格的个性化设定";
            // 
            // FrmSetup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(541, 498);
            this.Controls.Add(this.labPlanInfo);
            this.Controls.Add(this.tabControl);
            this.Controls.Add(this.BtnCloseFrm);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmSetup";
            this.Text = "系统配置";
            this.Load += new System.EventHandler(this.FrmSetup_Load);
            this.GroupSign.ResumeLayout(false);
            this.GroupSign.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TxtFontColor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtBGColor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TitleColor)).EndInit();
            this.tabControl.ResumeLayout(false);
            this.SetSign.ResumeLayout(false);
            this.GrpAward.ResumeLayout(false);
            this.GrpAward.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TxtAwardFontColor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicAwardTextBG)).EndInit();
            this.SetAward.ResumeLayout(false);
            this.groupBox.ResumeLayout(false);
            this.groupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AwardNumVal)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox GroupSign;
        private System.Windows.Forms.Label LabTitlefont;
        private System.Windows.Forms.Button BtnBrower;
        private System.Windows.Forms.TextBox txtbackpicpath;
        private System.Windows.Forms.Label LabPicture;
        private System.Windows.Forms.PictureBox TxtBGColor;
        private System.Windows.Forms.Label LabBGColor;
        private System.Windows.Forms.PictureBox TitleColor;
        private System.Windows.Forms.Label LabTitleTxtColor;
        private System.Windows.Forms.TextBox txtTitle;
        private System.Windows.Forms.Button BtnCloseFrm;
        private System.Windows.Forms.Button BtnUpdate;
        private System.Windows.Forms.ColorDialog ColorDialog;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage SetSign;
        private System.Windows.Forms.TabPage SetAward;
        private System.Windows.Forms.PictureBox TxtFontColor;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox;
        private System.Windows.Forms.ListView AwarditemList;
        private System.Windows.Forms.ColumnHeader AwardStyle;
        private System.Windows.Forms.ColumnHeader AwardPage;
        private System.Windows.Forms.ColumnHeader Awarditem;
        private System.Windows.Forms.Button BtnAwardDel;
        private System.Windows.Forms.Button BtnAwardEdit;
        private System.Windows.Forms.TextBox txtAwarditem;
        private System.Windows.Forms.ComboBox CombAwardNum;
        private System.Windows.Forms.ComboBox CombAwardStyle;
        private System.Windows.Forms.ColumnHeader ID;
        private System.Windows.Forms.Button BtnAwardReday;
        private System.Windows.Forms.Button BtnAwardAdd;
        private System.Windows.Forms.Label LabTips4;
        private System.Windows.Forms.GroupBox GrpAward;
        private System.Windows.Forms.Label LabTips3;
        private System.Windows.Forms.Label LabTips1;
        private System.Windows.Forms.Label LabTips2;
        private System.Windows.Forms.PictureBox PicAwardTextBG;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton BGStyleFlag2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton BGStyleFlag1;
        private System.Windows.Forms.Button BtnAwardBGBrower;
        private System.Windows.Forms.TextBox txtAwardBGpath;
        private System.Windows.Forms.Label LabAwardBg;
        private System.Windows.Forms.Label LabTps10;
        private System.Windows.Forms.Button BtnCustomBG;
        private System.Windows.Forms.TextBox txtAwardBG;
        private System.Windows.Forms.Label LabTps9;
        private System.Windows.Forms.Button BtnRestore;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox TxtAwardFontColor;
        private System.Windows.Forms.Label LabAwardFontColor;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ColumnHeader AwardBG;
        private System.Windows.Forms.ColumnHeader AwardNumber;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown AwardNumVal;
        private System.Windows.Forms.Label labPlanInfo;
    }
}