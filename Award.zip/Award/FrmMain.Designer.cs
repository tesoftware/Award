﻿namespace ConferenceSupport
{
    partial class FrmMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            this.StatusStrip = new System.Windows.Forms.StatusStrip();
            this.ClockShow = new System.Windows.Forms.ToolStripStatusLabel();
            this.BottomInfo = new System.Windows.Forms.ToolStripStatusLabel();
            this.ClockTimer = new System.Windows.Forms.Timer(this.components);
            this.ToolStrip = new System.Windows.Forms.ToolStrip();
            this.BtnMain = new System.Windows.Forms.ToolStripButton();
            this.BtnMeetingList = new System.Windows.Forms.ToolStripButton();
            this.BtnAward = new System.Windows.Forms.ToolStripButton();
            this.BtnSetup = new System.Windows.Forms.ToolStripButton();
            this.BtnAbout = new System.Windows.Forms.ToolStripButton();
            this.BtnExit = new System.Windows.Forms.ToolStripButton();
            this.PanelTop = new System.Windows.Forms.Panel();
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.TxtResult = new System.Windows.Forms.RichTextBox();
            this.BtnSpe = new System.Windows.Forms.Button();
            this.BtnNoCheckedList = new System.Windows.Forms.Button();
            this.BtnCheckedList = new System.Windows.Forms.Button();
            this.LabQDN = new System.Windows.Forms.Label();
            this.lab_GZD = new System.Windows.Forms.Label();
            this.TxtKeywords = new System.Windows.Forms.TextBox();
            this.BtnTableRelist = new System.Windows.Forms.Button();
            this.BtnSearch = new System.Windows.Forms.Button();
            this.LabInfo = new System.Windows.Forms.Label();
            this.PanelBottom = new System.Windows.Forms.Panel();
            this.UserListTable = new System.Windows.Forms.ListView();
            this.id = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.person = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.com_no = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.company_name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.remark = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.spe_flag = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.award_flag = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.check_flag = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.signdate = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.sales_name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.sales_dept = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.StatusStrip.SuspendLayout();
            this.ToolStrip.SuspendLayout();
            this.PanelTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).BeginInit();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            this.PanelBottom.SuspendLayout();
            this.SuspendLayout();
            // 
            // StatusStrip
            // 
            this.StatusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ClockShow,
            this.BottomInfo});
            this.StatusStrip.Location = new System.Drawing.Point(0, 708);
            this.StatusStrip.Name = "StatusStrip";
            this.StatusStrip.Size = new System.Drawing.Size(1350, 22);
            this.StatusStrip.TabIndex = 1;
            this.StatusStrip.Text = "statusStrip1";
            // 
            // ClockShow
            // 
            this.ClockShow.Name = "ClockShow";
            this.ClockShow.Size = new System.Drawing.Size(0, 17);
            // 
            // BottomInfo
            // 
            this.BottomInfo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.BottomInfo.Name = "BottomInfo";
            this.BottomInfo.Size = new System.Drawing.Size(228, 17);
            this.BottomInfo.Text = "焦点科技股份有限公司  系统开发部 2019";
            // 
            // ClockTimer
            // 
            this.ClockTimer.Enabled = true;
            this.ClockTimer.Interval = 1000;
            this.ClockTimer.Tick += new System.EventHandler(this.ClockTimer_Tick);
            // 
            // ToolStrip
            // 
            this.ToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.BtnMain,
            this.BtnMeetingList,
            this.BtnAward,
            this.BtnSetup,
            this.BtnAbout,
            this.BtnExit});
            this.ToolStrip.Location = new System.Drawing.Point(0, 0);
            this.ToolStrip.Name = "ToolStrip";
            this.ToolStrip.Size = new System.Drawing.Size(1350, 25);
            this.ToolStrip.TabIndex = 3;
            this.ToolStrip.Text = "toolStrip1";
            // 
            // BtnMain
            // 
            this.BtnMain.Image = ((System.Drawing.Image)(resources.GetObject("BtnMain.Image")));
            this.BtnMain.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnMain.Name = "BtnMain";
            this.BtnMain.Size = new System.Drawing.Size(76, 22);
            this.BtnMain.Text = "数据管理";
            this.BtnMain.ToolTipText = "人员列表";
            this.BtnMain.Click += new System.EventHandler(this.BtnMain_Click);
            // 
            // BtnMeetingList
            // 
            this.BtnMeetingList.Image = ((System.Drawing.Image)(resources.GetObject("BtnMeetingList.Image")));
            this.BtnMeetingList.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnMeetingList.Name = "BtnMeetingList";
            this.BtnMeetingList.Size = new System.Drawing.Size(76, 22);
            this.BtnMeetingList.Text = "参会签到";
            this.BtnMeetingList.ToolTipText = "签到界面";
            this.BtnMeetingList.Click += new System.EventHandler(this.BtnMeetingList_Click);
            // 
            // BtnAward
            // 
            this.BtnAward.Image = ((System.Drawing.Image)(resources.GetObject("BtnAward.Image")));
            this.BtnAward.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnAward.Name = "BtnAward";
            this.BtnAward.Size = new System.Drawing.Size(76, 22);
            this.BtnAward.Text = "现场抽奖";
            this.BtnAward.ToolTipText = "抽奖界面";
            this.BtnAward.Click += new System.EventHandler(this.BtnAward_Click);
            // 
            // BtnSetup
            // 
            this.BtnSetup.Image = ((System.Drawing.Image)(resources.GetObject("BtnSetup.Image")));
            this.BtnSetup.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnSetup.Name = "BtnSetup";
            this.BtnSetup.Size = new System.Drawing.Size(76, 22);
            this.BtnSetup.Text = "系统设置";
            this.BtnSetup.ToolTipText = "系统设置";
            this.BtnSetup.Click += new System.EventHandler(this.BtnSetup_Click);
            // 
            // BtnAbout
            // 
            this.BtnAbout.Image = ((System.Drawing.Image)(resources.GetObject("BtnAbout.Image")));
            this.BtnAbout.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnAbout.Name = "BtnAbout";
            this.BtnAbout.Size = new System.Drawing.Size(76, 22);
            this.BtnAbout.Text = "关于软件";
            this.BtnAbout.ToolTipText = "关于软件";
            this.BtnAbout.Click += new System.EventHandler(this.BtnAbout_Click);
            // 
            // BtnExit
            // 
            this.BtnExit.Image = ((System.Drawing.Image)(resources.GetObject("BtnExit.Image")));
            this.BtnExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnExit.Name = "BtnExit";
            this.BtnExit.Size = new System.Drawing.Size(76, 22);
            this.BtnExit.Text = "退出应用";
            this.BtnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // PanelTop
            // 
            this.PanelTop.Controls.Add(this.splitContainer);
            this.PanelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelTop.Location = new System.Drawing.Point(0, 25);
            this.PanelTop.Name = "PanelTop";
            this.PanelTop.Size = new System.Drawing.Size(1350, 191);
            this.PanelTop.TabIndex = 22;
            // 
            // splitContainer
            // 
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.Location = new System.Drawing.Point(0, 0);
            this.splitContainer.Name = "splitContainer";
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.TxtResult);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.Controls.Add(this.BtnSpe);
            this.splitContainer.Panel2.Controls.Add(this.BtnNoCheckedList);
            this.splitContainer.Panel2.Controls.Add(this.BtnCheckedList);
            this.splitContainer.Panel2.Controls.Add(this.LabQDN);
            this.splitContainer.Panel2.Controls.Add(this.lab_GZD);
            this.splitContainer.Panel2.Controls.Add(this.TxtKeywords);
            this.splitContainer.Panel2.Controls.Add(this.BtnTableRelist);
            this.splitContainer.Panel2.Controls.Add(this.BtnSearch);
            this.splitContainer.Panel2.Controls.Add(this.LabInfo);
            this.splitContainer.Size = new System.Drawing.Size(1350, 191);
            this.splitContainer.SplitterDistance = 1019;
            this.splitContainer.TabIndex = 37;
            // 
            // TxtResult
            // 
            this.TxtResult.BackColor = System.Drawing.Color.Black;
            this.TxtResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TxtResult.ForeColor = System.Drawing.Color.Lime;
            this.TxtResult.Location = new System.Drawing.Point(0, 0);
            this.TxtResult.Name = "TxtResult";
            this.TxtResult.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.TxtResult.Size = new System.Drawing.Size(1019, 191);
            this.TxtResult.TabIndex = 37;
            this.TxtResult.Text = "";
            // 
            // BtnSpe
            // 
            this.BtnSpe.Location = new System.Drawing.Point(65, 157);
            this.BtnSpe.Name = "BtnSpe";
            this.BtnSpe.Size = new System.Drawing.Size(70, 28);
            this.BtnSpe.TabIndex = 55;
            this.BtnSpe.Text = "特别关注";
            this.BtnSpe.UseVisualStyleBackColor = true;
            this.BtnSpe.Click += new System.EventHandler(this.BtnSpe_Click);
            // 
            // BtnNoCheckedList
            // 
            this.BtnNoCheckedList.Location = new System.Drawing.Point(216, 157);
            this.BtnNoCheckedList.Name = "BtnNoCheckedList";
            this.BtnNoCheckedList.Size = new System.Drawing.Size(100, 28);
            this.BtnNoCheckedList.TabIndex = 54;
            this.BtnNoCheckedList.Text = "未签到";
            this.BtnNoCheckedList.UseVisualStyleBackColor = true;
            this.BtnNoCheckedList.Click += new System.EventHandler(this.BtnNoCheckedList_Click);
            // 
            // BtnCheckedList
            // 
            this.BtnCheckedList.Location = new System.Drawing.Point(142, 157);
            this.BtnCheckedList.Name = "BtnCheckedList";
            this.BtnCheckedList.Size = new System.Drawing.Size(70, 28);
            this.BtnCheckedList.TabIndex = 53;
            this.BtnCheckedList.Text = "已签到";
            this.BtnCheckedList.UseVisualStyleBackColor = true;
            this.BtnCheckedList.Click += new System.EventHandler(this.BtnCheckedList_Click);
            // 
            // LabQDN
            // 
            this.LabQDN.AutoSize = true;
            this.LabQDN.Location = new System.Drawing.Point(6, 5);
            this.LabQDN.Name = "LabQDN";
            this.LabQDN.Size = new System.Drawing.Size(119, 12);
            this.LabQDN.TabIndex = 52;
            this.LabQDN.Text = "已签到人员百分比(%)";
            // 
            // lab_GZD
            // 
            this.lab_GZD.BackColor = System.Drawing.Color.Black;
            this.lab_GZD.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_GZD.Font = new System.Drawing.Font("Microsoft Sans Serif", 42F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_GZD.ForeColor = System.Drawing.Color.Yellow;
            this.lab_GZD.Location = new System.Drawing.Point(4, 24);
            this.lab_GZD.Name = "lab_GZD";
            this.lab_GZD.Size = new System.Drawing.Size(312, 95);
            this.lab_GZD.TabIndex = 51;
            this.lab_GZD.Text = "0";
            this.lab_GZD.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TxtKeywords
            // 
            this.TxtKeywords.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtKeywords.ImeMode = System.Windows.Forms.ImeMode.Hangul;
            this.TxtKeywords.Location = new System.Drawing.Point(45, 128);
            this.TxtKeywords.Name = "TxtKeywords";
            this.TxtKeywords.Size = new System.Drawing.Size(165, 21);
            this.TxtKeywords.TabIndex = 49;
            // 
            // BtnTableRelist
            // 
            this.BtnTableRelist.Location = new System.Drawing.Point(4, 157);
            this.BtnTableRelist.Name = "BtnTableRelist";
            this.BtnTableRelist.Size = new System.Drawing.Size(55, 28);
            this.BtnTableRelist.TabIndex = 48;
            this.BtnTableRelist.Text = "刷新";
            this.BtnTableRelist.UseVisualStyleBackColor = true;
            this.BtnTableRelist.Click += new System.EventHandler(this.BtnTableRelist_Click);
            // 
            // BtnSearch
            // 
            this.BtnSearch.Location = new System.Drawing.Point(216, 125);
            this.BtnSearch.Name = "BtnSearch";
            this.BtnSearch.Size = new System.Drawing.Size(100, 28);
            this.BtnSearch.TabIndex = 47;
            this.BtnSearch.Text = "查询";
            this.BtnSearch.UseVisualStyleBackColor = true;
            this.BtnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
            // 
            // LabInfo
            // 
            this.LabInfo.AutoSize = true;
            this.LabInfo.Location = new System.Drawing.Point(7, 133);
            this.LabInfo.Name = "LabInfo";
            this.LabInfo.Size = new System.Drawing.Size(41, 12);
            this.LabInfo.TabIndex = 50;
            this.LabInfo.Text = "查找：";
            // 
            // PanelBottom
            // 
            this.PanelBottom.Controls.Add(this.UserListTable);
            this.PanelBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelBottom.Location = new System.Drawing.Point(0, 216);
            this.PanelBottom.Name = "PanelBottom";
            this.PanelBottom.Size = new System.Drawing.Size(1350, 492);
            this.PanelBottom.TabIndex = 23;
            // 
            // UserListTable
            // 
            this.UserListTable.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.id,
            this.person,
            this.com_no,
            this.company_name,
            this.remark,
            this.spe_flag,
            this.award_flag,
            this.check_flag,
            this.signdate,
            this.sales_name,
            this.sales_dept});
            this.UserListTable.Cursor = System.Windows.Forms.Cursors.Hand;
            this.UserListTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.UserListTable.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.UserListTable.ForeColor = System.Drawing.Color.Black;
            this.UserListTable.FullRowSelect = true;
            this.UserListTable.GridLines = true;
            this.UserListTable.HideSelection = false;
            this.UserListTable.Location = new System.Drawing.Point(0, 0);
            this.UserListTable.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.UserListTable.MultiSelect = false;
            this.UserListTable.Name = "UserListTable";
            this.UserListTable.Size = new System.Drawing.Size(1350, 492);
            this.UserListTable.TabIndex = 21;
            this.UserListTable.UseCompatibleStateImageBehavior = false;
            this.UserListTable.View = System.Windows.Forms.View.Details;
            this.UserListTable.DoubleClick += new System.EventHandler(this.UserListTable_DoubleClick);
            // 
            // id
            // 
            this.id.Text = "id";
            this.id.Width = 0;
            // 
            // person
            // 
            this.person.Text = "姓名";
            this.person.Width = 80;
            // 
            // com_no
            // 
            this.com_no.Text = "编号";
            // 
            // company_name
            // 
            this.company_name.Text = "公司名称";
            this.company_name.Width = 170;
            // 
            // remark
            // 
            this.remark.Text = "备注";
            this.remark.Width = 170;
            // 
            // spe_flag
            // 
            this.spe_flag.Text = "特别关注";
            this.spe_flag.Width = 80;
            // 
            // award_flag
            // 
            this.award_flag.Text = "参与抽奖";
            this.award_flag.Width = 80;
            // 
            // check_flag
            // 
            this.check_flag.Text = "是否签到";
            this.check_flag.Width = 80;
            // 
            // signdate
            // 
            this.signdate.Text = "签到时间";
            this.signdate.Width = 160;
            // 
            // sales_name
            // 
            this.sales_name.Text = "对接销售";
            this.sales_name.Width = 84;
            // 
            // sales_dept
            // 
            this.sales_dept.Text = "对接部门";
            this.sales_dept.Width = 191;
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1350, 730);
            this.Controls.Add(this.PanelBottom);
            this.Controls.Add(this.PanelTop);
            this.Controls.Add(this.ToolStrip);
            this.Controls.Add(this.StatusStrip);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "会务支持系统";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmMain_FormClosing);
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.StatusStrip.ResumeLayout(false);
            this.StatusStrip.PerformLayout();
            this.ToolStrip.ResumeLayout(false);
            this.ToolStrip.PerformLayout();
            this.PanelTop.ResumeLayout(false);
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel2.ResumeLayout(false);
            this.splitContainer.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).EndInit();
            this.splitContainer.ResumeLayout(false);
            this.PanelBottom.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip StatusStrip;
        private System.Windows.Forms.Timer ClockTimer;
        private System.Windows.Forms.ToolStripStatusLabel ClockShow;
        private System.Windows.Forms.ToolStripStatusLabel BottomInfo;
        private System.Windows.Forms.ToolStrip ToolStrip;
        private System.Windows.Forms.ToolStripButton BtnMain;
        private System.Windows.Forms.ToolStripButton BtnMeetingList;
        private System.Windows.Forms.ToolStripButton BtnAward;
        private System.Windows.Forms.ToolStripButton BtnSetup;
        private System.Windows.Forms.ToolStripButton BtnAbout;
        private System.Windows.Forms.Panel PanelTop;
        private System.Windows.Forms.Panel PanelBottom;
        private System.Windows.Forms.ListView UserListTable;
        private System.Windows.Forms.ColumnHeader id;
        private System.Windows.Forms.ColumnHeader person;
        private System.Windows.Forms.ColumnHeader com_no;
        private System.Windows.Forms.ColumnHeader company_name;
        private System.Windows.Forms.ColumnHeader remark;
        private System.Windows.Forms.ColumnHeader spe_flag;
        private System.Windows.Forms.ColumnHeader award_flag;
        private System.Windows.Forms.ColumnHeader check_flag;
        private System.Windows.Forms.ColumnHeader signdate;
        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.RichTextBox TxtResult;
        private System.Windows.Forms.Button BtnNoCheckedList;
        private System.Windows.Forms.Button BtnCheckedList;
        private System.Windows.Forms.Label LabQDN;
        private System.Windows.Forms.Label lab_GZD;
        private System.Windows.Forms.TextBox TxtKeywords;
        private System.Windows.Forms.Button BtnTableRelist;
        private System.Windows.Forms.Button BtnSearch;
        private System.Windows.Forms.Label LabInfo;
        private System.Windows.Forms.ToolStripButton BtnExit;
        private System.Windows.Forms.Button BtnSpe;
        private System.Windows.Forms.ColumnHeader sales_name;
        private System.Windows.Forms.ColumnHeader sales_dept;
    }
}

