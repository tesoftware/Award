﻿using System;
using System.Drawing;
using System.Text;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;

namespace ConferenceSupport
{
    public partial class FrmAwardMain : Form
    {
        public FrmAwardMain()
        {
            InitializeComponent();
        }
        public event TransfDelegate TransfEvent;
        private string FileName = System.IO.Directory.GetCurrentDirectory() + @"\\template\\config.ini";
        private string AwardSelID = "-1";
        
        //参数说明：section：INI文件中的段落；key：INI文件中的关键字；val：INI文件中关键字的数值；filePath：INI文件的完整的路径和名称。
        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);


       //窗体启动
        private void FrmAwardMain_Load(object sender, EventArgs e)
        {
            //屏幕自适应
            int SW = Screen.PrimaryScreen.Bounds.Width;
            int SH = Screen.PrimaryScreen.Bounds.Height;
            this.Width = SW;
            this.Height = SH;
            int subSW = (SW - 840) / 2;
            int subSH = (SH - 600) / 2;
            BtnItemSelect.Location = new Point(subSW, subSH);
            labelExit.Location = new Point(0, 0);
            ReadAwardData();
            ReadiniFile();
        }
        //关闭窗体
        private void labelExit_Click(object sender, EventArgs e)
        {
            TransfEvent("AwardMain");
            this.Close();
        }
        //读取奖池设定
        private void ReadAwardData()
        {
            Application.DoEvents();
            AwarditemList.Items.Clear();
            //奖池配置
            ListViewItem liother = new ListViewItem();
            liother.SubItems.Clear();
            liother.SubItems[0].Text = "0";
            liother.SubItems.Add("进入 奖池配置");
            liother.SubItems.Add("");
            liother.SubItems.Add("生成抽奖者名单和查看中奖信息");
            AwarditemList.Items.Add(liother);
            OleDbConnection odcConnection = new OleDbConnection(Common.strConn());
            if (odcConnection.State == System.Data.ConnectionState.Open) odcConnection.Close();
            odcConnection.Open();
            OleDbCommand odCommand = odcConnection.CreateCommand();
            string sql = "select ID,AwardStyle,AwardPage,AwardItem  from [award] order by ID asc";
            odCommand.CommandText = sql;
            OleDbDataReader DBReader = odCommand.ExecuteReader();            
            while (DBReader.Read())
            {
                ListViewItem li = new ListViewItem();
                li.SubItems.Clear();
                li.SubItems[0].Text = DBReader["ID"].ToString();
                li.SubItems.Add("进入 " +  Common.AwardStyleArr[Int32.Parse(DBReader["AwardStyle"].ToString())] + " 抽奖界面");
                li.SubItems.Add(DBReader["AwardPage"].ToString());
                li.SubItems.Add("奖品： " + DBReader["AwardItem"].ToString());
                AwarditemList.Items.Add(li);
            }
            DBReader.Close();
            odCommand.Dispose();
            odcConnection.Close();
           
        }
        //禁止改变列宽
        private void AwarditemList_ColumnWidthChanging(object sender, ColumnWidthChangingEventArgs e)
        {            
            ColumnHeader header = this.AwarditemList.Columns[e.ColumnIndex];
            e.NewWidth = AwarditemList.Columns[e.ColumnIndex].Width;
            e.Cancel = true;
        }
        //读取ini配置
        private void ReadiniFile()
        {
            if (File.Exists(FileName))
            {
                try
                {
                    StringBuilder temp = new StringBuilder(256);
                    string ColorStr = temp.ToString();
                    string[] sArray = ColorStr.Split('|');                    
                    GetPrivateProfileString("AwardSetup", "AwardBGColor", "", temp, 256, FileName);   //抽奖背景颜色
                    ColorStr = temp.ToString();
                    sArray = ColorStr.Split('|');
                    this.BackColor = Color.FromArgb(Int32.Parse(sArray[0]), Int32.Parse(sArray[1]), Int32.Parse(sArray[2]));
                    BtnItemSelect.BackColor = Color.FromArgb(Int32.Parse(sArray[0]), Int32.Parse(sArray[1]), Int32.Parse(sArray[2]));
                    GetPrivateProfileString("AwardSetup", "AwardFontColor", "", temp, 256, FileName);   //抽奖背景颜色
                    ColorStr = temp.ToString();
                    sArray = ColorStr.Split('|');                    
                    LabMessageInfo.ForeColor = Color.FromArgb(Int32.Parse(sArray[0]), Int32.Parse(sArray[1]), Int32.Parse(sArray[2]));

                    GetPrivateProfileString("AwardSetup", "AwardBGpath", "", temp, 256, FileName);   //签到背景图路径
                    string backpicpath = temp.ToString();
                    if (File.Exists(@backpicpath))
                    {
                        this.BackgroundImage = Image.FromFile(@backpicpath);
                    }
                }
                catch
                {
                    MessageBox.Show("配置文件错误，请检查文件是否完整");
                    Application.Exit();
                }
            }
        }
        //点击项目后生成AwardSelID
        private void AwarditemList_Click(object sender, EventArgs e)
        {  
            AwardSelID = AwarditemList.SelectedItems[0].SubItems[0].Text.Trim(); //得到选中的行          
        }
        //选择面板功能
        private void button1_Click(object sender, EventArgs e)
        {
            if (AwardSelID == "-1")
            {
                MessageBox.Show("请先选中一个项目");
                return; //没有选中就退出
            }
            if (AwardSelID == "0")
            {  //选中奖池列表面板
                FrmAwardUserList frmawarduserlist = new FrmAwardUserList();
                frmawarduserlist.StartPosition = FormStartPosition.Manual;
                frmawarduserlist.ShowDialog(this);
                return;
            }
            //获得奖项ID及屏幕配置            
            FormAwardLucky formawardlucky = new FormAwardLucky();
                                        formawardlucky.PagestyleID =  AwarditemList.SelectedItems[0].SubItems[2].Text.Trim();     //同屏人数
                                        formawardlucky.AwardName =  AwarditemList.SelectedItems[0].SubItems[0].Text.Trim();      //奖项ID
                                        formawardlucky.StartPosition = FormStartPosition.Manual;
                                        formawardlucky.ShowDialog(this);     
        }
    }
}
