﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data.OleDb;

namespace ConferenceSupport
{
    class Access
    {
        //【数据库】执行SQL，用于插入或更改
        public static bool Export_to_DB(string SQL)
        {
            bool okflag = false;
            OleDbConnection odcConnection = new OleDbConnection(Common.strConn());
            if (odcConnection.State == System.Data.ConnectionState.Open) odcConnection.Close();
            odcConnection.Open();
            try
            {
                OleDbCommand odCommand = odcConnection.CreateCommand();
                odCommand.CommandText = SQL;
                odCommand.ExecuteNonQuery();
                Common.WriteLog("--" + SQL);
                okflag = true;                            
            }
            catch (Exception ex)
            {
                Common.WriteLog(SQL);
                Common.WriteLog("执行数据库操作命令出错" + ex.ToString());    
            }
            finally
            {
                if (odcConnection != null && odcConnection.State == System.Data.ConnectionState.Open)
                {
                    odcConnection.Close(); // 关闭连接  
                }
            }
            return okflag;
        }
        //【数据库】执行SQL请求，返回字符串 , 返回数据条目可以由SQL中的Limit 来确定
        public static string RunSqlToDB(string SQL)
        {
            OleDbConnection odcConnection = new OleDbConnection(Common.strConn());
            string ss = "none";
            string infostr = "";
            try
            {                
                odcConnection.Open();
                OleDbCommand odCommand = odcConnection.CreateCommand();
                odCommand.CommandText = SQL;
                OleDbDataReader odrCount = odCommand.ExecuteReader();                
                odrCount.Read();
                infostr = odrCount[0].ToString();
                odCommand.Dispose();
                odrCount.Close();
                if (infostr != "") ss = infostr;
            }
            catch
            {
                ss = "none";                
            }
            finally
            {
                if (odcConnection.State == System.Data.ConnectionState.Open) odcConnection.Close();
            }
            return ss;
        }
        //强制转为utf8
        public static string get_uft8(string unicodeString)
        {
            UTF8Encoding utf8 = new UTF8Encoding();
            Byte[] encodedBytes = utf8.GetBytes(unicodeString);
            String decodedString = utf8.GetString(encodedBytes);
            return decodedString;
        }
        //检查是否有重复
        public static bool CheckRpeat_DB(string idcard)
        {
            if (idcard.Length == 0) return false;
            bool okflag = false;
            string sql =  "select count(*) as result from  [employee] where barcode = '" + idcard + "'";
            string result = Access.RunSqlToDB(sql);            
            if (Convert.ToInt32(result) == 0) okflag = true;   //等于0就是没有重复的
            if (result == "none") okflag = false;  //出错了就返回假
            return okflag;
        }
    }
}
