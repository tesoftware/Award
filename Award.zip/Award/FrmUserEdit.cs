﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;
using System.Text;
using System.Net;
using LitJson;

namespace ConferenceSupport
{
    public delegate void TransfDelegate(String value);
    public partial class FrmUserEdit : Form
    {
        public FrmUserEdit()
        {
            InitializeComponent();
        }
        public string Personeid
        {
            get { return eid; }
            set { eid = value; }
        }

        private string eid = "0";            //编辑人员ID
        public event TransfDelegate TransfEvent;
        #region 公共函数
        //EXCEL导入列表数据
        public DataSet ExcelToDS(string Path)
        {
            string strConn = "Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=" + Path + ";" + "Extended Properties=Excel 12.0;";
            OleDbConnection conn = new OleDbConnection(strConn);
            conn.Open();
            string strExcel = "";
            OleDbDataAdapter myCommand = null;
            DataSet ds = null;
            strExcel = "select * from [sheet1$]";
            myCommand = new OleDbDataAdapter(strExcel, strConn);
            ds = new DataSet();
            myCommand.Fill(ds, "table1");
            conn.Close();
            return ds;
        }
        //清除全部数据按钮
        private void BtnClearList_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("确定要清除全部人员吗? 清除后数据将不可恢复", "清除确认", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                ClearAllPersondate();
                MessageBox.Show("全部数据清除完成！");
                TransfEvent("clear");
            }
        }
        //清除数据操作
        private void ClearAllPersondate()
        {
            string sql = "delete from [employee]";
            if (Access.Export_to_DB(sql) == false)
            {
                MessageBox.Show("执行清除数据操作失败，请检查数据格式是否正确");
                return;
            }
            sql = "delete from [seedlist]";            
            if (Access.Export_to_DB(sql) == false)
            {
                MessageBox.Show("执行清除数据操作失败，请检查数据格式是否正确");
                return;
            }
        }
        //////////////////////////////////////////  POST到服务器 
        private string PostWebRequest(string ServerUrl, string paramData, Encoding dataEncode)
        {
            var responseString = string.Empty;
            try
            {
                byte[] byteArray = dataEncode.GetBytes(paramData); //转化
                HttpWebRequest webReq = (HttpWebRequest)WebRequest.Create(new Uri(ServerUrl));
                webReq.Method = "POST";
                webReq.ContentType = "application/json";
                webReq.UserAgent = "FocusOA";
                webReq.ContentLength = byteArray.Length;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3;
                Stream newStream = webReq.GetRequestStream();
                newStream.Write(byteArray, 0, byteArray.Length);//写入参数
                newStream.Close();
                HttpWebResponse response;
                response = (HttpWebResponse)webReq.GetResponse();
                StreamReader sr = new StreamReader(response.GetResponseStream(), Encoding.Default);
                responseString = sr.ReadToEnd();
                sr.Close();
                sr.Dispose();
            }
            catch
            {
                responseString = @"出现故障，无法完成请求";
            }
            return responseString;
        }
        //////////////////////////////////////////  读取JSON
        private void LoadJson(string meetingjson)
        {
            try
            {
                JsonData jsonstr = JsonMapper.ToObject(meetingjson);
                if (jsonstr[0]["conferenceEnrolmentUsers"].IsArray)
                {
                    int Allcount = jsonstr[0]["conferenceEnrolmentUsers"].Count;
                    int WrongNum = 0;
                    for (int i = 0; i < Allcount; i++)
                    {
                        string sql = "";
                        sql += "'" + jsonstr[0]["conferenceEnrolmentUsers"][i]["messageAuthenticationCode"].ToString() + "',";   //barcode
                        sql += "'" + jsonstr[0]["conferenceEnrolmentUsers"][i]["applyUserName"].ToString() + "',";   //person
                        sql += "'" + jsonstr[0]["conferenceEnrolmentUsers"][i]["comId"].ToString() + "',";   //emp_no
                        sql += "'" + jsonstr[0]["conferenceEnrolmentUsers"][i]["comNameCn"].ToString() + "',"; //com_name
                        sql += "'人数：" + jsonstr[0]["conferenceEnrolmentUsers"][i]["memberCount"].ToString() + "',";  //参会人数
                        sql = "insert into [employee] (barcode,person,comp_no,company_name,remark,spe_flag,award_flag,check_flag,ok_flag,signdate,recdate) values (" + sql + "'0','1','0','0','','0','0')";
                        if (Access.Export_to_DB(sql) == false) WrongNum++;
                    }
                    //根据失败情况整理
                    if (WrongNum > 0)
                    {
                        MessageBox.Show("获取成功，共获得 " + Allcount.ToString() + " 条签到人员信息，其中有 " + WrongNum.ToString() + " 条信息导入失败，请检查数据源");
                    }
                    else
                    {
                        MessageBox.Show("获取成功，共获得 " + Allcount.ToString() + " 条签到人员信息");
                    }
                    TransfEvent("batchin");
                }
            }
            catch
            {
                MessageBox.Show("获取信息解析失败，请检查接口是否正确", "获取失败", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        //////////////////////////////////////////  GET方式提交到服务器
        private string GetWebRequest(string ServerUrl, Encoding dataEncode)
        {
            var responseString = string.Empty;
            try
            {
                var request = (HttpWebRequest)WebRequest.Create(ServerUrl);
                request.ContentType = "application/json";
                var response = (HttpWebResponse)request.GetResponse();
                responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
            }
            catch
            {
                responseString = @"出现故障";
            }
            return responseString;
        }
        //关闭窗体
        private void BtnCloseSec_Click(object sender, EventArgs e)
        {
            TransfEvent("close");
            this.Close();
        }
        #endregion
        #region 窗体操作
        private void FrmUserList_Load(object sender, EventArgs e)
        {
            LabDatashow.Text = "请选择指定的数据源";
            if (eid == "0")
            {
                TabUserDushboard.SelectedIndex = 1;
            }
            //当窗体是编辑状态，则显示删除框
            if (eid != "0")
            {
                chkdel_flag.Visible = true;
                try
                {
                    string sql = "";
                    OleDbConnection odcConnection = new OleDbConnection(Common.strConn());
                    if (odcConnection.State == System.Data.ConnectionState.Open) odcConnection.Close();
                    odcConnection.Open();
                    OleDbCommand odCommand = odcConnection.CreateCommand();
                    sql = "SELECT * FROM  [employee] WHERE eid = " + eid;
                    odCommand.CommandText = sql;
                    OleDbDataReader DBReader = odCommand.ExecuteReader();
                    if (DBReader.Read())
                    {
                        txtPerson.Text = DBReader["person"].ToString();
                        txtcomp_no.Text = DBReader["comp_no"].ToString().PadLeft(6, '0');
                        txtcompany_name.Text = DBReader["company_name"].ToString();
                        txtbarcode.Text = DBReader["barcode"].ToString();
                        txtremark.Text = DBReader["remark"].ToString();
                        txtsales.Text = DBReader["sales_name"].ToString();
                        txtsalesdept.Text = DBReader["sales_dept"].ToString();
                        chkaward_flag.Checked = (DBReader["award_flag"].ToString() == "1") ? (true) : (false);
                        chkspe_flag.Checked = (DBReader["spe_flag"].ToString() == "1") ? (true) : (false);
                        chkcheck_flag.Checked = (DBReader["check_flag"].ToString() == "1") ? (true) : (false);
                        chkok_flag.Checked = (DBReader["ok_flag"].ToString() == "1") ? (true) : (false);
                        chkdel_flag.Checked = (DBReader["del_flag"].ToString() == "1") ? (true) : (false);
                    }
                    DBReader.Close();
                    odCommand.Dispose();
                    odcConnection.Close();
                }
                catch { }
            } 
        }
        private void BtnCloseFrm_Click(object sender, EventArgs e)
        {
            TransfEvent("close");
            this.Close();
        }
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            //验证表单
            if (Common.CheckSql(txtbarcode.Text).Length < 5) { MessageBox.Show("请填写二维码字串，至少6位，工号请补零"); return; }
            if (Common.CheckSql(txtPerson.Text).Length < 2) { MessageBox.Show("请填写用户姓名，至少两个字符"); return; }
            if (Common.CheckSql(txtcomp_no.Text).Length == 0) { MessageBox.Show("请填定编号，六位数字"); return; }
            if (Common.CheckSql(txtcompany_name.Text).Length == 0) { MessageBox.Show("请填定公司名称或部门名称"); return; }    
            //验证，二维码不可重复
            string bkinfo = Access.RunSqlToDB("select count(*) as result from [employee] where barcode = '" + Common.CheckSql(txtbarcode.Text) + "'");
            if (bkinfo != "none")
            {
                if ((int.Parse(bkinfo) > 0) && (eid == "0")) { MessageBox.Show("二维码字串有重复，请重新输入"); return; }
                if ((int.Parse(bkinfo) > 1) && (eid != "0")) { MessageBox.Show("二维码字串有重复，请重新输入"); return; }
            }

            DateTime dt = DateTime.Now;
            List<string> list = new List<string>();
                list.Add(Common.CheckSql(txtbarcode.Text));
                list.Add(Common.CheckSql(txtPerson.Text));
                list.Add(Common.CheckSql(txtcomp_no.Text));
                list.Add(Common.CheckSql(txtcompany_name.Text));
                list.Add((chkdel_flag.Checked)?("1"):("0"));
                list.Add((chkcheck_flag.Checked)?("1"):("0"));
                list.Add((chkok_flag.Checked)?("1"):("0"));
                list.Add((chkspe_flag.Checked)?("1"):("0"));
                list.Add(Common.CheckSql(txtremark.Text));                            
                list.Add((chkcheck_flag.Checked)?(Common.NowStamp()):("0"));   //签到时间
                list.Add(dt.ToString("yyyyMMddHHmmss"));   //最后一次操作时间
                list.Add((chkaward_flag.Checked)?("1"):("0"));
                list.Add(Common.CheckSql(txtsales.Text));
                list.Add(Common.CheckSql(txtsalesdept.Text));
            string str = string.Join("','", list.ToArray());
            //生成SQL
            string sql = string.Empty; 
            if (eid == "0")
            {
                sql = "insert into [employee] (barcode,person,comp_no,company_name,del_flag,check_flag,ok_flag,spe_flag,remark,signdate,recdate,award_flag,sales_name,sales_dept) values ('" + str + "')";
                //新增完成，清空列表。防止误操作
                txtbarcode.Text = "";
                txtPerson.Text = "";
                txtcomp_no.Text = "";
                txtcompany_name.Text = "";
                txtremark.Text = "";
                txtsales.Text = "";
                txtsalesdept.Text = "";
                chkdel_flag.Checked = false;
                chkcheck_flag.Checked = false;
                chkok_flag.Checked = false;
                chkspe_flag.Checked = false;
                chkaward_flag.Checked = false;
                if (Access.Export_to_DB(sql) == false) MessageBox.Show("执行失败，请检查数据格式是否正确");
                list.Clear();
                TransfEvent("add");
                MessageBox.Show("增加人员信息成功！");
            }
            else
            {
                if (list[5] == "0") list[9] = "0";
                sql = "update [employee] set";
                sql += " barcode = '" + list[0] + "',";
                sql += " person = '" + list[1] + "',";
                sql += " comp_no = '" + list[2] + "',";
                sql += " company_name = '" + list[3] + "',";
                sql += " del_flag = '" + list[4] + "',";
                sql += " check_flag = '" + list[5] + "',";
                sql += " ok_flag = '" + list[6] + "',";
                sql += " spe_flag = '" + list[7] + "',";
                sql += " remark = '" + list[8] + "',";
                sql += " signdate = '" + list[9] + "',";
                sql += " recdate = '" + list[10] + "',";
                sql += " award_flag = '" + list[11] + "',";
                sql += " sales_name = '" + list[12] + "',";
                sql += " sales_dept = '" + list[13] + "' where eid = " + eid;        
                if (Access.Export_to_DB(sql) == false) MessageBox.Show("执行失败，请检查数据格式是否正确");
                list.Clear();                
                TransfEvent("edit");
                this.Close();
            }           
        }
        //批量人员导入
        private void BtnSynchronize_Click(object sender, EventArgs e)
        {
            string OpenFilePath = "";
            OpenFileDialog opf = new OpenFileDialog();
            opf.Title = "请选择人员模板文件或中奖名单文件";
            opf.Filter = "Excel2007(*.xlsx)|*.xlsx|中奖记录(*.awd)|*.awd|旧模板文件(*.xls)|*.xls";
            if (opf.ShowDialog() == DialogResult.OK)
            {                
                try
                {
                    //两种文件，要判断
                    string hz = opf.FileName.Substring(opf.FileName.Length - 3, 3);
                    if (hz == "awd")
                    {
                        string sql = string.Empty;
                        ProgressBarLOC.Maximum = 100;
                        ProgressBarLOC.Value = 0;
                        int i = 1;
                        int Barnum = 0;                          
                        OpenFilePath = opf.FileName;
                        string readstr = string.Empty;
                        //判断文件有多少行
                        int lineCount = 0;
                        using (StreamReader readerline = new StreamReader(OpenFilePath))
                        {
                            while (readerline.ReadLine() != null)
                            {
                                lineCount++;
                            }
                        }
                        if (lineCount == 0) return;
                        if (MessageBox.Show("此文件共有" + lineCount.ToString() + " 条中奖记录，确定导入吗?", "导入确认", MessageBoxButtons.YesNo) == DialogResult.Yes)
                        {
                            DateTime dt = DateTime.Now;
                            FileStream fs = new FileStream(OpenFilePath, FileMode.Open);
                            StreamReader reader = new StreamReader(fs, UnicodeEncoding.GetEncoding("gbk"));
                            while ((readstr = reader.ReadLine()) != null)
                            {
                                Application.DoEvents();
                                readstr = readstr.Trim().ToString();
                                string[] sArray = readstr.Split('\t');
                                if ((sArray.Length == 5) && (sArray[0].Length > 0))
                                {
                                    System.Threading.Thread.Sleep(100);
                                    if (Access.CheckRpeat_DB(sArray[0]) == true)
                                    {
                                        sql = "insert into [employee] (eid,barcode,person,comp_no,company_name,remark,check_flag,ok_flag,spe_flag,signdate,recdate,sales_name,sales_dept)";
                                        sql += " values (" + i.ToString() + ",'" + sArray[0].Trim() + "','" + sArray[1].Trim() + "','" + sArray[2].Trim() + "','" + sArray[3].Trim() + "','" + sArray[4].Trim() + "','0','0','0','" + dt.ToString("yyyyMMddHHmmss") + "','" + dt.ToString("yyyyMMddHHmmss") + "','','')";
                                        if (Access.Export_to_DB(sql) == false) Common.WriteLog("数据格式错误:" + sql);
                                    }
                                    Barnum = 100 * i / lineCount;
                                    ProgressBarLOC.Value = Barnum;
                                    Labmsg.Text = "正在导入第 " + i.ToString() + " 条中奖信息";
                                    i++;
                                }
                            }
                            fs.Close();
                            ProgressBarLOC.Value = 100;
                            TransfEvent("ok");
                            MessageBox.Show("人员信息已导入完成");
                        }
                    }
                    else
                    {
                        //清空
                        ClearAllPersondate();
                        //导入Excel
                        OpenFilePath = opf.FileName;
                        DataSet ds = new DataSet();
                        ds = ExcelToDS(OpenFilePath);
                        int rowCount, i, Barnum, allrow;
                        i = 0;
                        allrow = 0;
                        string cf1, cf2, cf3;
                        rowCount = ds.Tables[0].Rows.Count;
                        if (MessageBox.Show("检测到Excel文件共有" + rowCount.ToString() + " 行记录(含空行)，确定导入吗?", "导入确认", MessageBoxButtons.YesNo) == DialogResult.Yes)
                        {
                            Application.DoEvents();
                            string sql = "";
                            string keyvalue = "";
                            ProgressBarLOC.Maximum = 100;
                            ProgressBarLOC.Value = 0;
                            for (i = 0; i < rowCount; i++)
                            {
                                if (ds.Tables[0].Rows[i][1].ToString() != "")
                                {
                                    allrow++;
                                    DateTime dt = DateTime.Now;
                                    cf1 = "0";
                                    cf2 = "0";
                                    cf3 = "0";
                                    if (ds.Tables[0].Rows[i][5].ToString() == "是") cf1 = "1";
                                    if (ds.Tables[0].Rows[i][6].ToString() == "是") cf2 = "1";
                                    if (ds.Tables[0].Rows[i][7].ToString() == "是") cf3 = "1";

                                    keyvalue = string.Empty;
                                    keyvalue += "'" + ds.Tables[0].Rows[i][0].ToString() + "',";        //二维码
                                    keyvalue += "'" + ds.Tables[0].Rows[i][1].ToString() + "',";        //姓名
                                    keyvalue += "'" + ds.Tables[0].Rows[i][2].ToString() + "',";        //公司编号(工号)
                                    keyvalue += "'" + ds.Tables[0].Rows[i][3].ToString() + "',";        //公司名称（部门）
                                    keyvalue += "'" + ds.Tables[0].Rows[i][4].ToString() + "',";        //备注
                                    keyvalue += "'" + cf1 + "',";        //是否签到
                                    keyvalue += "'" + cf2 + "',";        //是否已领
                                    keyvalue += "'" + cf3 + "',";        //是否特殊                            
                                    keyvalue += "'" + ds.Tables[0].Rows[i][8].ToString() + "',";        //签到时间
                                    keyvalue += "'" + dt.ToString("yyyyMMddHHmmss") + "',";        //录入系统时间
                                    keyvalue += "'" + ds.Tables[0].Rows[i][9].ToString() + "',";        //销售姓名
                                    keyvalue += "'" + ds.Tables[0].Rows[i][10].ToString() + "'";        //销售部门
                                    sql = keyvalue;
                                    //读出来一行，生成sql
                                    //当前日期
                                    sql = "insert into [employee] (eid,barcode,person,comp_no,company_name,remark,check_flag,ok_flag,spe_flag,signdate,recdate,sales_name,sales_dept) values ("+ i.ToString() + "," + sql + ")";
                                    Common.WriteLog(sql);
                                    if (Access.Export_to_DB(sql) == false)
                                    {                                        
                                        MessageBox.Show("执行失败，请检查数据格式是否正确");
                                    }
                                    Barnum = 100 * i / rowCount;
                                    ProgressBarLOC.Value = Barnum;
                                    Labmsg.Text = "正在导入第 " + i.ToString() + " 条人员信息，当前进度 " + Barnum.ToString() + "%";
                                }
                            }
                            ProgressBarLOC.Value = 100;
                            Labmsg.Text = "人员信息已导入完成！共导入了 " + allrow.ToString() + " 条人员信息，当前进度 100%";
                            TransfEvent("ok");
                            MessageBox.Show("人员信息已导入完成！共导入了 " + allrow.ToString() + "条人员信息");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("文档格式不正确，请检查。" + ex.Message);
                    return;
                }
            }
        }
        #endregion
        //导出
        private void BtnExplort_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.SaveFileDialog sfd = new SaveFileDialog();
            sfd.Title = "请选择导入人员信息的路径和文件名";
            sfd.DefaultExt = "txt";
            sfd.Filter = "数据文件(*.txt)|*.txt";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                string str = string.Empty;
                FileStream fs = new FileStream(sfd.FileName, FileMode.OpenOrCreate, FileAccess.Write);
                StreamWriter m_streamWriter = new StreamWriter(fs);
                m_streamWriter.Flush();
                m_streamWriter.BaseStream.Seek(0, SeekOrigin.Begin);
                OleDbConnection odcConnection = new OleDbConnection(Common.strConn());
                if (odcConnection.State == System.Data.ConnectionState.Open) odcConnection.Close();
                odcConnection.Open();
                OleDbCommand odCommand = odcConnection.CreateCommand();
                string sql = "select  eid,person,comp_no,company_name,remark,spe_flag,award_flag,check_flag,signdate,ok_flag,recdate,del_flag,sales_name,sales_dept  from [employee] order by eid asc";
                odCommand.CommandText = sql;
                OleDbDataReader DBReader = odCommand.ExecuteReader();
                while (DBReader.Read())
                {                    
                    str = DBReader["person"].ToString() + "\t";
                    str += DBReader["comp_no"].ToString() + "\t";
                    str += DBReader["company_name"].ToString() + "\t";
                    str += DBReader["remark"].ToString() + "\t";
                    str += (DBReader["check_flag"].ToString() == "1") ? ("已签到") : ("未签到") + "\t";
                    str += Common.DataChange(DBReader["signdate"].ToString()) + "\t";
                    str += DBReader["sales_name"].ToString() + "\t";
                    str += DBReader["sales_dept"].ToString() + "\t";
                    str += (DBReader["del_flag"].ToString() == "1") ? ("已删除") : ("") + "\n";
                    m_streamWriter.Write(str);
                    m_streamWriter.Flush();
                }
                m_streamWriter.Close();
                odCommand.Dispose();
                odcConnection.Close();
                MessageBox.Show("人员信息资料导出完毕！");
            }            
        }
        //统计数据
        private void BtnDataRepoet_Click(object sender, EventArgs e)
        {
            string sql = "select count(*) as result from employee  where del_flag = '0'";  //总人数
            string result = Access.RunSqlToDB(sql);
            LabDatashow.Text = "用户数：" + result + "　　　";
            sql = "select count(*) as result from employee where del_flag = '0' and check_flag = '1'";  //已签到人数
            result = Access.RunSqlToDB(sql);
            LabDatashow.Text += "已签到：" + result + "　　　";
            sql = "select count(*) as result from employee where del_flag = '0' and check_flag = '0'";  //未签到人数
            result = Access.RunSqlToDB(sql);
            LabDatashow.Text += "未签到：" + result + "\n\n";
            sql = "select count(*) as result from employee where del_flag = '0' and spe_flag = '1'";  //特殊用户人数
            result = Access.RunSqlToDB(sql);
            LabDatashow.Text += "特别人员：" + result + "　　　";
            sql = "select count(*) as result from employee where del_flag = '0' and ok_flag = '1'";  //已领取人数
            result = Access.RunSqlToDB(sql);
            LabDatashow.Text += "已领取：" + result + "　　　";
            sql = "select count(*) as result from employee where del_flag = '0' and check_flag = '1' and award_flag = '1'";  //参加抽奖人数
            result = Access.RunSqlToDB(sql);
            LabDatashow.Text += "当前可参加抽奖人数：" + result;
        }
        //生成和下载内容
        private void BtnGetWebRequest_Click(object sender, EventArgs e)
        {
            //验证URL
            if (StrWebUrl.Text.Length == 0)
            {
                MessageBox.Show("请填写请求的网站URL");
                return;
            }
            if (txtmeeting_id.Text.Length == 0)
            {
                MessageBox.Show("请填写会议ID，会议ID由 服务端提供的一串编码");
                return;
            }

            if (MessageBox.Show("导入会清空系统内原有数据，请确认是否要继续操作", "导入确认", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                ClearAllPersondate();
            }
            string url = StrWebUrl.Text + txtmeeting_id.Text + "==";
            string ss = PostWebRequest(url, "", Encoding.UTF8);
            //解析JSON
            LoadJson(ss);           
        }
        //提交签到结果到OSS
        private void BtnPostToOSS_Click(object sender, EventArgs e)
        {
            MessageBox.Show("功能正在开发中...");
            return;            
        }
        //从服务端获取会议信息
        private void GuestRenew_Click(object sender, EventArgs e)
        {
            if (!ConnectOA())
            {
                MessageBox.Show("无法连接OA，请检查网络");
                return;
            }
            try
            {
                string url = @"http://oa.vemic.com/guestmeet/public/get_meet_list";
                Common.WriteLog("download:" + url);
                string ss = PostWebRequest(url, "", Encoding.UTF8);
                JsonData jsonstr = JsonMapper.ToObject(ss);
                if (jsonstr[2].ToString() == "1")                {
                    LabDatashow.Text = "获取活动会议场次列表成功！";
                    JsonData datastr = JsonMapper.ToObject(jsonstr["data"].ToString());
                    DataTable dt = new DataTable();//创建一个数据集
                    dt.Columns.Add("group_name", typeof(String));
                    dt.Columns.Add("id", typeof(String));
                    DataRow dr;
                    for (int i = 0; i < datastr.Count; i++)
                    {
                        dr = dt.NewRow();
                        dr[0] = datastr[i]["group_name"].ToString() + "  (" + datastr[i]["count"].ToString() + ")";
                        dr[1] = datastr[i]["id"].ToString();
                        dt.Rows.Add(dr);
                    }
                    GuestListCom.DataSource = dt;
                    GuestListCom.DisplayMember = "group_name";
                    GuestListCom.ValueMember = "id";
                }
                else
                {
                    MessageBox.Show("获取OA活动会议失败，请检查OA服务端配置");
                }
            }
            catch
            {
                MessageBox.Show("获取OA活动会议失败，请检查网络是否能连接到OA");
            }
        }
        //禁用或启用全部按钮，防用户误操作
        private void DisableCommandBtn(bool key)
        {
            if (!key)
            {
                BtnSynchronize.Enabled = false;
                GuestRenew.Enabled = false;
                GetGuestList.Enabled = false;
                GuestUpload.Enabled = false;
                BtnGetWebRequest.Enabled = false;
                BtnPostToOSS.Enabled = false;
                BtnAllSign.Enabled = false;
                BtnClearList.Enabled = false;
                BtnExplort.Enabled = false;
                BtnDataRepoet.Enabled = false;
                BtnCloseSec.Enabled = false;
            }
            else
            {
                BtnSynchronize.Enabled = true;
                GuestRenew.Enabled = true;
                GetGuestList.Enabled = true;
                GuestUpload.Enabled = true;
                BtnGetWebRequest.Enabled = true;
                BtnPostToOSS.Enabled = true;
                BtnAllSign.Enabled = true;
                BtnClearList.Enabled = true;
                BtnExplort.Enabled = true;
                BtnDataRepoet.Enabled = true;
                BtnCloseSec.Enabled = true;
            }
        }
        //下载活动会议参会人信息到数据库
        private void GetGuestList_Click(object sender, EventArgs e)
        {
            if (!ConnectOA())
            {
                MessageBox.Show("无法连接OA，请检查网络");
                return;
            }
            if (GuestListCom.Text == "")
            {
                LabDatashow.Text = "请先获取并选中一个活动会议";
                MessageBox.Show("请先获取并选中一个活动会议");
                return;
            }

            if (MessageBox.Show("导入会清空系统内原有数据，请确认是否要继续操作", "导入确认", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                ClearAllPersondate();
            }
            string meetid = GuestListCom.SelectedValue.ToString();
            LabDatashow.Text = "下载活动会议 “" + GuestListCom.Text + "” 人员到系统中， ID：" + meetid;
            string request = string.Empty;
            string url = @"http://oa.vemic.com/linksys/guest/download_meetdetail.php?meetid=" + meetid.Trim();            
            try
            {                
                request = GetWebRequest(url, Encoding.UTF8);
                Common.WriteLog("string:" + request);
                JsonData jsonstr = JsonMapper.ToObject(request);
                if (jsonstr.Count > 0)
                {
                    FrmWait wait = new FrmWait();
                    wait.TopMost = true;
                    wait.StartPosition = FormStartPosition.CenterScreen;
                    wait.Show();
                    DisableCommandBtn(false);
                    Application.DoEvents();
                    int WrongNum = 0;
                    int Allcount = 0;
                    //停用所有按钮
                    for (int i = 0; i < jsonstr.Count; i++)
                    {
                     try
                     {
                         Allcount++;
                         //读出来一行，生成sql
                         Application.DoEvents();
                         DateTime dt = DateTime.Now;
                         if (jsonstr[i]["remark"] == null) jsonstr[i]["remark"] = " ";
                         string remark = jsonstr[i]["remark"].ToString();
                         remark = Common.CheckSql(remark); //过滤非法字符                         
                         string sql = "";
                         sql += "'" + jsonstr[i]["barcode"].ToString() + "',";   //barcode
                         sql += "'" + jsonstr[i]["person"].ToString() + "',";   //person
                         sql += "'" + jsonstr[i]["comp_no"].ToString() + "',";   //emp_no
                         sql += "'" + jsonstr[i]["company_name"].ToString() + "',"; //com_name
                         sql += "'" + remark + "',";                                                    //remark                         
                         sql += "'" + jsonstr[i]["check_flag"].ToString() + "',";      //check_flag            
                         sql += "'" + jsonstr[i]["spe_flag"].ToString() + "',";        //spe_flag            
                         sql += "'" + jsonstr[i]["ok_flag"].ToString() + "',";          //ok_flag            
                         sql += "'" + jsonstr[i]["signdate"].ToString() + "',";        //signdate            
                         sql += "'" + jsonstr[i]["sales_name"].ToString() + "',";        //销售
                         sql += "'" + jsonstr[i]["sales_dept"].ToString() + "',";        //销售部门

                         sql = "insert into [employee] (barcode,person,comp_no,company_name,remark,check_flag,spe_flag,ok_flag,signdate,sales_name,sales_dept,recdate) values (" + sql + "'')";                         
                         if (Access.Export_to_DB(sql) == false) WrongNum++;
                     }
                     catch
                     {
                         WrongNum++;
                     }
                 }
                 DisableCommandBtn(true);
                 wait.Close();
                 //根据失败情况整理
                 if (WrongNum > 0)
                 {
                     MessageBox.Show("获取成功，共获得 " + Allcount.ToString() + " 条签到人员信息，其中有 " + WrongNum.ToString() + " 条信息导入失败，请检查数据源");
                     LabDatashow.Text = "获取成功, 但有 " + WrongNum.ToString() + " 条信息导入失败";
                 }
                 else
                 {
                     MessageBox.Show("获取成功，共获得 " + Allcount.ToString() + " 条签到人员信息");
                     LabDatashow.Text = "获取成功，共获得 " + Allcount.ToString() + " 条签到人员信息";
                 }
                 TransfEvent("batchin");
                }
            }
            catch
            {
                MessageBox.Show("从OA活动会议下载人员名单失败，请使用导入Excel的方式更新名单");
                return;
            }
        }
        //上报结果
        private void GuestUpload_Click(object sender, EventArgs e)
        {
            if (!ConnectOA())
            {
                MessageBox.Show("无法连接OA，请检查网络");
                return;
            }
            if (GuestListCom.Text == "")
            {
                MessageBox.Show("请先选中您要上报更新的活动会议");
                return;
            }
            Common.WriteLog("上传签到记录");     
            if (MessageBox.Show("确定更新 【" + GuestListCom.Text  + "】 签到数据到OA吗？", "上传数据确认", MessageBoxButtons.YesNo) != DialogResult.Yes) return;
            try
            {
                string meetid = GuestListCom.SelectedValue.ToString();
                string json = string.Empty;
                JsonData data = new JsonData();
                //指定为JsonObject
                data.SetJsonType(JsonType.Object);
                //指定为JsonArray
                data.SetJsonType(JsonType.Array);
                JsonData requestObj = new JsonData();
                OleDbConnection odcConnection = new OleDbConnection(Common.strConn());
                if (odcConnection.State == System.Data.ConnectionState.Open) odcConnection.Close();
                odcConnection.Open();
                OleDbCommand odCommand = odcConnection.CreateCommand();
                string sql = "select * from employee where del_flag = '0'";
                odCommand.CommandText = sql;
                OleDbDataReader DBReader = odCommand.ExecuteReader();
                while (DBReader.Read())
                {
                      string checkdate = DBReader["signdate"].ToString();
                    if (checkdate == "")
                    {
                        checkdate = "0";
                    }
                    requestObj["meet_id"] = meetid;
                    requestObj["barcode"] = DBReader["barcode"].ToString();
                    requestObj["data"] = new JsonData();
                    JsonData array = new JsonData();
                    array.SetJsonType(JsonType.Array);
                    JsonData param_data = new JsonData();
                    param_data["person"] = DBReader["person"].ToString();
                    param_data["comp_no"] = DBReader["comp_no"].ToString();
                    param_data["company_name"] = DBReader["company_name"].ToString();                    
                    param_data["spe_flag"] = DBReader["spe_flag"].ToString();
                    param_data["award_flag"] = DBReader["award_flag"].ToString();                    
                    param_data["check_flag"] = DBReader["check_flag"].ToString();
                    param_data["ok_flag"] = DBReader["ok_flag"].ToString();
                    param_data["spe_flag"] = DBReader["spe_flag"].ToString();
                    param_data["remark"] = DBReader["remark"].ToString();
                    param_data["signdate"] = checkdate;
                    param_data["manager_name"] = DBReader["sales_name"].ToString();
                    param_data["area"] = DBReader["sales_dept"].ToString();
                    array.Add(param_data);
                    requestObj["data"] = array;
                    json += JsonMapper.ToJson(requestObj) + ",\n";
                }
                json = json.Remove(json.Length - 2, 2);
                json= "[\n" + json + "]\n";
              Common.WriteLog(json);     
                //提交结果到OA                
              string url = @"http://oa.vemic.com/linksys/guest/update_meetlist.php";
              string ss = PostWebRequest(url, json, Encoding.UTF8);
              Common.WriteLog("service result:" + ss);
              if (ss == "ok"){
                    MessageBox.Show("上传成功！签到数据已更新到服务器");
                }else{
                    MessageBox.Show("上传失败，操作过程中出现错误，请重试");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("上传失败，网络连接错误，请重试" + ex.ToString());
                Common.WriteLog(ex.ToString());     
            }              
        }
        //全部设为已签到，用于抽奖
        private void BtnAllSign_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("确定要把全部人员都设为已签到吗？", "确认", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                DateTime dt = DateTime.Now;
                string sql = "update [employee] set check_flag = '1', signdate = '" + Common.NowStamp() + "' where check_flag = '0' and del_flag = '0'";
                Access.Export_to_DB(sql);
                TransfEvent("ok");
                MessageBox.Show("全部未签到人员已设置为已签到状态！");
            }
        }
        //调试按钮，连接OA
        private bool ConnectOA()
        {
            return true;          
        }
        //增加新人员
        private void BtnAddNew_Click(object sender, EventArgs e)
        {
            //验证表单
            if (Common.CheckSql(txtbarcode.Text).Length < 5) { MessageBox.Show("请填写二维码字串，至少6位，工号请补零"); return; }
            if (Common.CheckSql(txtPerson.Text).Length < 2) { MessageBox.Show("请填写用户姓名，至少两个字符"); return; }
            if (Common.CheckSql(txtcomp_no.Text).Length == 0) { MessageBox.Show("请填定编号，六位数字"); return; }
            if (Common.CheckSql(txtcompany_name.Text).Length == 0) { MessageBox.Show("请填定公司名称或部门名称"); return; }
            //验证，二维码不可重复
            string bkinfo = Access.RunSqlToDB("select count(*) as result from [employee] where barcode = '" + Common.CheckSql(txtbarcode.Text) + "'");
            if (bkinfo != "none")
            {
                if (int.Parse(bkinfo) > 0) { 
                    MessageBox.Show("二维码字串有重复，请重新输入"); 
                    return; 
                }
            }

            DateTime dt = DateTime.Now;
            List<string> list = new List<string>();
            list.Add(Common.CheckSql(txtbarcode.Text));
            list.Add(Common.CheckSql(txtPerson.Text));
            list.Add(Common.CheckSql(txtcomp_no.Text));
            list.Add(Common.CheckSql(txtcompany_name.Text));
            list.Add((chkdel_flag.Checked) ? ("1") : ("0"));
            list.Add((chkcheck_flag.Checked) ? ("1") : ("0"));
            list.Add((chkok_flag.Checked) ? ("1") : ("0"));
            list.Add((chkspe_flag.Checked) ? ("1") : ("0"));
            list.Add(Common.CheckSql(txtremark.Text));
            list.Add((chkcheck_flag.Checked) ? (Common.NowStamp()) : ("0"));   //签到时间
            list.Add(dt.ToString("yyyyMMddHHmmss"));   //最后一次操作时间
            list.Add((chkaward_flag.Checked) ? ("1") : ("0"));
            list.Add(Common.CheckSql(txtsales.Text));
            list.Add(Common.CheckSql(txtsalesdept.Text));
            string str = string.Join("','", list.ToArray());
            //生成SQL
            string sql = string.Empty;
            sql = "insert into [employee] (barcode,person,comp_no,company_name,del_flag,check_flag,ok_flag,spe_flag,remark,signdate,recdate,award_flag,sales_name,sales_dept) values ('" + str + "')";
            //新增完成，清空列表。防止误操作
            txtbarcode.Text = "";
            txtPerson.Text = "";
            txtcomp_no.Text = "";
            txtcompany_name.Text = "";
            txtremark.Text = "";
            txtsales.Text = "";
            txtsalesdept.Text = "";
            chkdel_flag.Checked = false;
            chkcheck_flag.Checked = false;
            chkok_flag.Checked = false;
            chkspe_flag.Checked = false;
            chkaward_flag.Checked = false;
            if (Access.Export_to_DB(sql) == false) MessageBox.Show("执行失败，请检查数据格式是否正确");
            list.Clear();
            TransfEvent("add");
            MessageBox.Show("增加人员信息成功！");   
        }
    }
}
