﻿namespace ConferenceSupport
{
    partial class FrmAwardUserList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmAwardUserList));
            this.BackBoard = new System.Windows.Forms.Panel();
            this.Btn_ExploreExcel = new System.Windows.Forms.Button();
            this.Btn_BackHome = new System.Windows.Forms.Button();
            this.BtnDatashow = new System.Windows.Forms.Button();
            this.BtnExportAwardList = new System.Windows.Forms.Button();
            this.BtnMarkdata = new System.Windows.Forms.Button();
            this.SeedList = new System.Windows.Forms.ListView();
            this.ID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.deptname = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.username = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.employee_no = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.award_flag = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.LabMessageInfo = new System.Windows.Forms.Label();
            this.labelExit = new System.Windows.Forms.Label();
            this.BackBoard.SuspendLayout();
            this.SuspendLayout();
            // 
            // BackBoard
            // 
            this.BackBoard.Controls.Add(this.Btn_ExploreExcel);
            this.BackBoard.Controls.Add(this.Btn_BackHome);
            this.BackBoard.Controls.Add(this.BtnDatashow);
            this.BackBoard.Controls.Add(this.BtnExportAwardList);
            this.BackBoard.Controls.Add(this.BtnMarkdata);
            this.BackBoard.Controls.Add(this.SeedList);
            this.BackBoard.Controls.Add(this.LabMessageInfo);
            this.BackBoard.Location = new System.Drawing.Point(82, 106);
            this.BackBoard.Name = "BackBoard";
            this.BackBoard.Size = new System.Drawing.Size(840, 520);
            this.BackBoard.TabIndex = 2;
            // 
            // Btn_ExploreExcel
            // 
            this.Btn_ExploreExcel.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Btn_ExploreExcel.Location = new System.Drawing.Point(521, 469);
            this.Btn_ExploreExcel.Name = "Btn_ExploreExcel";
            this.Btn_ExploreExcel.Size = new System.Drawing.Size(140, 40);
            this.Btn_ExploreExcel.TabIndex = 28;
            this.Btn_ExploreExcel.Text = "导出发奖名单";
            this.Btn_ExploreExcel.UseVisualStyleBackColor = true;
            this.Btn_ExploreExcel.Click += new System.EventHandler(this.Btn_ExploreExcel_Click);
            // 
            // Btn_BackHome
            // 
            this.Btn_BackHome.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Btn_BackHome.Location = new System.Drawing.Point(667, 469);
            this.Btn_BackHome.Name = "Btn_BackHome";
            this.Btn_BackHome.Size = new System.Drawing.Size(160, 40);
            this.Btn_BackHome.TabIndex = 27;
            this.Btn_BackHome.Text = "返回主选单";
            this.Btn_BackHome.UseVisualStyleBackColor = true;
            this.Btn_BackHome.Click += new System.EventHandler(this.Btn_BackHome_Click);
            // 
            // BtnDatashow
            // 
            this.BtnDatashow.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.BtnDatashow.Location = new System.Drawing.Point(229, 469);
            this.BtnDatashow.Name = "BtnDatashow";
            this.BtnDatashow.Size = new System.Drawing.Size(140, 40);
            this.BtnDatashow.TabIndex = 26;
            this.BtnDatashow.Text = "数据统计";
            this.BtnDatashow.UseVisualStyleBackColor = true;
            this.BtnDatashow.Click += new System.EventHandler(this.BtnDatashow_Click);
            // 
            // BtnExportAwardList
            // 
            this.BtnExportAwardList.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.BtnExportAwardList.Location = new System.Drawing.Point(375, 469);
            this.BtnExportAwardList.Name = "BtnExportAwardList";
            this.BtnExportAwardList.Size = new System.Drawing.Size(140, 40);
            this.BtnExportAwardList.TabIndex = 24;
            this.BtnExportAwardList.Text = "导出.csv";
            this.BtnExportAwardList.UseVisualStyleBackColor = true;
            this.BtnExportAwardList.Click += new System.EventHandler(this.BtnExportAwardList_Click);
            // 
            // BtnMarkdata
            // 
            this.BtnMarkdata.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.BtnMarkdata.ForeColor = System.Drawing.Color.Red;
            this.BtnMarkdata.Location = new System.Drawing.Point(2, 469);
            this.BtnMarkdata.Name = "BtnMarkdata";
            this.BtnMarkdata.Size = new System.Drawing.Size(160, 40);
            this.BtnMarkdata.TabIndex = 23;
            this.BtnMarkdata.Text = "生成奖池数据";
            this.BtnMarkdata.UseVisualStyleBackColor = true;
            this.BtnMarkdata.Click += new System.EventHandler(this.BtnMarkdata_Click);
            // 
            // SeedList
            // 
            this.SeedList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ID,
            this.deptname,
            this.username,
            this.employee_no,
            this.award_flag,
            this.columnHeader1});
            this.SeedList.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SeedList.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.SeedList.ForeColor = System.Drawing.Color.Black;
            this.SeedList.FullRowSelect = true;
            this.SeedList.GridLines = true;
            this.SeedList.HideSelection = false;
            this.SeedList.Location = new System.Drawing.Point(2, 37);
            this.SeedList.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.SeedList.Name = "SeedList";
            this.SeedList.Size = new System.Drawing.Size(825, 426);
            this.SeedList.TabIndex = 22;
            this.SeedList.UseCompatibleStateImageBehavior = false;
            this.SeedList.View = System.Windows.Forms.View.Details;
            this.SeedList.ColumnWidthChanging += new System.Windows.Forms.ColumnWidthChangingEventHandler(this.SeedList_ColumnWidthChanging);
            // 
            // ID
            // 
            this.ID.Text = "ID";
            this.ID.Width = 0;
            // 
            // deptname
            // 
            this.deptname.Text = "所属公司/部门";
            this.deptname.Width = 280;
            // 
            // username
            // 
            this.username.Text = "姓名";
            this.username.Width = 104;
            // 
            // employee_no
            // 
            this.employee_no.Text = "编号/工号";
            this.employee_no.Width = 136;
            // 
            // award_flag
            // 
            this.award_flag.Text = "中奖信息";
            this.award_flag.Width = 92;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "奖品";
            this.columnHeader1.Width = 341;
            // 
            // LabMessageInfo
            // 
            this.LabMessageInfo.BackColor = System.Drawing.Color.Transparent;
            this.LabMessageInfo.Font = new System.Drawing.Font("微软雅黑", 18F, System.Drawing.FontStyle.Bold);
            this.LabMessageInfo.ForeColor = System.Drawing.Color.Black;
            this.LabMessageInfo.Location = new System.Drawing.Point(255, -6);
            this.LabMessageInfo.Name = "LabMessageInfo";
            this.LabMessageInfo.Size = new System.Drawing.Size(300, 40);
            this.LabMessageInfo.TabIndex = 0;
            this.LabMessageInfo.Text = "奖池数据列表";
            this.LabMessageInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelExit
            // 
            this.labelExit.BackColor = System.Drawing.Color.Transparent;
            this.labelExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.labelExit.Image = ((System.Drawing.Image)(resources.GetObject("labelExit.Image")));
            this.labelExit.Location = new System.Drawing.Point(0, 0);
            this.labelExit.Name = "labelExit";
            this.labelExit.Size = new System.Drawing.Size(32, 32);
            this.labelExit.TabIndex = 10;
            this.labelExit.Click += new System.EventHandler(this.labelExit_Click);
            // 
            // FrmAwardUserList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1024, 768);
            this.Controls.Add(this.labelExit);
            this.Controls.Add(this.BackBoard);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmAwardUserList";
            this.ShowInTaskbar = false;
            this.Text = "FrmAwardUserList";
            this.Load += new System.EventHandler(this.FrmAwardUserList_Load);
            this.BackBoard.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel BackBoard;
        private System.Windows.Forms.ListView SeedList;
        private System.Windows.Forms.ColumnHeader ID;
        private System.Windows.Forms.ColumnHeader username;
        private System.Windows.Forms.ColumnHeader employee_no;
        private System.Windows.Forms.ColumnHeader deptname;
        private System.Windows.Forms.Label LabMessageInfo;
        private System.Windows.Forms.Label labelExit;
        private System.Windows.Forms.ColumnHeader award_flag;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.Button BtnMarkdata;
        private System.Windows.Forms.Button BtnExportAwardList;
        private System.Windows.Forms.Button BtnDatashow;
        private System.Windows.Forms.Button Btn_BackHome;
        private System.Windows.Forms.Button Btn_ExploreExcel;
    }
}